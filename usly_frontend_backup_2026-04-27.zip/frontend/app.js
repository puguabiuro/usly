/* =========================================================
USLY — JS FINAL (v11) — SPÓJNY Z HTML v11 (PL ONLY)
CEL: UI + przygotowanie pod backend (spójne ID, stan, hooki)
========================================================= */

/* ------------------------- API Config -------------------------- */
// Prod: ustawimy na URL backendu z Render (osobna domena)
// Local: http://127.0.0.1:8001 (jak dziś uruchamiasz uvicorn)
const API_BASE_URL =
  window.USLY_API_BASE_URL ||
  (location.hostname.includes("onrender.com")
    ? "https://usly-backend-v2.onrender.com"
    : "http://127.0.0.1:8000");

// expose for api.js (plain scripts)
window.API_BASE_URL = API_BASE_URL;


/* ------------------------- App State -------------------------- */
const App = {
  lang: "pl", // PL only (zgodnie z wymaganiem "brak wersji angielskiej")
  role: "user", // 'user' | 'partner'
  isLoggedIn: false,
  history: ["S0_WELCOME"],
  currentView: "S0_WELCOME",
  resetToken: "",
  resetEmail: "",
  partnerEventFormMode: "create", // create | draft_edit | published_edit | archived_edit

  // Sub-states / filters
  eventsTab: "for_you", // 'for_you' | 'followed'

  // Profile 
  user: {
    plan: "free", // free | plus | premium | vip
    email: "",
    nick: "",
    city: "",
    age: "",
    bio: "",
    interests: [],
    prefAgeFrom: 18,
    prefAgeTo: 35,
    geo: { lat: "", lng: "" },
    avatarEmoji: "🙂",
    avatarUrl: "",
  },

  partner: {
    plan: "free", // free | pro | premium | enterprise
    email: "",
    company: "Kawiarnia Aurora",
    category: "gastro",
    city: "Warszawa",
    about: "",
    logoEmoji: "🏷️",
  },

  // data
  people: [],

  events: [
    {
      id: "e1",
      title: "Koncert na żywo",
      city: "Warszawa",
      when: "Sobota 18:00",
      where: "Centrum",
      interest: "muzyka",
      desc: "Wieczór z muzyką na żywo i luźną atmosferą.",
      paidMode: "paid_fixed",
      price: 49,
      priceFrom: null,
      priceTo: null,
      ticketLink: "https://example.com",
      saved: false,
      interested: false,
      organizer: { id: "p1", name: "Klub Aurora" },
    },
    {
      id: "e2",
      title: "Poranna joga",
      city: "Warszawa",
      when: "Niedziela 09:00",
      where: "Park",
      interest: "joga",
      desc: "Spokojna joga na świeżym powietrzu. Weź matę.",
      paidMode: "free",
      price: 0,
      priceFrom: null,
      priceTo: null,
      ticketLink: "https://example.com",
      saved: false,
      interested: false,
      organizer: { id: "p2", name: "Studio Balance" },
    },
    {
      id: "e3",
      title: "Wieczór planszówek",
      city: "Warszawa",
      when: "Piątek 19:00",
      where: "Kawiarnia",
      interest: "planszówki",
      desc: "Poznaj ludzi przy grach — bez spiny, z uśmiechem.",
      paidMode: "paid_range",
      price: null,
      priceFrom: 15,
      priceTo: 30,
      ticketLink: "https://example.com",
      saved: false,
      interested: false,
      organizer: { id: "p1", name: "Kawiarnia Aurora" },
    },
  ],

  // Group model: interestTag used for filtering by profile interests
  groups: [],

  myGroups: [],
  partnerEvents: [],

  chats: [],

  // Working selection
  selectedPersonId: null,
  selectedEventId: null,
  selectedPartnerEventId: null,
  selectedChatId: null,
  selectedChatUserId: null,
  currentUserId: null,
  selectedGroupId: null,
};

/* ------------------------- DOM Helpers -------------------------- */
const $ = (id) => document.getElementById(id);

const USLY_STORAGE_KEYS = {
  token: "usly_token",
  userPlan: "usly_user_plan",
  partnerPlan: "usly_partner_plan",
  savedEvents: "usly_saved_events",
};

try {
  const hasToken =
    !!localStorage.getItem(USLY_STORAGE_KEYS.token) ||
    !!localStorage.getItem("usly_token");

  if (hasToken) {
    const savedUserPlan = localStorage.getItem(USLY_STORAGE_KEYS.userPlan);
    if (savedUserPlan && ["free", "plus", "premium", "vip"].includes(savedUserPlan)) {
      App.user.plan = savedUserPlan;
    }

    const savedPartnerPlan = localStorage.getItem(USLY_STORAGE_KEYS.partnerPlan);
    if (savedPartnerPlan && ["free", "pro", "premium", "enterprise"].includes(savedPartnerPlan)) {
      App.partner.plan = savedPartnerPlan;
    }
  } else {
    App.user.plan = "free";
    App.partner.plan = "free";
  }
} catch (_) {
  App.user.plan = "free";
  App.partner.plan = "free";
}

function safeSetText(id, text) {
  const el = $(id);
  if (el) el.textContent = text;
}

function show(el) { if (el) el.style.display = ""; }
function hide(el) { if (el) el.style.display = "none"; }

function getSavedEventIds() {
  try {
    const raw = localStorage.getItem(USLY_STORAGE_KEYS.savedEvents);
    const arr = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(arr) ? arr.map(String) : []);
  } catch (_) {
    return new Set();
  }
}

function persistSavedEventIds() {
  try {
    const ids = App.events.filter(e => e.saved).map(e => String(e.id));
    localStorage.setItem(USLY_STORAGE_KEYS.savedEvents, JSON.stringify(ids));
  } catch (_) {}
}

function syncEventDetailButtons() {
  const ev = App.events.find(e => String(e.id) === String(App.selectedEventId));
  if (!ev) return;

  const saveBtn = document.querySelector('#S7B_EVENT_DETAIL button[onclick="toggleSaveEvent()"]');
  const interestedBtn = document.querySelector('#S7B_EVENT_DETAIL button[onclick="toggleInterestedEvent()"]');

  if (saveBtn) {
    saveBtn.textContent = ev.saved ? "Obserwowane" : "Obserwuj";
  }

  if (interestedBtn) {
    interestedBtn.textContent = ev.interested ? "Zrezygnuj z udziału" : "Wezmę udział";
  }
}

/* ------------------------- Navigation -------------------------- */
function go(viewId) {
  if (!viewId) return;
  const current = App.currentView;
  if (current === viewId) return;

  // Hide all
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));

  const next = $(viewId);
  if (!next) {
    toast(`Brak widoku: ${viewId}`);
    return;
  }
  next.classList.add("active");

  App.currentView = viewId;
  App.history.push(viewId);

  if (viewId === "S10E_PROFILE_INVITES" || viewId === "S12_NOTIFICATIONS") {
    updateNotifBadges(0);
  }

  if (viewId === "S10E_PROFILE_INVITES") {
    refreshProfileRelations().catch(() => {});
  }

  if (viewId === "S2_REGISTER" && App.role === "user") {
    useCurrentLocationForCity();
  }


  
  if (viewId === "S3_PROFILE_SETUP" && App.role === "user") {
    const setupCity = $("setupCity");
    if (setupCity) setupCity.value = "Pobieranie lokalizacji...";

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;

          App.user.geo = App.user.geo || {};
          App.user.geo.lat = String(lat);
          App.user.geo.lng = String(lng);

          const cityInput = $("setupCity");
          if (cityInput) cityInput.value = "Pobieranie lokalizacji...";

          apiFetch("/users/me", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              location_lat: lat,
              location_lng: lng,
            }),
          })
            .then((data) => {
              App.user.city = data?.data?.miasto || App.user.city;
              App.user.geo = App.user.geo || {};
              App.user.geo.lat = String(data?.data?.location_lat || lat);
              App.user.geo.lng = String(data?.data?.location_lng || lng);

              if (cityInput) cityInput.value = App.user.city || "Lokalizacja pobrana";
            })
            .catch(() => {
              if (cityInput) cityInput.value = App.user.city || "Lokalizacja pobrana";
            });
        },
        () => {},
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 60000 }
      );
    }
  }


if (viewId === "S4_NEARBY" && App.role === "user") {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;

          App.user.geo.lat = String(lat);
          App.user.geo.lng = String(lng);

          apiFetch("/users/me", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              location_lat: lat,
              location_lng: lng,
            }),
          })
            .then(() => loadNearbyPeople())
            .then(() => renderNearby())
            .catch((err) => console.error("location save failed", err));

          if (nearbyMap) {
            nearbyMap.setView([lat, lng], 12);
            renderNearbyMapMarkers();
          }
        },
        () => {},
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 60000 }
      );
    }
  }

  if (viewId === "S10_SETTINGS") {
    if ($("setNick")) $("setNick").value = App.user.nick || "";
    if ($("setBio")) $("setBio").value = App.user.bio || "";
    if ($("setCity")) $("setCity").value = App.user.city || "";

    safeSetText("settingsProfileHeroNick", App.user.nick || "Twój profil");
    safeSetText(
      "settingsProfileHeroMeta",
      [App.user.city, App.user.bio].filter(Boolean).join(" • ") || "Uzupełnij profil, aby poprawić dopasowania."
    );
    safeSetText("settingsProfilePlanPill", String(App.user.plan || "FREE").toUpperCase());
    safeSetText("settingsProfilePlanPillSecondary", String(App.user.plan || "FREE").toUpperCase());
    if ($("setupPrefAgeFrom")) $("setupPrefAgeFrom").value = String(App.user.prefAgeFrom);
    if ($("setupPrefAgeTo")) $("setupPrefAgeTo").value = String(App.user.prefAgeTo);
    safeSetText("setupAgeDisplay", `Wiek: ${App.user.age || "—"} lat`);
    safeSetText("setPrefAgeFromVal", String(App.user.prefAgeFrom));
    safeSetText("setPrefAgeToVal", String(App.user.prefAgeTo));
    refreshProfileRelations().catch(() => {});
  }

  // Render after navigation
  renderAll();
}

function back() {
  if (App.history.length <= 1) return go("S0_WELCOME");
  // Remove current
  App.history.pop();
  const prev = App.history[App.history.length - 1] || "S0_WELCOME";

  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  const prevEl = $(prev);
  if (prevEl) prevEl.classList.add("active");
  App.currentView = prev;

  renderAll();
}

/* ------------------------- Toast -------------------------- */
let toastTimer = null;
function toast(message) {
  const el = $("toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ------------------------- Modal -------------------------- */
function openModal(title, html) {
  const overlay = $("modalOverlay");
  const body = $("modalBody");
  const ttl = $("modalTitle");
  if (!overlay || !body || !ttl) return;

  ttl.textContent = title || "USLY";
  body.innerHTML = html || "";
  overlay.classList.add("show");
  overlay.setAttribute("aria-hidden", "false");
}

function closeModal() {
  const overlay = $("modalOverlay");
  if (!overlay) return;
  overlay.classList.remove("show");
  overlay.setAttribute("aria-hidden", "true");
}

/* ------------------------- Bug Report -------------------------- */
// Minimal UI for "Zgłoś błąd" button added in S10_SETTINGS.
// Does not remove/alter any existing behavior.
function openBugReport() {
  openModal("Zgłoś błąd", `
    <div class="tStrong">Zgłoszenie błędu</div>
    <div class="sectionSub mt10">Opisz krótko problem. To trafia do zespołu (na testach).</div>
    <label class="mt12">Co nie działa?</label>
    <textarea id="bugReportText" maxlength="1000" placeholder="Np. Po kliknięciu Zapisz zmiany nic się nie dzieje..."></textarea>
    <div class="charHint"><span id="bugReportCount">0</span>/1000</div>
    <button class="btn mt16" type="button" onclick="submitBugReport()">Wyślij</button>
  `);

  const ta = $("bugReportText");
  const cnt = $("bugReportCount");
  if (ta && cnt) {
    const upd = () => (cnt.textContent = String(ta.value.length));
    ta.addEventListener("input", upd);
    upd();
    // autofocus
    setTimeout(() => ta.focus(), 0);
  }
}

function submitBugReport() {
  const ta = $("bugReportText");
  const message = (ta?.value || "").trim();
  if (!message) {
    toast("Opisz proszę problem");
    return;
  }

  // Optional API base override via window.USLY_API_BASE.
  // Example: window.USLY_API_BASE = "https://api.example.com";
  const base = window.USLY_API_BASE;
  if (base) {
    fetch(String(base).replace(/\/$/, "") + "/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: "bug",
        message,
        // Minimal context to help diagnose (safe for MVP tests)
        view: App.currentView,
        role: App.role,
      }),
    })
      .then(async (r) => {
        if (!r.ok) throw new Error("HTTP " + r.status);
        toast("Dzięki! Zgłoszenie wysłane.");
        closeModal();
      })
      .catch(() => {
        toast("Nie udało się wysłać ");
        closeModal();
      });
    return;
  }

  // fallback
  toast("Dzięki! Zgłoszenie zapisane ");
  closeModal();
}

/* ------------------------- Role Selection -------------------------- */
function selectRole(role) {
  if (role !== "user" && role !== "partner") return;
  App.role = role;

  // Toggle segmented buttons (where present)
  const pairs = [
    ["roleUserBtn", "rolePartnerBtn"],
    ["roleUserBtnLogin", "rolePartnerBtnLogin"],
    ["roleUserBtn2", "rolePartnerBtn2"],
  ];
  pairs.forEach(([u, p]) => {
    const uEl = $(u), pEl = $(p);
    if (!uEl || !pEl) return;
    if (role === "user") {
      uEl.classList.add("on"); pEl.classList.remove("on");
    } else {
      pEl.classList.add("on"); uEl.classList.remove("on");
    }
  });

  // Labels
  safeSetText("roleLabelLogin", role === "user" ? "Towarzysz" : "Organizator");
  safeSetText("roleLabelRegister", role === "user" ? "Towarzysz" : "Organizator");
  safeSetText("regSubLine", role === "user"
    ? "Stwórz konto Towarzysza i ustaw profil."
    : "Stwórz konto Organizatora i ustaw profil.");

  // Show/Hide registration account fields
  const regUserAccountFields = $("regUserAccountFields");
  const regPartnerAccountFields = $("regPartnerAccountFields");
  if (regUserAccountFields && regPartnerAccountFields) {
    if (role === "user") { show(regUserAccountFields); hide(regPartnerAccountFields); }
    else { hide(regUserAccountFields); show(regPartnerAccountFields); }
  }

  // Show/Hide registration blocks
  const userBox = $("regUserBox");
  const userPlanBox = $("regUserPlanBox");
  const partnerBox = $("regPartnerBox");
  if (userBox && partnerBox) {
    if (role === "user") {
      show(userBox);
      if (userPlanBox) show(userPlanBox);
      hide(partnerBox);
    } else {
      hide(userBox);
      if (userPlanBox) hide(userPlanBox);
      show(partnerBox);
    }
  }

  // Settings sections
  const settingsUser = $("settingsUserBox");
  const settingsPartner = $("settingsPartnerBox");
  if (settingsUser && settingsPartner) {
    if (role === "user") { show(settingsUser); hide(settingsPartner); }
    else { hide(settingsUser); show(settingsPartner); }
  }

  // Plans sections
  const plansUserOnly = $("plansUserOnly");
  const plansPartnerOnly = $("plansPartnerOnly");
  if (plansUserOnly && plansPartnerOnly) {
    if (role === "user") { show(plansUserOnly); hide(plansPartnerOnly); }
    else { hide(plansUserOnly); show(plansPartnerOnly); }
  }

  // Update tabbars visibility (still controlled by login class + role)
  updateTabbars();

  // Re-render pills etc.
  renderAll();
}

/* ------------------------- Login / Signup -------------------------- */
async function loginPrimary() {
  const email = $("loginId")?.value?.trim();
  const password = $("loginPass")?.value?.trim();

  if (!email || !password) {
    toast("Podaj email i hasło");
    return;
  }

  try {
    const data = await apiFetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, expected_role: App.role === "partner" ? "partner" : "user" }),
    });

    if (!data?.success || !data?.data?.access_token) {
      toast(data?.error?.message || "Błąd logowania");
      return;
    }

    localStorage.setItem("usly_token", data.data.access_token);

    const me = await apiFetch("/auth/me");
    const meData = me?.data || me || {};
    App.currentUserId = meData.id ?? null;
    App.role = meData.role === "partner" ? "partner" : "user";
    App.isLoggedIn = true;

    const accountEmail = meData.email || "";
    if (App.role === "user") {
      App.user.email = accountEmail;
      const el = $("setEmail");
      if (el) el.value = accountEmail;
    } else {
      App.partner.email = accountEmail;
      const el = $("setOrgEmail");
      if (el) el.value = accountEmail;
    }

    if (App.role === "user") {
      const profile = await apiFetch("/users/me");
      if (profile?.success && profile?.data) {
        App.user.nick = profile.data.nick || App.user.nick;
        App.user.city = profile.data.miasto || App.user.city;
        App.user.bio = profile.data.bio || "";
        App.user.prefAgeFrom = Object.prototype.hasOwnProperty.call(profile.data, "age_min") ? profile.data.age_min : App.user.prefAgeFrom;
        App.user.prefAgeTo = Object.prototype.hasOwnProperty.call(profile.data, "age_max") ? profile.data.age_max : App.user.prefAgeTo;
        const backendInterests = Array.isArray(profile.data.zainteresowania) ? profile.data.zainteresowania : [];

        App.user.interests = backendInterests;
        try { localStorage.setItem("usly_user_interests", JSON.stringify(backendInterests)); } catch(_) {}
        App.user.plan = profile.data.plan || App.user.plan;
        App.user.avatarUrl = profile.data.avatar_url ?? "";
        if (profile.data.location_lat != null && profile.data.location_lng != null) {
          App.user.geo.lat = String(profile.data.location_lat);
          App.user.geo.lng = String(profile.data.location_lng);
        }
        try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, App.user.plan); } catch (_) {}
      }
    } else {
      await loadPartnerProfile();
      await loadPartnerEvents();
    }

    $("appRoot")?.classList.add("isLoggedIn");
updateTabbars();

if (App.role === "user") {
  await Promise.all([loadNearbyPeople(), loadEvents(), loadMyGroups(), loadGroups(), renderChatList()]);
}

renderAll();
bindMessageInputs();

toast("Zalogowano");
if (App.role === "user") go("S4_NEARBY");
else go("S9_PARTNER");
  } catch (err) {
    toast(err?.userMessage || "Błąd logowania");
  }
}

async function loadPartnerProfile() {
  try {
    const profile = await apiFetch("/partners/me");
    if (profile?.success && profile?.data) {
      App.partner.company = profile.data.nazwa || App.partner.company;
      App.partner.city = profile.data.miasto || App.partner.city;
      App.partner.category = profile.data.kategoria || App.partner.category || "inne";
      App.partner.plan = profile.data.plan || App.partner.plan || "free";
      App.partner.about = profile.data.bio || "";
      App.partner.logoUrl = profile.data.logo_url || "";
    }
  } catch (err) {
    console.error("loadPartnerProfile failed", err);
  }
}

function loginSocial(provider) {
  toast("Logowanie społecznościowe będzie dostępne wkrótce");
}

function signupSocial(provider) {
  toast("Rejestracja społecznościowa będzie dostępna wkrótce");
}

function logout() {
  App.isLoggedIn = false;
  try { localStorage.removeItem("usly_token"); } catch (_) {}
  try { localStorage.removeItem(USLY_STORAGE_KEYS.userPlan); } catch (_) {}
  try { localStorage.removeItem("usly_user_interests"); } catch (_) {}

  App.currentUserId = null;
  App.selectedPersonId = null;
  App.selectedChatId = null;
  App.selectedChatUserId = null;
  App.selectedEventId = null;
  App.selectedGroupId = null;

  App.user.plan = "free";
  App.user.nick = "";
  App.user.city = "";
  App.user.age = 24;
  App.user.bio = "";
  App.user.interests = [];
  App.user.prefAgeFrom = 18;
  App.user.prefAgeTo = 35;
  App.user.avatarUrl = "";

  App.people = [];
  App.chats = [];
  App.myGroups = [];

  $("appRoot")?.classList.remove("isLoggedIn");

  hide($("tabbarUser"));
  hide($("tabbarPartner"));

  toast("Wylogowano");
  App.history = ["S0_WELCOME"];
  go("S0_WELCOME");
}
function openForgot() {
  openModal("Odzyskiwanie hasła", `
    <div class="tStrong">Reset hasła</div>
    <div class="sectionSub">Podaj adres e-mail przypisany do konta. Wyślemy link do ustawienia nowego hasła.</div>
    <label class="mt12">Email</label>
    <input id="forgotEmail" type="email" placeholder="np. ola@email.com" />
    <button class="btn mt16" type="button" onclick="submitForgotPassword()">Wyślij link</button>
  `);
}

async function submitForgotPassword() {
  const email = ($("forgotEmail")?.value || "").trim().toLowerCase();

  if (!email) {
    toast("Podaj adres e-mail");
    return;
  }

  try {
    await apiFetch("/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    closeModal();
    toast("Jeśli konto istnieje, wyślemy link do ustawienia nowego hasła.");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wysłać linku. Spróbuj ponownie.");
  }
}

/* ------------------------- Registration -------------------------- */
async function registerPrimary() {
  const terms = $("acceptTerms")?.checked;
  const rodo = $("acceptRodo")?.checked;
  if (!terms || !rodo) {
    toast("Zaznacz wymagane zgody (*)");
    return;
  }

  const email = $("regEmail")?.value?.trim();
  const pass = $("regPass")?.value?.trim();
  const passRepeat = $("regPassRepeat")?.value?.trim();

  if (!email || !pass || !passRepeat || pass.length < 8) {
    toast("Uzupełnij email, hasło i powtórzenie hasła (min. 8 znaków)");
    return;
  }

  if (pass !== passRepeat) {
    toast("Hasła nie są takie same");
    return;
  }

  let dob = "";

  if (App.role === "user") {
    const city = normalizeCity($("regCity")?.value);
    const nick = $("regNick")?.value?.trim();

    const dobEl = $("regBirthDate");
    const errEl = $("ageError");
    dob = (dobEl?.value || "").trim();

    function showAgeError(msg) {
      if (errEl) {
        errEl.style.display = "block";
        errEl.textContent = msg;
      }
      toast(msg);
    }

    function hideAgeError() {
      if (errEl) errEl.style.display = "none";
    }

    if (!dob) {
      showAgeError("Podaj datę urodzenia.");
      return;
    }

    const birth = new Date(dob);
    if (Number.isNaN(birth.getTime())) {
      showAgeError("Nieprawidłowa data urodzenia.");
      return;
    }

    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;

    if (age < 18) {
      showAgeError("Nie możesz się zarejestrować – wymagane jest ukończone 18 lat.");
      return;
    }

    hideAgeError();

    if (!nick) {
      toast("Uzupełnij datę urodzenia i nick");
      return;
    }

    if (!App.user?.geo?.lat || !App.user?.geo?.lng) {
      toast("Włącz lokalizację, aby kontynuować");
      return;
    }

    App.user.city = city;
    App.user.age = age;
    App.user.dob = dob;
    App.user.nick = nick;
  } else {
    const company = $("regCompany")?.value?.trim();
    const category = $("regCategory")?.value;
    const city = normalizeCity($("regCityPartner")?.value);
    dob = null;

    if (!company || !city) {
      toast("Uzupełnij nazwę i miasto organizatora");
      return;
    }

    App.partner.company = company;
    App.partner.category = category || "inne";
    App.partner.city = city || "Warszawa";
    App.partner.about = $("regOrgAbout")?.value?.trim() || "";
  }

  try {
    const data = await apiFetch("/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        password: pass,
        dob,
        role: App.role === "partner" ? "partner" : "user",
        accept_terms: true,
      }),
    });

    if (!data?.success || !data?.data?.id) {
      toast(data?.error?.message || "Nie udało się utworzyć konta");
      return;
    }

    const loginData = await apiFetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password: pass, expected_role: App.role === "partner" ? "partner" : "user" }),
    });

    if (!loginData?.success || !loginData?.data?.access_token) {
      toast("Konto utworzone, ale nie udało się zalogować automatycznie");
      go("S1_LOGIN");
      return;
    }

    localStorage.setItem("usly_token", loginData.data.access_token);

    const me = await apiFetch("/auth/me");
    App.currentUserId = me?.id ?? me?.data?.id ?? null;
    App.role = (me?.data?.role || me?.role) === "partner" ? "partner" : "user";
    App.isLoggedIn = true;

    if (App.role === "user") {
      const profile = await apiFetch("/users/me");
      if (profile?.success && profile?.data) {
        App.user.nick = profile.data.nick || App.user.nick;
        App.user.city = profile.data.miasto || App.user.city;
        App.user.bio = profile.data.bio || "";
          const backendInterests = Array.isArray(profile.data.zainteresowania) ? profile.data.zainteresowania : [];
          App.user.interests = backendInterests;
          try { localStorage.setItem("usly_user_interests", JSON.stringify(backendInterests)); } catch(_) {}
        App.user.plan = profile.data.plan || App.user.plan;
        App.user.avatarUrl = profile.data.avatar_url || App.user.avatarUrl || "";
        try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, App.user.plan); } catch (_) {}
      }
    } else {
      await loadPartnerProfile();
      await loadPartnerEvents();
    }

    $("appRoot")?.classList.add("isLoggedIn");
    updateTabbars();

    renderAll();
    bindMessageInputs();

    toast("Konto utworzone i zalogowano");
      if (App.role === "user") {
        if ($("setupNick")) $("setupNick").value = App.user.nick || "";
        if ($("setupCity")) $("setupCity").value = App.user.city || "";
        if ($("setupBio")) $("setupBio").value = App.user.bio || "";
        if ($("setupPrefAgeFrom")) $("setupPrefAgeFrom").value = String(App.user.prefAgeFrom);
        if ($("setupPrefAgeTo")) $("setupPrefAgeTo").value = String(App.user.prefAgeTo);
        safeSetText("bioCount", String(($("setupBio")?.value || "").length));
        safeSetText("setupAgeDisplay", `Wiek: ${App.user.age || "—"} lat`);
        safeSetText("setupAgeDisplay", `Wiek: ${App.user.age || "—"} lat`);
        renderInterestChips("interestChips");
        refreshInterestUi();
        go("S3_PROFILE_SETUP");
      } else {
        go("S9_PARTNER");
      }
  } catch (err) {
    toast(err?.userMessage || "Nie udało się utworzyć konta");
  }
}

/* ------------------------- Plans -------------------------- */

function refreshUserPlanCardsUi() {
  const current = String(App.user?.plan || "free").toLowerCase();

  document.querySelectorAll('#S11_PLANS #plansUserOnly .card[data-plan]').forEach(card => {
    const plan = String(card.dataset.plan || "").toLowerCase();
    const btn = card.querySelector('button.btn.secondary');

    card.classList.toggle("is-current", plan === current);

    if (btn) {
      btn.textContent = plan === current ? "Aktualny plan" : "Wybierz";
    }
  });

  safeSetText("settingsProfilePlanPill", current.toUpperCase());
  safeSetText("settingsProfilePlanPillSecondary", current.toUpperCase());
}


async function setUserPlan(plan, silent = false) {
  const allowed = ["free", "plus", "premium", "vip"];
  if (!allowed.includes(plan)) return;

  const prevPlan = App.user.plan;
  App.user.plan = plan;
  try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, plan); } catch(_) {}

  const btnIds = [
    "uplan_free", "uplan_plus", "uplan_premium", "uplan_vip",
    "uplan_free_set", "uplan_plus_set", "uplan_premium_set", "uplan_vip_set",
  ];
  btnIds.forEach(id => {
    const b = $(id);
    if (!b) return;
    const isOn = b.dataset.plan === plan;
    b.classList.toggle("on", isOn);
    b.classList.toggle("active", isOn);
  });

  safeSetText("planPillSetup", plan.toUpperCase());
  refreshUserPlanCardsUi();
  renderAll();

  if (App.isLoggedIn && App.role === "user") {
    try {
      const data = await apiFetch("/users/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nick: App.user.nick || "",
          miasto: App.user.city || "",
          bio: App.user.bio || "",
          zainteresowania: Array.isArray(App.user.interests) ? App.user.interests : [],
          age_min: App.user.prefAgeFrom,
          age_max: App.user.prefAgeTo,
          plan: plan,
        }),
      });

      if (!data?.success || !data?.data) {
        throw new Error(data?.error?.message || "Nie udało się zapisać planu");
      }

      App.user.plan = data.data.plan || plan;
      try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, App.user.plan); } catch(_) {}
      safeSetText("planPillSetup", App.user.plan.toUpperCase());
      refreshUserPlanCardsUi();
      renderAll();
      if (!silent) toast(`Wybrano plan: ${App.user.plan.toUpperCase()}`);
      return;
    } catch (err) {
      App.user.plan = prevPlan;
      try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, prevPlan); } catch(_) {}
      btnIds.forEach(id => {
        const b = $(id);
        if (!b) return;
        const isOn = b.dataset.plan === prevPlan;
        b.classList.toggle("on", isOn);
        b.classList.toggle("active", isOn);
      });
      safeSetText("planPillSetup", prevPlan.toUpperCase());
      refreshUserPlanCardsUi();
      renderAll();
      toast(err?.userMessage || err?.message || "Nie udało się zapisać planu");
      return;
    }
  }

  if (!silent) toast(`Wybrano plan: ${plan.toUpperCase()}`);
}

async function setPartnerPlan(plan, silent = false) {
  const allowed = ["free", "pro", "premium", "enterprise"];
  if (!allowed.includes(plan)) return;

  const prevPlan = App.partner.plan || "free";
  App.partner.plan = plan;
  try { localStorage.setItem(USLY_STORAGE_KEYS.partnerPlan, plan); } catch(_) {}

  const btnIds = [
    "pplan_free", "pplan_pro", "pplan_premium", "pplan_enterprise",
    "pplan_free_set", "pplan_pro_set", "pplan_premium_set", "pplan_enterprise_set",
  ];
  btnIds.forEach(id => {
    const b = $(id);
    if (!b) return;
    const isOn = b.dataset.plan === plan;
    b.classList.toggle("on", isOn);
    b.classList.toggle("active", isOn);
  });

  document.querySelectorAll('#S11_PLANS #plansPartnerOnly .card[data-plan]').forEach(card => {
    const isCurrent = String(card.dataset.plan || "").toLowerCase() === plan;
    card.classList.toggle("is-current", isCurrent);
    const btn = card.querySelector(".btn");
    if (btn) btn.textContent = isCurrent ? "Aktualny plan" : "Wybierz";
  });

  document.querySelectorAll("#partnerPlanPill").forEach((el) => {
    el.textContent = plan.toUpperCase();
  });

  const isAuthSetupFlow = ["S1_LOGIN", "S2_REGISTER", "S3_PROFILE_SETUP", "S3B_PARTNER_SETUP"].includes(App.currentView);

  if (!silent && App.isLoggedIn && App.role === "partner" && !isAuthSetupFlow) {
    try {
      const res = await apiFetch("/partners/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan }),
      });

      if (!res?.success || !res?.data) {
        App.partner.plan = prevPlan;
        try { localStorage.setItem(USLY_STORAGE_KEYS.partnerPlan, prevPlan); } catch(_) {}
        renderAll();
        toast(res?.error?.message || "Nie udało się zapisać planu organizatora");
        return;
      }

      App.partner.plan = res.data.plan || plan;
      try { localStorage.setItem(USLY_STORAGE_KEYS.partnerPlan, App.partner.plan); } catch(_) {}
      document.querySelectorAll("#partnerPlanPill").forEach((el) => {
        el.textContent = String(App.partner.plan).toUpperCase();
      });
      toast(`Wybrano plan: ${String(App.partner.plan).toUpperCase()}`);
    } catch (err) {
      App.partner.plan = prevPlan;
      try { localStorage.setItem(USLY_STORAGE_KEYS.partnerPlan, prevPlan); } catch(_) {}
      renderAll();
      toast(err?.userMessage || "Nie udało się zapisać planu organizatora");
      return;
    }
  } else if (!silent) {
    toast(`Wybrano plan: ${String(plan).toUpperCase()}`);
  }

  renderAll();
}


function getPartnerPlanRules() {
  const plan = String(App.partner?.plan || "free").toLowerCase();

  if (plan === "enterprise") {
    return {
      plan,
      maxActiveEvents: null,
      reportsScope: "full",
      canMessageParticipants: true,
      canBroadcastParticipants: true,
      canFeatureEvents: true,
      isCustom: true,
    };
  }

  if (plan === "premium") {
    return {
      plan,
      maxActiveEvents: null,
      reportsScope: "full",
      canMessageParticipants: true,
      canBroadcastParticipants: true,
      canFeatureEvents: true,
      isCustom: false,
    };
  }

  if (plan === "pro") {
    return {
      plan,
      maxActiveEvents: 5,
      reportsScope: "basic",
      canMessageParticipants: true,
      canBroadcastParticipants: false,
      canFeatureEvents: false,
      isCustom: false,
    };
  }

  return {
    plan: "free",
    maxActiveEvents: 2,
    reportsScope: "basic",
    canMessageParticipants: false,
    canBroadcastParticipants: false,
    canFeatureEvents: false,
    isCustom: false,
  };
}


function getUserInterestLimit() {
  const plan = App.user.plan || "free";

  if (plan === "vip") return null;
  if (plan === "premium") return 20;
  if (plan === "plus") return 10;
  return 5;
}

function canAddMoreInterests(currentCount) {
  const limit = getUserInterestLimit();
  if (limit === null) return true;
  return currentCount < limit;
}

function getUserGroupPlanRules() {
  const plan = App.user.plan || "free";

  if (plan === "vip") {
    return {
      plan,
      canBrowseGroups: true,
      canOpenGroup: true,
      canInviteFriendsToGroup: true,
      maxActiveGroups: null,
    };
  }

  if (plan === "premium") {
    return {
      plan,
      canBrowseGroups: true,
      canOpenGroup: true,
      canInviteFriendsToGroup: true,
      maxActiveGroups: null,
    };
  }

  if (plan === "plus") {
    return {
      plan,
      canBrowseGroups: true,
      canOpenGroup: true,
      canInviteFriendsToGroup: false,
      maxActiveGroups: 3,
    };
  }

  return {
    plan: "free",
    canBrowseGroups: true,
    canOpenGroup: true,
    canInviteFriendsToGroup: false,
    maxActiveGroups: 1,
  };
}

function getUserGroupCreateRules() {
  const plan = App.user.plan || "free";

  if (plan === "vip") {
    return { plan, canCreate: true, createLimit: null };
  }

  if (plan === "premium") {
    return { plan, canCreate: true, createLimit: 3 };
  }

  if (plan === "plus") {
    return { plan, canCreate: true, createLimit: 1 };
  }

  return { plan: "free", canCreate: false, createLimit: 0 };
}

function refreshCreateGroupUi() {
  const btn = $("btnCreateGroup");
  const hint = $("groupCreateHint");
  const rules = getUserGroupCreateRules();

  const createdCount = Array.isArray(App.myGroups) ? App.myGroups.length : 0;
  const limitReached =
    rules.canCreate &&
    rules.createLimit != null &&
    createdCount >= rules.createLimit;

  if (btn) {
    const enabled = rules.canCreate && !limitReached;
    btn.disabled = !enabled;
    btn.style.opacity = enabled ? "1" : "0.65";
    btn.style.cursor = enabled ? "pointer" : "not-allowed";

    if (!rules.canCreate) {
      btn.textContent = "Dostępne od PLUS";
    } else if (limitReached) {
      btn.textContent = "Limit wykorzystany";
    } else {
      btn.textContent = "Utwórz grupę";
    }
  }

  if (hint) {
    if (!rules.canCreate) {
      hint.textContent = "Tworzenie własnych grup jest dostępne od planu PLUS.";
    } else if (rules.createLimit == null) {
      hint.textContent = `Utworzone grupy: ${createdCount} • Na planie VIP możesz tworzyć grupy bez limitu.`;
    } else if (limitReached) {
      hint.textContent = `Utworzone grupy: ${createdCount} / ${rules.createLimit} • Wykorzystałaś cały limit dla tego planu.`;
    } else {
      hint.textContent = `Utworzone grupy: ${createdCount} / ${rules.createLimit} • Możesz utworzyć jeszcze ${rules.createLimit - createdCount}.`;
    }
  }
}

function openCreateGroupModal() {
  const rules = getUserGroupCreateRules();

  if (!rules.canCreate) {
    toast("Tworzenie grup jest dostępne od planu PLUS");
    return;
  }

  openModal("Utwórz grupę", `
    <label>Tytuł grupy *</label>
    <input id="createGroupTitle" type="text" placeholder="np. Kawosze Warszawa" />

    <label class="mt12">Hashtag / zainteresowanie *</label>
    <div class="hashRow">
      <span class="hashPrefix">#</span>
      <input id="createGroupInterest" type="text" placeholder="np. kawa" />
    </div>

    <label class="mt12">Opis</label>
    <textarea id="createGroupDesc" maxlength="600" placeholder="Krótki opis grupy (opcjonalnie)"></textarea>

    <div class="sectionSub mt12">
      ${rules.createLimit == null
        ? "Tworzysz grupy bez limitu."
        : `Ten plan pozwala tworzyć do ${rules.createLimit} własnych grup.`}
    </div>

    <div class="row mt16">
      <button class="btn" type="button" onclick="submitCreateGroup()">Utwórz</button>
      <button class="btn secondary" type="button" onclick="closeModal()">Anuluj</button>
    </div>
  `);
}

async function submitCreateGroup() {
  const title = $("createGroupTitle")?.value?.trim();
  const interest = normalizeTag($("createGroupInterest")?.value?.trim());
  const description = $("createGroupDesc")?.value?.trim() || "";

  if (!title || title.length < 3) {
    toast("Podaj nazwę grupy (min. 3 znaki)");
    return;
  }

  if (!interest || interest.length < 2) {
    toast("Podaj hashtag grupy");
    return;
  }

  try {
    const data = await apiFetch("/groups", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        description,
        interest_tag: interest,
      }),
    });

    if (!data?.success) {
      toast(data?.error?.message || "Nie udało się utworzyć grupy");
      return;
    }

    closeModal();
    await Promise.all([loadMyGroups(), loadGroups()]);
    renderGroups();
    toast("Grupa została utworzona");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się utworzyć grupy");
  }
}


/* ------------------------- Groups helpers -------------------------- */
function isUserInGroup(groupId) {
  return App.myGroups.some(g => String(g.id) === String(groupId));
}

function userGroupsCount() {
  return App.myGroups.length;
}

function canJoinMoreGroups() {
  const plan = App.user.plan || "free";

  const limits = {
    free: 1,
    plus: 3,
    premium: null,
    vip: null,
  };

  const limit = Object.prototype.hasOwnProperty.call(limits, plan) ? limits[plan] : 1;

  if (limit === null) return true;

  return userGroupsCount() < limit;
}

function canInviteFriendsToGroup() {
  return getUserGroupPlanRules().canInviteFriendsToGroup;
}

/* ------------------------- Settings -------------------------- */
async function saveSettings() {
  const nick = $("setNick")?.value?.trim() || App.user.nick;
  const bio = $("setBio")?.value?.trim() || "";
  const city = normalizeCity($("setCity")?.value) || App.user.city;

  const ageAny = !!$("setAgeAny")?.checked;
  const f = Number($("setPrefAgeFrom")?.value || App.user.prefAgeFrom);
  const t = Number($("setPrefAgeTo")?.value || App.user.prefAgeTo);
  const ageMin = ageAny ? null : Math.min(f, t);
  const ageMax = ageAny ? null : Math.max(f, t);

  const payload = {
    nick: nick,
    miasto: city,
    bio: bio,
    zainteresowania: Array.isArray(App.user.interests) ? App.user.interests : [],
    age_min: ageMin,
    age_max: ageMax,
    nearby_radius_km: nearbyRadiusKm,
  };

  if (App.user?.geo?.lat && App.user?.geo?.lng) {
    payload.location_lat = Number(App.user.geo.lat);
    payload.location_lng = Number(App.user.geo.lng);
  }

  try {
    const data = await apiFetch("/users/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!data?.success || !data?.data) {
      toast(data?.error?.message || "Nie udało się zapisać ustawień");
      return;
    }

    App.user.nick = data.data.nick || nick;
    App.user.bio = data.data.bio || bio;
    App.user.nearbyRadiusKm = data.data.nearby_radius_km || nearbyRadiusKm;
    App.user.city = data.data.miasto || city;
    App.user.prefAgeFrom = Object.prototype.hasOwnProperty.call(data.data, "age_min") ? data.data.age_min : ageMin;
    App.user.prefAgeTo = Object.prototype.hasOwnProperty.call(data.data, "age_max") ? data.data.age_max : ageMax;
    App.user.interests = Array.isArray(data.data.zainteresowania) ? data.data.zainteresowania : (Array.isArray(App.user.interests) ? App.user.interests : []);

    await Promise.all([loadNearbyPeople(), loadEvents(), loadMyGroups(), loadGroups(), renderChatList()]);

    toast("Zapisano ustawienia");
    renderAll();
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zapisać ustawień");
  }
}

async function savePartnerSettings() {
  const company = $("setOrgCompany")?.value?.trim() || App.partner.company;
  const category = $("setOrgCategory")?.value || App.partner.category;
  const city = normalizeCity($("setOrgCity")?.value) || App.partner.city;
  const about = $("setOrgAbout")?.value?.trim() || "";

  try {
    const data = await apiFetch("/partners/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nazwa: company,
        miasto: city,
        kategoria: category,
        bio: about,
      }),
    });

    if (!data?.success || !data?.data) {
      toast(data?.error?.message || "Nie udało się zapisać ustawień organizatora");
      return;
    }

    App.partner.company = data.data.nazwa || company;
    App.partner.category = data.data.kategoria || category;
    App.partner.city = data.data.miasto || city;
    App.partner.about = data.data.bio || about;

    toast("Zapisano ustawienia organizatora");
    renderAll();
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zapisać ustawień organizatora");
  }
}

/* ------------------------- Terms / Privacy -------------------------- */
function openTerms() {
  window.open("legal/terms_pl.docx", "_blank");
}

function openRodo() {
  window.open("legal/privacy_pl.docx", "_blank");
}

async function uploadPartnerLogo(file) {
  if (!file) return;

  const form = new FormData();
  form.append("file", file);

  try {
    const data = await apiFetch("/uploads/logo", {
      method: "POST",
      body: form,
    });

    if (!data?.success || !data?.data?.logo_url) {
      toast(data?.error?.message || "Nie udało się wgrać logo");
      return;
    }

    App.partner.logoUrl = data.data.logo_url;
    toast("Logo zapisane");
    renderAll();
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wgrać logo");
  }
}

function initPartnerLogoUpload() {
  const input = $("setOrgLogo");
  if (!input || input.dataset.bound === "1") return;

  input.addEventListener("change", async (e) => {
    const file = e.target?.files?.[0];
    if (!file) return;
    await uploadPartnerLogo(file);
    input.value = "";
  });

  input.dataset.bound = "1";
}

/* ------------------------- Avatar / Photo hooks -------------------------- */
async function uploadUserAvatar(file) {
  if (!file) return;

  const form = new FormData();
  form.append("file", file);

  try {
    const data = await apiFetch("/uploads/avatar", {
      method: "POST",
      body: form,
    });

    if (!data?.success || !data?.data?.avatar_url) {
      toast(data?.error?.message || "Nie udało się wgrać zdjęcia");
      return;
    }

    App.user.avatarUrl = data.data.avatar_url;
    toast("Zdjęcie zapisane");
    renderAll();
    closeModal();
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wgrać zdjęcia");
  }
}

function openAddPhoto() {
  openModal("Dodaj zdjęcie", `
    <div class="tStrong">Upload zdjęcia</div>
    <div class="sectionSub mt10">Dodaj zdjęcie profilowe albo zostaw puste pole i używaj placeholdera.</div>
    <input id="userAvatarFileInput" type="file" accept="image/jpeg,image/png,image/webp" class="mt12" />
    <button id="userAvatarUploadBtn" class="btn mt16" type="button">Zapisz zdjęcie</button>
  `);

  setTimeout(() => {
    const btn = $("userAvatarUploadBtn");
    const input = $("userAvatarFileInput");
    if (!btn || !input || btn.dataset.bound === "1") return;

    btn.addEventListener("click", async () => {
      const file = input.files?.[0];
      if (!file) {
        toast("Wybierz plik ze zdjęciem");
        return;
      }
      await uploadUserAvatar(file);
    });

    btn.dataset.bound = "1";
  }, 0);
}

function openAvatarAI() {
  openModal("Stwórz awatar", `
    <div class="tStrong">Awatar AI</div>
    <div class="sectionSub mt10">UI. Backend: prompt → generator → zapis awatara.</div>
    <label class="mt12">Opis awatara</label>
    <input id="aiAvatarPrompt" type="text" placeholder="np. neonowy, minimalistyczny, uśmiechnięty" />
    <button class="btn mt16" type="button" onclick="toast('Awatar utworzony '); closeModal();">Generuj</button>
  `);
}

/* ------------------------- Profile Setup -------------------------- */
async function finishProfileSetup() {
  const nick = $("setupNick")?.value?.trim() || App.user.nick;
  const city = normalizeCity($("setupCity")?.value) || App.user.city;
  const bio = $("setupBio")?.value?.trim() || "";
  const nearbyRadiusKm = Number($("setupNearbyRadiusKm")?.value || App.user.nearbyRadiusKm || 25);

  const ageAny = !!$("setupAgeAny")?.checked;
  const f = Number($("setupPrefAgeFrom")?.value || App.user.prefAgeFrom);
  const t = Number($("setupPrefAgeTo")?.value || App.user.prefAgeTo);
  const ageMin = ageAny ? null : Math.min(f, t);
  const ageMax = ageAny ? null : Math.max(f, t);

  const payload = {
    nick: nick,
    miasto: city,
    bio: bio,
    zainteresowania: Array.isArray(App.user.interests) ? App.user.interests : [],
    age_min: ageMin,
    age_max: ageMax,
    nearby_radius_km: nearbyRadiusKm,
  };

  if (App.user?.geo?.lat && App.user?.geo?.lng) {
    payload.location_lat = Number(App.user.geo.lat);
    payload.location_lng = Number(App.user.geo.lng);
  }

  try {
    const data = await apiFetch("/users/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!data?.success || !data?.data) {
      toast(data?.error?.message || "Nie udało się zapisać profilu");
      return;
    }

    App.user.nick = data.data.nick || nick;
    App.user.city = data.data.miasto || city;
    App.user.bio = data.data.bio || bio;
    App.user.nearbyRadiusKm = data.data.nearby_radius_km || nearbyRadiusKm;
    App.user.prefAgeFrom = Object.prototype.hasOwnProperty.call(data.data, "age_min") ? data.data.age_min : ageMin;
    App.user.prefAgeTo = Object.prototype.hasOwnProperty.call(data.data, "age_max") ? data.data.age_max : ageMax;
    App.user.interests = Array.isArray(data.data.zainteresowania) ? data.data.zainteresowania : (Array.isArray(App.user.interests) ? App.user.interests : []);

    await Promise.all([loadNearbyPeople(), loadEvents(), loadMyGroups(), loadGroups(), renderChatList()]);

    toast("Profil zapisany");
    go("S4_NEARBY");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zapisać profilu");
  }
}

/* ------------------------- Nearby / Map -------------------------- */
function getNearbyPeopleForView() {
  const q = ($("nearbyPeopleSearch")?.value || "").trim().toLowerCase();
  return App.people
    .filter(p => String(p.id) !== String(App.currentUserId))
    .map(p => ({ person: p, score: commonInterests(p).length }))
    .filter(({ person, score }) => {
      const matchesSearch = !q || person.nick.toLowerCase().includes(q);
      return matchesSearch && score > 0;
    })
    .sort((a, b) => b.score - a.score)
    .map(({ person }) => person)
    .slice(0, 12);
}

function openMapMarker(type, index) {
  if (type === "person") {
    const person = getNearbyPeopleForView()[index];
    if (!person) return;
    App.selectedPersonId = person.id;
    openPerson(person.id);
  } else {
    const ev = App.events[index];
    if (!ev) return;
    openEvent(ev.id);
  }
}


function resolvePersonById(userId) {
  if (!userId) return null;

  const pid = String(userId);

  const fromPeople = (App.people || []).find(p => String(p.id) === pid);
  if (fromPeople) return fromPeople;

  const fromChats = (App.chats || []).find(c => String(c.with?.id) === pid);
  if (fromChats?.with) {
    return {
      id: String(fromChats.with.id),
      nick: fromChats.with.nick || `Użytkownik #${pid}`,
      role: fromChats.with.role || "user",
      company: fromChats.with.company || "",
      city: fromChats.with.city || "",
      category: fromChats.with.category || "",
      age: fromChats.with.age || 0,
      emoji: fromChats.with.emoji || "🙂",
      interests: Array.isArray(fromChats.with.interests) ? fromChats.with.interests : [],
      bio: fromChats.with.bio || "",
      avatarUrl: fromChats.with.avatarUrl || "",
      logoUrl: fromChats.with.logoUrl || fromChats.with.avatarUrl || "",
    };
  }

  const friendCards = Array.from(document.querySelectorAll('#profileFriendsList [onclick*="openChatParticipantProfile"]'));
  const friendCard = friendCards.find(el => String(el.getAttribute('onclick') || '').includes(`'${pid}'`));
  if (friendCard) {
    const title = friendCard.querySelector('.sectionTitle')?.textContent?.trim() || `Użytkownik #${pid}`;
    const sub = friendCard.querySelector('.sectionSub')?.textContent?.trim() || "";
    return {
      id: pid,
      nick: title,
      city: sub === "Znajomy w USLY" ? "" : sub,
      age: 0,
      emoji: "🙂",
      interests: [],
      bio: "",
      avatarUrl: "",
    };
  }

  const groupPeople = window._lastGroupPeople || { members: [], invited: [] };
  const fromGroupMembers = (groupPeople.members || []).find(p => String(p.id) === pid);
  if (fromGroupMembers) {
    return {
      id: pid,
      nick: fromGroupMembers.nick || `Użytkownik #${pid}`,
      city: fromGroupMembers.city || "",
      age: 0,
      emoji: "🙂",
      interests: [],
      bio: "",
      avatarUrl: fromGroupMembers.avatar_url || "",
    };
  }

  const fromGroupInvited = (groupPeople.invited || []).find(p => String(p.id) === pid);
  if (fromGroupInvited) {
    return {
      id: pid,
      nick: fromGroupInvited.nick || `Użytkownik #${pid}`,
      city: fromGroupInvited.city || "",
      age: 0,
      emoji: "🙂",
      interests: [],
      bio: "",
      avatarUrl: fromGroupInvited.avatar_url || "",
    };
  }

  return null;
}


/* ------------------------- Person Profile -------------------------- */
function openPerson(personId) {
  const p = resolvePersonById(personId);
  if (!p) return;

  App.selectedPersonId = personId;

  const initialProfileState =
    String(personId) === String(App.currentUserId) ? "self" : "default";

  setPersonFriendButtonState(initialProfileState);
  setPersonChatButtonState(initialProfileState);

  const isPartnerProfile = String(p.role || "").toLowerCase() === "partner";
  const friendBtn = $("personFriendBtn");
  const chatBtn = $("personChatBtn");
  const chips = $("personInterests");
  const avatar = $("personAvatar");

  if (isPartnerProfile) {
    if (friendBtn) friendBtn.style.display = "none";
    if (chatBtn) {
      chatBtn.disabled = false;
      chatBtn.style.opacity = "";
      chatBtn.classList.remove("secondary");
      chatBtn.dataset.state = "friend";
      chatBtn.textContent = "Napisz";
    }

    const displayName = p.company || p.nick || "Organizator";
    safeSetText("personTitle", displayName);
    safeSetText("personNick", displayName);
    safeSetText("personMeta", p.city || "Organizator");
    const matchEl = $("personMatchScore");
    if (matchEl) matchEl.style.display = "none";
    safeSetText("personMatchScore", "");
    safeSetText("personBio", p.bio || "To miejsce nie dodało jeszcze opisu.");

    if (avatar) {
      const src = p.logoUrl || p.avatarUrl || "";
      avatar.style.display = src ? "" : "none";
      avatar.innerHTML = src
        ? `<img src="${String(src).startsWith("http") ? src : `${API_BASE_URL}${src}`}" alt="${displayName}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`
        : "";
    }

    if (chips) {
      chips.dataset.label = "Branża";
      chips.innerHTML = "";
      const categoryLabel = getPartnerCategoryLabel(p.category);
      if (categoryLabel) chips.appendChild(makeChip(categoryLabel, null));
    }
    go("S5_PERSON_PROFILE");
    return;
  }

  if (App.role === "partner") {
    if (friendBtn) friendBtn.style.display = "none";
    if (chatBtn) {
      const rules = getPartnerPlanRules();
      chatBtn.disabled = !rules.canMessageParticipants;
      chatBtn.style.opacity = rules.canMessageParticipants ? "" : "0.7";
      chatBtn.classList.toggle("secondary", !rules.canMessageParticipants);
      chatBtn.dataset.state = rules.canMessageParticipants ? "friend" : "partner_locked";
      chatBtn.textContent = rules.canMessageParticipants ? "Napisz" : "Wiadomości od planu PRO";
    }
  } else {
    if (friendBtn) friendBtn.style.display = "";
  }

  safeSetText("personTitle", p.nick);
  safeSetText("personNick", p.nick);
  safeSetText("personMeta", [
    p.city,
    Number.isFinite(p.age) && p.age > 0 ? `${p.age} lat` : ""
  ].filter(Boolean).join(" • ") || "Profil użytkownika");
  safeSetText("personDistanceMeta", formatDistanceFromMe(p));
  const matchEl = $("personMatchScore");
  if (matchEl) matchEl.style.display = "";
  safeSetText("personMatchScore", `${sharedScore(p)}% dopasowania`);
  safeSetText("personBio", p.bio || "Ta osoba nie dodała jeszcze bio.");

  if (avatar) {
    avatar.innerHTML = p.avatarUrl
      ? `<img src="${String(p.avatarUrl).startsWith("http") ? p.avatarUrl : `${API_BASE_URL}${p.avatarUrl}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`
      : (p.emoji || "🙂");
  }

  if (chips) {
    chips.dataset.label = "Zainteresowania";
    chips.innerHTML = "";
    const shared = new Set(commonInterests(p).map(x => String(x).toLowerCase()));
    (p.interests || []).forEach(tag => {
      const chip = makeChip(`#${tag}`, null);
      if (shared.has(String(tag).toLowerCase())) {
        chip.classList.add("isShared");
      }
      chips.appendChild(chip);
    });
  }

  go("S5_PERSON_PROFILE");
  refreshProfileRelations().catch(() => {});

  if (String(personId) === String(App.currentUserId)) return;

  apiFetch(`/users/${encodeURIComponent(personId)}`)
    .then((data) => {
      const full = data?.data ? mapApiPersonToViewModel(data.data) : null;
      if (!full) return;
      if (String(App.selectedPersonId) !== String(personId)) return;

      safeSetText("personTitle", full.nick);
      safeSetText("personNick", full.nick);
      safeSetText("personMeta", [
        full.city,
        Number.isFinite(full.age) && full.age > 0 ? `${full.age} lat` : ""
      ].filter(Boolean).join(" • ") || "Profil użytkownika");
      safeSetText("personDistanceMeta", formatDistanceFromMe(full));
      safeSetText("personMatchScore", `${sharedScore(full)}% dopasowania`);
      safeSetText("personBio", full.bio || "Ta osoba nie dodała jeszcze bio.");

      const avatarEl = $("personAvatar");
      if (avatarEl) {
        avatarEl.innerHTML = full.avatarUrl
          ? `<img src="${String(full.avatarUrl).startsWith("http") ? full.avatarUrl : `${API_BASE_URL}${full.avatarUrl}`}" alt="${full.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`
          : (full.emoji || "🙂");
      }

      const fullChips = $("personInterests");
      if (fullChips) {
        fullChips.dataset.label = "Zainteresowania";
        fullChips.innerHTML = "";
        const shared = new Set(commonInterests(full).map(x => String(x).toLowerCase()));
        (full.interests || []).forEach(tag => {
          const chip = makeChip(`#${tag}`, null);
          if (shared.has(String(tag).toLowerCase())) {
            chip.classList.add("isShared");
          }
          fullChips.appendChild(chip);
        });
      }

      const idx = (App.people || []).findIndex(x => String(x.id) === String(full.id));
      if (idx >= 0) {
        App.people[idx] = { ...App.people[idx], ...full };
      } else {
        App.people.push(full);
      }
    })
    .catch(() => {});
}


async function blockUser(userId) {
  const token = localStorage.getItem(USLY_STORAGE_KEYS.token) || localStorage.getItem("usly_token");
  if (!token || !userId) {
    toast("Brak danych użytkownika");
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/blocks`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ blocked_user_id: Number(userId) }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      toast("Nie udało się zablokować użytkownika");
      return;
    }

    toast("Użytkownik został zablokowany");
    closeModal();

    // szybki refresh danych
    await Promise.all([
      loadNearbyPeople(),
      renderChatList?.(),
    ]);

  } catch (e) {
    toast("Błąd połączenia");
  }
}


function openPersonMenu() {
  openModal("Opcje", `
    <button class="btn secondary" type="button" onclick="toast('Zgłaszanie treści będzie dostępne w kolejnej aktualizacji.'); closeModal();">Zgłoś</button>
    <button class="btn danger mt12" type="button" onclick="blockUser(App.selectedPersonId)">Zablokuj</button>
  `);
}

function startChatFromProfile() {
  const pid = App.selectedPersonId;
  if (!pid) return;
  const p = resolvePersonById(pid);
  if (!p) return;

  const chatBtn = $("personChatBtn");
  const chatState = chatBtn?.dataset?.state || "default";

  if (chatState !== "friend") {
    if (chatState === "self") {
      toast("To Twoje konto");
    } else if (chatState === "pending") {
      toast("Prywatny czat będzie dostępny po akceptacji znajomości");
    } else {
      toast("Najpierw dodaj tę osobę do znajomych");
    }
    return;
  }

  // Create or open existing chat
  let chat = App.chats.find(c => String(c.with?.id) === String(pid));
  if (!chat) {
    chat = {
      id: `pm_${pid}`,
      with: {
        id: pid,
        nick: p.nick,
        role: "user",
        city: p.city || "",
        bio: p.bio || "",
        avatarUrl: p.avatarUrl || "",
        emoji: p.emoji || "💬",
      },
      last: "",
      unread: 0,
      messages: [],
    };
    App.chats.unshift(chat);
  }

  App.selectedChatId = chat.id;
  openChat(chat.id);
}

function setPersonFriendButtonState(state) {
  const btn = $("personFriendBtn");
  if (!btn) return;

  if (App.role === "partner") {
    btn.style.display = "none";
    btn.dataset.state = "partner_hidden";
    return;
  }

  btn.style.display = "";
  btn.dataset.state = state || "default";
  btn.disabled = false;
  btn.style.opacity = "";
  btn.classList.remove("secondary");
  btn.textContent = "Dodaj do znajomych";

  if (state === "self") {
    btn.textContent = "To Twoje konto";
    btn.disabled = true;
    btn.style.opacity = "0.7";
    btn.classList.add("secondary");
    return;
  }

  if (state === "friend") {
    btn.textContent = "Znajomy";
    btn.disabled = true;
    btn.style.opacity = "0.7";
    btn.classList.add("secondary");
    return;
  }

  if (state === "pending") {
    btn.textContent = "Zaproszenie wysłane";
    btn.disabled = true;
    btn.style.opacity = "0.7";
    btn.classList.add("secondary");
    return;
  }
}

function setPersonChatButtonState(state) {
  const btn = $("personChatBtn");
  if (!btn) return;

  if (App.role === "partner") {
    btn.style.display = "";
    const rules = getPartnerPlanRules();
    btn.dataset.state = rules.canMessageParticipants ? "friend" : "partner_locked";
    btn.disabled = !rules.canMessageParticipants;
    btn.style.opacity = rules.canMessageParticipants ? "" : "0.7";
    btn.classList.toggle("secondary", !rules.canMessageParticipants);
    btn.textContent = rules.canMessageParticipants ? "Napisz" : "Wiadomości od planu PRO";
    return;
  }

  btn.dataset.state = state || "default";
  btn.disabled = false;
  btn.style.opacity = "";
  btn.classList.add("secondary");
  btn.textContent = "Napisz";
  btn.style.display = "none";

  if (state === "friend") {
    btn.style.display = "";
    btn.textContent = "Napisz";
    btn.classList.remove("secondary");
    return;
  }
}

function syncPersonFriendButton(incoming, outgoing, friends) {
  const pid = App.selectedPersonId;
  if (!pid) return;

  if (String(pid) === String(App.currentUserId)) {
    setPersonFriendButtonState("self");
    setPersonChatButtonState("self");
    return;
  }

  const normalizedFriends = Array.isArray(friends) ? friends : [];
  const normalizedIncoming = Array.isArray(incoming) ? incoming : [];
  const normalizedOutgoing = Array.isArray(outgoing) ? outgoing : [];

  const isFriend = normalizedFriends.some(item => {
    const friendId = item.id || item.user_id || item.friend_id;
    return String(friendId) === String(pid);
  });

  if (isFriend) {
    setPersonFriendButtonState("friend");
    setPersonChatButtonState("friend");
    return;
  }

  const hasPendingIncoming = normalizedIncoming.some(item => {
    const user = item.user || {};
    return String(user.id) === String(pid) && String(item.status || "pending").toLowerCase() === "pending";
  });

  const hasPendingOutgoing = normalizedOutgoing.some(item => {
    const user = item.user || {};
    return String(user.id) === String(pid) && String(item.status || "pending").toLowerCase() === "pending";
  });

  if (hasPendingIncoming || hasPendingOutgoing) {
    setPersonFriendButtonState("pending");
    setPersonChatButtonState("pending");
    return;
  }

  setPersonFriendButtonState("default");
  setPersonChatButtonState("default");
}

async function addFriendFromProfile() {
  const pid = App.selectedPersonId;
  if (!pid) {
    toast("Nie wybrano profilu");
    return;
  }

  if (String(pid) === String(App.currentUserId)) {
    toast("To Twoje konto");
    return;
  }

  const token = localStorage.getItem(USLY_STORAGE_KEYS.token) || localStorage.getItem("usly_token");
  if (!token) {
    toast("Najpierw się zaloguj");
    return;
  }

  try {
    const data = await apiFetch("/friends/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ addressee_user_id: Number(pid) }),
    });

    if (!data?.success && data !== null) {
      toast(data?.error?.message || "Nie udało się wysłać zaproszenia");
      return;
    }

    toast("Zaproszenie do znajomych zostało wysłane");
    await refreshProfileRelations();
    await refreshNotifBadgeCount();
    if (App.currentView === "S12_NOTIFICATIONS") await renderNotifications();
  } catch (err) {
    toast(err?.userMessage || err?.message || "Nie udało się wysłać zaproszenia");
  }
}

async function refreshProfileRelations() {
  const token = localStorage.getItem(USLY_STORAGE_KEYS.token) || localStorage.getItem("usly_token");
  if (!token) return;

  try {
    const [requestsRes, groupInvRes, friendsRes] = await Promise.all([
      fetch(`${API_BASE_URL}/friends/requests`, {
        headers: { "Authorization": `Bearer ${token}` },
      }),
      fetch(`${API_BASE_URL}/group-invitations`, {
        headers: { "Authorization": `Bearer ${token}` },
      }),
      fetch(`${API_BASE_URL}/friends`, {
        headers: { "Authorization": `Bearer ${token}` },
      }),
    ]);

    const requestsData = await requestsRes.json().catch(() => ({}));
    const groupInvData = await groupInvRes.json().catch(() => ({}));
    const friendsData = await friendsRes.json().catch(() => ({}));

    const requestsPayload = requestsData && typeof requestsData === "object"
      ? (requestsData.data || requestsData)
      : {};

    const groupInvPayload = groupInvData && typeof groupInvData === "object"
      ? (groupInvData.data || groupInvData)
      : {};

    const friendsPayload = friendsData && typeof friendsData === "object"
      ? (friendsData.data || friendsData)
      : [];

    const incoming = Array.isArray(requestsPayload.incoming) ? requestsPayload.incoming : [];
    const outgoing = Array.isArray(requestsPayload.outgoing) ? requestsPayload.outgoing : [];
    const incomingGroupInvites = Array.isArray(groupInvPayload.incoming) ? groupInvPayload.incoming : [];
    const outgoingGroupInvites = Array.isArray(groupInvPayload.outgoing) ? groupInvPayload.outgoing : [];
    const friends = Array.isArray(friendsPayload) ? friendsPayload : (Array.isArray(friendsPayload.items) ? friendsPayload.items : []);
    window._lastFriendsList = friends.map(friend => ({
      ...friend,
      avatarUrl: friend.avatar_url || "",
      interests: Array.isArray(friend.interests) ? friend.interests : [],
      emoji: friend.emoji || "🙂",
    }));
    window._lastOutgoingGroupInvites = Array.isArray(outgoingGroupInvites) ? outgoingGroupInvites : [];

    const sortedFriends = [...friends].sort((a, b) => {
      const an = String(a?.nick || a?.name || a?.friend_nick || "").toLocaleLowerCase("pl-PL");
      const bn = String(b?.nick || b?.name || b?.friend_nick || "").toLocaleLowerCase("pl-PL");
      return an.localeCompare(bn, "pl-PL");
    });

    window._lastFriendsList = sortedFriends.map(friend => ({
      ...friend,
      avatarUrl: friend.avatar_url || "",
      interests: Array.isArray(friend.interests) ? friend.interests : [],
      emoji: friend.emoji || "🙂",
    }));

    renderProfileFriendRequests(incoming, outgoing, incomingGroupInvites, outgoingGroupInvites);
    renderProfileFriends(sortedFriends);
    syncPersonFriendButton(incoming, outgoing, sortedFriends);
  } catch (_) {
    renderProfileFriendRequests([], []);
    renderProfileFriends([]);
    syncPersonFriendButton([], [], []);
  }
}

function renderProfileFriendRequests(incoming, outgoing, incomingGroupInvites = [], outgoingGroupInvites = []) {
  const el = $("profileFriendRequestsList");
  if (!el) return;

  const inItems = Array.isArray(incoming) ? incoming : [];
  const outItems = Array.isArray(outgoing) ? outgoing : [];
  const inGroupItems = Array.isArray(incomingGroupInvites) ? incomingGroupInvites : [];
  const outGroupItems = Array.isArray(outgoingGroupInvites) ? outgoingGroupInvites : [];

  if (!inItems.length && !outItems.length && !inGroupItems.length && !outGroupItems.length) {
    el.innerHTML = '<div class="tMuted">Brak oczekujących zaproszeń.</div>';
    return;
  }

  const incomingHtml = inItems.map(item => {
    const user = item.user || {};
    const sender = user.nick || `Użytkownik #${user.id || "—"}`;
    const city = user.city || "";
    const requestId = item.id;

    return `
      <div class="card" style="margin:0;">
        <div class="row" style="align-items:center;justify-content:space-between;gap:12px;">
            <div style="text-align:left;flex:1;cursor:pointer;" onclick="openPerson('${user.id}')">
            <div class="sectionTitle" style="font-size:16px;">${sender}</div>
            <div class="sectionSub">${city || "Zaproszenie oczekuje na decyzję."}</div>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap;justify-content:flex-end;">
            <button class="btn small" type="button" onclick="respondToFriendRequest(${Number(requestId)}, 'accepted')">Akceptuj</button>
            <button class="btn secondary small" type="button" onclick="respondToFriendRequest(${Number(requestId)}, 'rejected')">Odrzuć</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  const outgoingHtml = outItems.map(item => {
    const user = item.user || {};
    const nick = user.nick || `Użytkownik #${user.id || "—"}`;
    const city = user.city || "";

    return `
      <div class="card" style="margin:0;opacity:0.9;">
        <div class="row" style="align-items:center;justify-content:space-between;gap:12px;">
            <div style="text-align:left;flex:1;cursor:pointer;" onclick="openPerson('${user.id}')">
            <div class="sectionTitle" style="font-size:16px;">${nick}</div>
            <div class="sectionSub">${city || "Zaproszenie wysłane — oczekuje na akceptację."}</div>
          </div>
          <div class="pill">Wysłane</div>
        </div>
      </div>
    `;
  }).join("");

  const groupInvHtml = incomingGroupInvites.map(inv => {
    const user = inv.user || {};
    const group = inv.group || {};
    const nick = user.nick || `Użytkownik #${user.id || "—"}`;
    const groupTitle = group.title || "Grupa";

    return `
      <div class="card" style="margin:0;">
        <div class="row" style="align-items:center;justify-content:space-between;gap:12px;">
          <div style="text-align:left;flex:1;">
            <div class="sectionTitle" style="font-size:16px;">${groupTitle}</div>
            <div class="sectionSub">${nick} zaprasza Cię do grupy</div>
          </div>
          <div class="row" style="gap:8px;flex-wrap:wrap;justify-content:flex-end;">
            <button class="btn small" type="button" onclick="respondToGroupInvitation(${Number(inv.id)}, 'accepted')">Akceptuj</button>
            <button class="btn secondary small" type="button" onclick="respondToGroupInvitation(${Number(inv.id)}, 'rejected')">Odrzuć</button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  el.innerHTML = incomingHtml + groupInvHtml + outgoingHtml;
}



function filterFriendsList(query) {
  const q = String(query || "").toLowerCase();

  const all = Array.isArray(window._lastFriendsList)
    ? window._lastFriendsList
    : [];

  const filtered = !q
    ? all
    : all.filter(f => {
        const nick = String(f.nick || f.name || "").toLowerCase();
        return nick.includes(q);
      });

  renderProfileFriends(filtered);
}

function renderProfileFriends(items) {
  const el = $("profileFriendsList");
  if (!el) return;

  if (!items.length) {
    el.innerHTML = '<div class="tMuted">Nie masz jeszcze znajomych.</div>';
    return;
  }

  el.innerHTML = items.map(item => {
    const friendId = item.id || item.user_id || item.friend_id;
    const friendNick = item.nick || item.name || item.friend_nick || `Użytkownik #${friendId || "—"}`;
    const friendCity = item.city || "";

    return `
      <div class="card" style="margin:0;cursor:pointer;" onclick="openChatParticipantProfile('${String(friendId || "")}')">
        <div class="row" style="align-items:center;justify-content:space-between;gap:12px;">
          <div style="text-align:left;flex:1;">
            <div class="sectionTitle" style="font-size:16px;">${friendNick}</div>
            <div class="sectionSub">${friendCity || "Znajomy w USLY"}</div>
          </div>
          <button class="btn secondary small" type="button" onclick="event.stopPropagation(); openChatParticipantProfile('${String(friendId || "")}')">Zobacz profil</button>
        </div>
      </div>
    `;
  }).join("");
}


async function respondToGroupInvitation(invitationId, action) {
  const token = localStorage.getItem(USLY_STORAGE_KEYS.token) || localStorage.getItem("usly_token");
  if (!token || !invitationId) {
    toast("Brak danych zaproszenia do grupy");
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/group-invitations/${invitationId}/respond`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ action }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      toast(data?.error?.message || data?.detail || "Nie udało się zaktualizować zaproszenia do grupy");
      return;
    }

    toast(action === "accepted" ? "Zaproszenie do grupy zaakceptowane" : "Zaproszenie do grupy odrzucone");
    await loadMyGroups();
    await refreshProfileRelations();
    await refreshGroupBadgeCount();
    if (App.currentView === "S12_NOTIFICATIONS") await renderNotifications();
  } catch (_) {
    toast("Błąd połączenia przy aktualizacji zaproszenia do grupy");
  }
}


async function respondToFriendRequest(requestId, action) {
  const token = localStorage.getItem(USLY_STORAGE_KEYS.token) || localStorage.getItem("usly_token");
  if (!token || !requestId) {
    toast("Brak danych zaproszenia");
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/friends/requests/${requestId}/respond`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ action }),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      toast(data.detail || "Nie udało się zaktualizować zaproszenia");
      return;
    }

    toast(action === "accepted" ? "Zaproszenie zaakceptowane" : "Zaproszenie odrzucone");
    await refreshProfileRelations();
  } catch (_) {
    toast("Błąd połączenia przy aktualizacji zaproszenia");
  }
}

function getChatOtherPerson() {
  if (!App.selectedChatUserId) return null;
  return resolvePersonById(App.selectedChatUserId) || null;
}

function openChatParticipantProfile(userId) {
  if (!userId) return;

  if (String(userId) === String(App.currentUserId)) {
    toast("To Twoje konto");
    return;
  }

  const person = resolvePersonById(userId);
  if (!person) {
    toast("Profil tej osoby nie jest teraz dostępny");
    return;
  }

  openPerson(person.id);
}

/* ------------------------- Chats -------------------------- */
async function openChat(chatId) {
  const chat = App.chats.find(c => c.id === chatId);
  if (!chat) return;
  App.selectedChatId = chatId;
  App.selectedChatUserId = chat.with.id;
  App.chatUnreadAtOpen = Number(chat.rawUnread ?? chat.unread ?? 0);

  safeSetText("chatTitle", chat.with.nick);

  // Mark read
  chat.unread = 0;

  go("S6B_CHAT_THREAD");
}

async function renderChatThread() {
  const box = $("chatBubbles");
  if (!box || !App.selectedChatUserId) return;

  const renderMessageRow = ({ from, text, senderUserId, createdAt, isRead }) => {
    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.alignItems = "flex-end";
    row.style.gap = "10px";
    row.style.margin = "10px 0";
    row.style.justifyContent = from === "me" ? "flex-end" : "flex-start";

    const avatar = document.createElement("button");
    avatar.type = "button";
    avatar.style.width = "32px";
    avatar.style.height = "32px";
    avatar.style.minWidth = "32px";
    avatar.style.borderRadius = "999px";
    avatar.style.border = from === "them" ? "1px solid rgba(16,24,40,0.08)" : "0";
    avatar.style.padding = "0";
    avatar.style.display = "inline-flex";
    avatar.style.alignItems = "center";
    avatar.style.justifyContent = "center";
    avatar.style.background = "#f2f4f7";
    avatar.style.cursor = from === "them" ? "pointer" : "default";
    avatar.style.overflow = "hidden";
    avatar.style.boxShadow = from === "them" ? "0 2px 8px rgba(16,24,40,0.08)" : "none";
    avatar.style.flexShrink = "0";

    if (from === "me") {
      if (App.user.avatarUrl) {
        const src = String(App.user.avatarUrl).startsWith("http")
          ? App.user.avatarUrl
          : `${API_BASE_URL}${App.user.avatarUrl}`;
        avatar.innerHTML = `<img src="${src}" alt="Twój awatar" style="width:100%;height:100%;object-fit:cover;" />`;
      } else {
        avatar.textContent = App.user.avatarEmoji || "🙂";
      }
      avatar.disabled = true;
    } else {
      const other = getChatOtherPerson();
      if (other?.avatarUrl) {
        const src = String(other.avatarUrl).startsWith("http")
          ? other.avatarUrl
          : `${API_BASE_URL}${other.avatarUrl}`;
        avatar.innerHTML = `<img src="${src}" alt="${escapeHtml(other.nick || "Użytkownik")}" style="width:100%;height:100%;object-fit:cover;" />`;
      } else {
        avatar.textContent = other?.emoji || "🙂";
      }
      avatar.title = "Otwórz profil";
      avatar.addEventListener("mouseenter", () => {
        avatar.style.transform = "scale(1.04)";
      });
      avatar.addEventListener("mouseleave", () => {
        avatar.style.transform = "scale(1)";
      });
      avatar.style.transition = "transform 120ms ease, box-shadow 120ms ease";
      avatar.addEventListener("click", (e) => {
        e.stopPropagation();
        openChatParticipantProfile(senderUserId);
      });
    }

    const bubble = document.createElement("div");
    bubble.className = `bubble ${from === "me" ? "me" : "them"}`;
    bubble.style.maxWidth = "78%";
    bubble.style.wordBreak = "break-word";
    bubble.style.boxShadow = "0 4px 14px rgba(16,24,40,0.06)";

    const rawText = String(text || "");
    const ts = parseUslyTimestamp(createdAt);
    const timeLabel = ts
      ? new Date(ts).toLocaleString("pl-PL", {
          day: "2-digit",
          month: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "";
    const readLabel = from === "me" ? (isRead ? "✓✓" : "✓") : "";
    const metaLabel = [timeLabel, readLabel].filter(Boolean).join("   ");

    if (rawText.startsWith("📣 ")) {
      const lines = rawText.split("\n").map(x => x.trim()).filter(Boolean);
      const titleLine = lines[0] || "📣 Wydarzenie";
      const bodyLines = lines.filter(line => line !== "— wiadomość od organizatora —" && line !== titleLine);
      const bodyText = bodyLines.join("\n\n");

      bubble.innerHTML = `
        <div style="display:flex;flex-direction:column;gap:8px;">
          <div style="font-weight:1000;line-height:1.15;">${escapeHtml(titleLine)}</div>
          <div style="font-size:12px;font-weight:900;letter-spacing:.01em;opacity:.72;text-transform:uppercase;">Wiadomość od organizatora</div>
          <div style="line-height:1.45;">${escapeHtml(bodyText)}</div>
          ${metaLabel ? `<div style="font-size:11px;opacity:.65;text-align:right;">${metaLabel.includes("✓✓") ? escapeHtml(metaLabel).replace("✓✓", '<span style="color:#6EE7FF;font-weight:700;">✓✓</span>') : metaLabel.includes("✓") ? escapeHtml(metaLabel).replace("✓", '<span style="opacity:0.4;">✓</span>') : escapeHtml(metaLabel)}</div>` : ``}
        </div>
      `;
    } else {
      bubble.innerHTML = `
        <div style="display:flex;flex-direction:column;gap:6px;">
          <div style="line-height:1.45;">${escapeHtml(rawText)}</div>
          ${metaLabel ? `<div style="font-size:11px;opacity:.65;text-align:right;">${metaLabel.includes("✓✓") ? escapeHtml(metaLabel).replace("✓✓", '<span style="color:#6EE7FF;font-weight:700;">✓✓</span>') : metaLabel.includes("✓") ? escapeHtml(metaLabel).replace("✓", '<span style="opacity:0.4;">✓</span>') : escapeHtml(metaLabel)}</div>` : ``}
        </div>
      `;
    }

    if (from === "me") {
      row.appendChild(bubble);
      row.appendChild(avatar);
    } else {
      row.appendChild(avatar);
      row.appendChild(bubble);
    }

    box.appendChild(row);
  };

  try {
    const data = await apiFetch(`/messages/private/${App.selectedChatUserId}`);
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];
    const unreadAtOpen = Math.max(0, Number(App.chatUnreadAtOpen || 0));
    const incomingTotal = items.filter(m => String(m.sender_user_id) !== String(App.currentUserId)).length;
    const dividerIncomingIndex = unreadAtOpen > 0 ? Math.max(0, incomingTotal - unreadAtOpen) : -1;

    box.innerHTML = "";
    let newDividerInserted = false;
    let incomingIndex = 0;

    items.forEach(m => {
      const from = String(m.sender_user_id) === String(App.currentUserId) ? "me" : "them";

      if (from === "them") {
        if (!newDividerInserted && dividerIncomingIndex >= 0 && incomingIndex === dividerIncomingIndex) {
          const divider = document.createElement("div");
          divider.style.display = "flex";
          divider.style.alignItems = "center";
          divider.style.gap = "10px";
          divider.style.margin = "18px 0 10px";
          divider.innerHTML = `
            <div style="flex:1;height:1px;background:rgba(255,255,255,.10);"></div>
            <div class="sectionSub" style="white-space:nowrap;">Nowe wiadomości</div>
            <div style="flex:1;height:1px;background:rgba(255,255,255,.10);"></div>
          `;
          box.appendChild(divider);
          newDividerInserted = true;
        }
        incomingIndex += 1;
      }

      renderMessageRow({
        from,
        text: m.content || "",
        senderUserId: m.sender_user_id,
        createdAt: m.created_at || null,
        isRead: !!m.is_read,
      });
    });

    const chat = App.chats.find(c => c.id === App.selectedChatId);
    if (chat) {
      chat.last = items.length ? (items[items.length - 1].content || "") : chat.last;
      chat.messages = items.map(m => ({
        from: String(m.sender_user_id) === String(App.currentUserId) ? "me" : "them",
        text: m.content || "",
        senderUserId: m.sender_user_id,
        createdAt: m.created_at || null,
        isRead: !!m.is_read,
      }));
    }

    markChatAsSeen(App.selectedChatId);
  } catch (err) {
    console.error("renderChatThread failed", err);

    const chat = App.chats.find(c => c.id === App.selectedChatId);
    if (!chat) return;

    box.innerHTML = "";
    chat.messages.forEach(m => {
      renderMessageRow({
        from: m.from === "me" ? "me" : "them",
        text: m.text || "",
        senderUserId: m.senderUserId || App.selectedChatUserId,
        createdAt: m.createdAt || null,
        isRead: !!m.isRead,
      });
    });
  }

  setTimeout(() => {
    box.parentElement?.scrollTo({ top: box.parentElement.scrollHeight, behavior: "smooth" });
  }, 0);
}

async function sendChat() {
  const inp = $("chatInput");
  const text = inp?.value?.trim();
  if (!text || !App.selectedChatUserId) return;

  try {
    await apiFetch("/messages/private", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recipient_user_id: Number(String(App.selectedChatUserId).replace("u", "")),
        content: text,
      }),
    });

    const chat = App.chats.find(c => c.id === App.selectedChatId);
    if (chat) chat.last = text;
    inp.value = "";

    await renderChatThread();
    renderChatList();
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wysłać wiadomości");
  }
}

function openChatMenu() {
  const chatId = App.selectedChatId;
  const isMuted = isChatMuted(chatId);

  openModal("Menu czatu", `
    <button class="btn secondary" type="button"
      onclick="setChatMuted('${chatId}', ${isMuted ? "false" : "true"}); closeModal(); renderChatList(); toast('${isMuted ? "Powiadomienia dla rozmowy zostały włączone" : "Rozmowa została wyciszona"}');">
      ${isMuted ? "Włącz powiadomienia" : "Wycisz rozmowę"}
    </button>

    <button class="btn danger mt12" type="button" onclick="blockUser(Number(String(App.selectedChatUserId).replace('u', '')))">Zablokuj</button>
  `);
}

/* ------------------------- Events -------------------------- */
function setEventsTab(tab) {
  if (tab === "nearby") tab = "for_you";
  if (tab !== "for_you" && tab !== "followed") return;
  App.eventsTab = tab;

  $("eventsTabNearby")?.classList.toggle("on", tab === "for_you");
  $("eventsTabForYou")?.classList.toggle("on", tab === "for_you");
  $("eventsTabFollowed")?.classList.toggle("on", tab === "followed");

  renderEventsList();
}

function openEvent(eventId) {
  const ev = App.events.find(e => e.id === eventId);
  if (!ev) return;
  App.selectedEventId = eventId;

  safeSetText("eventTitleTop", ev.title);
  safeSetText("evTitle", ev.title);
  safeSetText("evMeta", `${ev.city} • ${ev.where} • ${ev.when}`);

  const chips = $("evInterestChips");
  if (chips) {
    chips.innerHTML = "";
    chips.appendChild(makeChip(`#${ev.interest}`, null));
  }

  safeSetText("evDesc", ev.desc);

  const organizerName = ev.organizer?.name || "Organizator";
  const organizerMeta = [
    getPartnerCategoryLabel(ev.organizer?.category || ""),
    ev.city || ""
  ].filter(Boolean).join(" • ") || "Organizator wydarzenia";

  safeSetText("evOrganizerName", organizerName);
  safeSetText("evOrganizerMeta", organizerMeta);

  const organizerLogo = $("evOrganizerLogo");
  if (organizerLogo) {
    const src = ev.organizer?.logoUrl || "";
    organizerLogo.innerHTML = src
      ? `<img src="${String(src).startsWith("http") ? src : `${API_BASE_URL}${src}`}" alt="${organizerName}" style="width:100%;height:100%;object-fit:cover;" />`
      : "🏢";
  }

  const capacityLine = $("evCapacityLine");
  const capacityAlert = $("evCapacityAlert");
  const capacityCopy = getEventCapacityCopy(ev);

  if (capacityLine) capacityLine.textContent = capacityCopy.line;
  if (capacityAlert) {
    if (capacityCopy.alert) {
      capacityAlert.style.display = "block";
      capacityAlert.textContent = capacityCopy.alert;
    } else {
      capacityAlert.style.display = "none";
      capacityAlert.textContent = "";
    }
  }

  // ticket display
  const typeEl = $("evTicketType");
  const pricePill = $("evTicketPricePill");
  const lineEl = $("evTicketPriceLine");
  const linkEl = $("evTicketLink");

  const legalBoxEl = $("evTicketLegalBox");

  if (ev.paidMode === "free") {
    if (typeEl) typeEl.textContent = "Bezpłatne";
    if (pricePill) pricePill.textContent = "0 zł";
    if (lineEl) lineEl.textContent = "";
    if (linkEl) {
      linkEl.href = "#";
      linkEl.style.display = "none";
    }
    if (legalBoxEl) legalBoxEl.style.display = "none";
  } else if (ev.paidMode === "paid_fixed") {
    if (typeEl) typeEl.textContent = "Płatne — cena stała";
    if (pricePill) pricePill.textContent = `${ev.price} zł`;
    if (lineEl) lineEl.textContent = `Cena: ${ev.price} zł (zakup / rezerwacja poza aplikacją).`;
    if (linkEl) {
      linkEl.href = ev.ticketLink || "#";
      linkEl.style.display = "";
    }
    if (legalBoxEl) legalBoxEl.style.display = "";
  } else {
    if (typeEl) typeEl.textContent = "Płatne — przedział";
    if (pricePill) pricePill.textContent = `${ev.priceFrom}–${ev.priceTo} zł`;
    if (lineEl) lineEl.textContent = `Cena: ${ev.priceFrom}–${ev.priceTo} zł (zakup / rezerwacja poza aplikacją).`;
    if (linkEl) {
      linkEl.href = ev.ticketLink || "#";
      linkEl.style.display = "";
    }
    if (legalBoxEl) legalBoxEl.style.display = "";
  }

  // Badge (plan)
  safeSetText("evBadge", App.user.plan.toUpperCase());

  go("S7B_EVENT_DETAIL");
  syncEventDetailButtons();
}

async function toggleSaveEvent() {
  const ev = App.events.find(e => e.id === App.selectedEventId);
  if (!ev) return;

  try {
    if (ev.saved) {
      const res = await apiFetch(`/events/${ev.id}/save`, {
        method: "DELETE",
      });
      if (!res?.success) {
        toast(res?.error?.message || "Nie udało się usunąć z obserwowanych");
        return;
      }
      toast("Usunięto z obserwowanych");
    } else {
      const res = await apiFetch(`/events/${ev.id}/save`, {
        method: "POST",
      });
      if (!res?.success) {
        toast(res?.error?.message || "Nie udało się dodać do obserwowanych");
        return;
      }
      toast("Dodano do obserwowanych");
    }

    await loadEvents();

    const fresh = App.events.find(e => String(e.id) === String(App.selectedEventId));
    if (fresh) {
      openEvent(fresh.id);
      syncEventDetailButtons();
    } else {
      renderEventsList();
      renderNearby();
    }
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zmienić obserwowanych wydarzeń");
  }
}

async function toggleInterestedEvent() {
  const ev = App.events.find(e => e.id === App.selectedEventId);
  if (!ev) return;

  try {
    if (ev.interested) {
      const res = await apiFetch(`/events/${ev.id}/join`, {
        method: "DELETE",
      });
      if (!res?.success) {
        toast(res?.error?.message || "Nie udało się wycofać zapisu");
        return;
      }
      toast("Wycofano zapis na wydarzenie");
    } else {
      const res = await apiFetch(`/events/${ev.id}/join`, {
        method: "POST",
      });
      if (!res?.success) {
        toast(res?.error?.message || "Nie udało się zapisać na wydarzenie");
        return;
      }
      toast("Jesteś zapisany na wydarzenie");
    }

    await loadEvents();

    const fresh = App.events.find(e => String(e.id) === String(App.selectedEventId));
    if (fresh) {
      openEvent(fresh.id);
      syncEventDetailButtons();
    } else {
      renderEventsList();
      renderNearby();
    }
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zmienić zapisu na wydarzenie");
  }
}

function openShare() {
  openModal("Udostępnij", `
    <div class="tStrong">Udostępnianie</div>
    <div class="sectionSub mt10">W wersji produkcyjnej: deep link / share sheet.</div>
    <button class="btn mt16" type="button" onclick="toast('Skopiowano link '); closeModal();">Skopiuj link</button>
  `);
}

function openEventMenu() {
  openModal("Opcje wydarzenia", `
    <button class="btn secondary" type="button" onclick="toast('Zgłaszanie treści będzie dostępne w kolejnej aktualizacji.'); closeModal();">Zgłoś</button>
    <button class="btn danger mt12" type="button" onclick="toast('Ukrywanie wydarzeń będzie dostępne w kolejnej aktualizacji.'); closeModal();">Ukryj</button>
  `);
}

function openEventOrganizerProfile() {
  const ev = App.events.find(e => e.id === App.selectedEventId);
  if (!ev || !ev.organizer?.id) return;

  const organizerId = String(ev.organizer.id);
  const organizerName = ev.organizer.name || "Organizator";

  let chat = App.chats.find(c => String(c.with?.id) === organizerId);
  if (!chat) {
    chat = {
      id: `c_org_${organizerId}`,
      with: {
        id: organizerId,
        nick: organizerName,
        role: "partner",
        company: organizerName,
        city: ev.organizer?.city || ev.city || "",
        category: ev.organizer?.category || ev.category || "",
        bio: ev.organizer?.bio || "",
        avatarUrl: ev.organizer?.logoUrl || "",
        logoUrl: ev.organizer?.logoUrl || "",
        emoji: "🏢",
      },
      last: "",
      unread: 0,
      messages: [],
    };
    App.chats.unshift(chat);
  } else {
    chat.with = {
      ...(chat.with || {}),
      id: organizerId,
      nick: chat.with?.nick || organizerName,
      role: "partner",
      company: chat.with?.company || organizerName,
      city: chat.with?.city || ev.city || "",
      category: chat.with?.category || ev.organizer?.category || ev.category || "",
      bio: chat.with?.bio || ev.organizer?.bio || "",
      avatarUrl: chat.with?.avatarUrl || ev.organizer?.logoUrl || "",
      logoUrl: chat.with?.logoUrl || ev.organizer?.logoUrl || chat.with?.avatarUrl || "",
      emoji: chat.with?.emoji || "🏢",
    };
  }

  openPerson(organizerId);
}

function openChatWithOrganizer() {
  const ev = App.events.find(e => e.id === App.selectedEventId);
  if (!ev || !ev.organizer?.id) return;

  const organizerId = String(ev.organizer.id);
  const organizerName = ev.organizer.name || "Organizator";

  let chat = App.chats.find(c => String(c.with?.id) === organizerId);
  if (!chat) {
    chat = {
      id: `c_org_${organizerId}`,
      with: {
        id: organizerId,
        nick: organizerName,
        role: "partner",
        company: organizerName,
        city: ev.city || "",
        category: ev.organizer?.category || ev.category || "",
        bio: ev.organizer?.bio || "",
        avatarUrl: ev.organizer?.logoUrl || "",
        logoUrl: ev.organizer?.logoUrl || "",
        emoji: "🏢",
      },
      last: "",
      unread: 0,
      messages: [],
    };
    App.chats.unshift(chat);
  } else {
    chat.with = {
      ...(chat.with || {}),
      id: organizerId,
      nick: chat.with?.nick || organizerName,
      role: "partner",
      company: chat.with?.company || organizerName,
      city: chat.with?.city || ev.city || "",
      category: chat.with?.category || ev.organizer?.category || ev.category || "",
      bio: chat.with?.bio || ev.organizer?.bio || "",
      avatarUrl: chat.with?.avatarUrl || ev.organizer?.logoUrl || "",
      logoUrl: chat.with?.logoUrl || ev.organizer?.logoUrl || chat.with?.avatarUrl || "",
      emoji: chat.with?.emoji || "🏢",
    };
  }

  App.selectedChatId = chat.id;
  App.selectedChatUserId = organizerId;
  openChat(chat.id);
}

/* ------------------------- Groups -------------------------- */
async function openGroup(groupId) {
  const allGroups = [...(App.myGroups || []), ...(App.groups || [])];
  const g = allGroups.find(x => String(x.id) === String(groupId));
  if (!g) return;
  App.selectedGroupId = groupId;

  const inviteBtn = $("btnInviteFriendToGroup");
  const inviteHook = $("groupInviteHook");
  const canInvite = canInviteFriendsToGroup();
  const inGroup = isUserInGroup(groupId);

  if (inviteBtn) {
    inviteBtn.disabled = !canInvite;
    inviteBtn.textContent = canInvite ? "Dodaj znajomego" : "Dostępne od PREMIUM";
  }

  if (inviteHook) {
    inviteHook.style.opacity = canInvite ? "1" : "0.72";
  }

  safeSetText("groupTitle", g.title);
  safeSetText("groupTagline", g.interestTag ? `#${g.interestTag}` : "");

  const joinCta = $("groupJoinCta");
  const input = $("groupInput");
  const inputDock = $("groupInputDock");

  if (joinCta) {
    joinCta.innerHTML = "";
  }

  if (inputDock) {
    inputDock.innerHTML = inGroup
      ? `
          <input id="groupInput" type="text" placeholder="Napisz w grupie." />
          <button class="btn small" id="groupSendBtn" type="button" onclick="sendGroup()" aria-label="Wyślij wiadomość do grupy">➜</button>
        `
      : `
          <button class="btn" type="button" style="width:100%;" onclick="joinGroup('${groupId}')">
            Dołącz do grupy
          </button>
        `;
  }

  const currentInput = $("groupInput");
  const currentSendBtn = $("groupSendBtn");

  if (currentInput) {
    currentInput.disabled = false;
    currentInput.value = "";
    currentInput.placeholder = "Napisz w grupie.";
  }
  if (currentSendBtn) {
    currentSendBtn.disabled = false;
    currentSendBtn.style.opacity = "1";
    currentSendBtn.style.cursor = "pointer";
  }

  bindMessageInputs();

  try {
    const peopleRes = await apiFetch(`/groups/${groupId}/people`);
    const peopleData = peopleRes?.data || peopleRes || {};
    window._lastGroupPeople = {
      members: Array.isArray(peopleData.members) ? peopleData.members : [],
      invited: Array.isArray(peopleData.invited) ? peopleData.invited : [],
    };
  } catch (err) {
    console.error("group people preload failed", err);
  }

  // messages
  const box = $("groupBubbles");
  if (box) {
    if (!inGroup) {
      box.innerHTML = `
        <div style="padding:16px;">
          <div class="tStrong">${g.title}</div>
          <div class="sectionSub" style="margin-top:6px;">
            ${g.desc || "Grupa oparta na wspólnych zainteresowaniach."}
          </div>
          <div class="tMuted" style="margin-top:12px;">
            Dołącz do grupy, aby zobaczyć rozmowę i napisać wiadomość.
          </div>
        `;
      go("S8B_GROUP_THREAD");
      return;
    }

    box.innerHTML = '<div class="tMuted" style="padding:16px; text-align:center;">Ładowanie wiadomości...</div>';
    const seenAt = parseUslyTimestamp(readGroupSeenMap()[String(groupId)]);

    try {
      const data = await apiFetch(`/messages/group/${groupId}`);
      const items = Array.isArray(data?.data?.items) ? data.data.items : [];

      if (!items.length) {
        box.innerHTML = `
          <div class="tMuted" style="padding:16px; text-align:center;">
            Nie ma jeszcze wiadomości w tej grupie. Napisz jako pierwsza osoba.
          </div>
        `;
      } else {
        let newDividerInserted = false;
        box.innerHTML = items.map(m => {
          const from = String(m.sender_user_id) === String(App.currentUserId) ? "me" : "them";
          const person = resolvePersonById(m.sender_user_id);
          const ts = parseUslyTimestamp(m.created_at);
          const isNewForCurrentUser = !newDividerInserted && from !== "me" && ts > seenAt;
          const timeLabel = ts
            ? new Date(ts).toLocaleString("pl-PL", {
                day: "2-digit",
                month: "2-digit",
                hour: "2-digit",
                minute: "2-digit",
              })
            : "";

          const avatarHtml = person?.avatarUrl
            ? `<img src="${String(person.avatarUrl).startsWith("http") ? person.avatarUrl : `${API_BASE_URL}${person.avatarUrl}`}" alt="${escapeHtml(person.nick || "Użytkownik")}" style="width:100%;height:100%;object-fit:cover;border-radius:999px;" />`
            : escapeHtml(person?.emoji || "🙂");

          const avatarButton = `
            <button
              type="button"
              onclick="openPerson('${String(m.sender_user_id)}')"
              title="Otwórz profil"
              style="width:32px;height:32px;min-width:32px;border-radius:999px;border:${from === "me" ? "0" : "1px solid rgba(16,24,40,0.08)"};padding:0;display:inline-flex;align-items:center;justify-content:center;background:#f2f4f7;overflow:hidden;box-shadow:${from === "me" ? "none" : "0 2px 8px rgba(16,24,40,0.08)"};cursor:pointer;flex-shrink:0;"
            >${avatarHtml}</button>
          `;

          const senderLabel = from === "me" ? "Ty" : escapeHtml(person?.nick || `Użytkownik #${String(m.sender_user_id)}`);
          const dividerHtml = isNewForCurrentUser
            ? `<div style="display:flex;align-items:center;gap:10px;margin:18px 0 10px;"><div style="flex:1;height:1px;background:rgba(255,255,255,.10);"></div><div class="sectionSub" style="white-space:nowrap;">Nowe wiadomości</div><div style="flex:1;height:1px;background:rgba(255,255,255,.10);"></div></div>`
            : ``;

          if (isNewForCurrentUser) newDividerInserted = true;

          return `
            ${dividerHtml}
            <div style="display:flex; align-items:flex-end; gap:10px; justify-content:${from === "me" ? "flex-end" : "flex-start"}; margin:10px 0;">
              ${from === "me" ? "" : avatarButton}
              <div class="bubble ${from === "me" ? "me" : "them"}" style="max-width:78%; word-break:break-word;">
                <div style="font-size:12px; opacity:.72; margin-bottom:4px; font-weight:800;">${senderLabel}</div>
                <div style="line-height:1.45;">${escapeHtml(m.content || "")}</div>
                ${timeLabel ? `<div style="font-size:11px; opacity:.65; text-align:right; margin-top:6px;">${escapeHtml(timeLabel)}</div>` : ``}
              </div>
              ${from === "me" ? avatarButton : ""}
            </div>
          `;
        }).join("");
        markGroupAsSeen(groupId);
      }
    } catch (err) {
      console.error("load group messages failed", err);
      box.innerHTML = '<div class="tMuted" style="padding:16px; text-align:center;">Nie udało się załadować wiadomości grupy.</div>';
    }
  }

  go("S8B_GROUP_THREAD");
}


function bindMessageInputs() {
  const chatInput = $("chatInput");
  const chatSendBtn = $("chatSendBtn");
  if (chatSendBtn && !chatSendBtn.dataset.bound) {
    chatSendBtn.addEventListener("click", sendChat);
    chatSendBtn.dataset.bound = "1";
  }
  if (chatInput && !chatInput.dataset.bound) {
    chatInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        sendChat();
      }
    });
    chatInput.dataset.bound = "1";
  }

  const groupInput = $("groupInput");
  const groupSendBtn = $("groupSendBtn");
  if (groupSendBtn && !groupSendBtn.dataset.bound) {
    groupSendBtn.addEventListener("click", sendGroup);
    groupSendBtn.dataset.bound = "1";
  }
  if (groupInput && !groupInput.dataset.bound) {
    groupInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        sendGroup();
      }
    });
    groupInput.dataset.bound = "1";
  }
}

async function sendGroup() {
  const groupId = App.selectedGroupId;
  if (!isUserInGroup(groupId)) {
    toast("Dołącz do grupy, aby pisać wiadomości");
    return;
  }

  const inp = $("groupInput");
  const text = inp?.value?.trim();
  if (!text) return;

  try {
    const res = await apiFetch("/messages/group", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        group_id: Number(groupId),
        content: text,
      }),
    });

    if (!res?.success) {
      toast(res?.error?.message || "Nie udało się wysłać wiadomości");
      return;
    }

    if (inp) inp.value = "";
    await openGroup(groupId);
  } catch (err) {
    console.error("sendGroup failed", err);
    toast(err?.userMessage || "Nie udało się wysłać wiadomości");
  }
}


/* ------------------------- Groups API -------------------------- */
async function joinGroup(groupId) {
  try {
    if (!canJoinMoreGroups()) {
      toast("Limit grup dla Twojego planu został osiągnięty");
      return;
    }

    const res = await apiFetch(`/groups/${groupId}/join`, {
      method: "POST"
    });

    if (res?.success) {
      await loadMyGroups();
      toast("Dołączono do grupy");
      renderAll();
      openGroup(groupId);
    } else {
      toast("Nie udało się dołączyć do grupy");
    }

  } catch (err) {
    console.error("joinGroup failed", err);
    toast("Błąd dołączania do grupy");
  }
}


async function closeGroup(groupId) {
  try {
    const res = await apiFetch(`/groups/${groupId}/close`, {
      method: "POST"
    });

    if (res?.success) {
      await loadMyGroups();
      toast("Grupa została zamknięta");
      App.selectedGroupId = null;
      renderAll();
    } else {
      toast("Nie udało się zamknąć grupy");
    }

  } catch (err) {
    console.error("closeGroup failed", err);
    toast(err?.userMessage || "Błąd zamykania grupy");
  }
}


async function leaveGroup(groupId) {
  try {

    const res = await apiFetch(`/groups/${groupId}/leave`, {
      method: "POST"
    });

    if (res?.success) {
      await loadMyGroups();
      toast("Opuszczono grupę");
      renderAll();
    } else {
      toast("Nie udało się opuścić grupy");
    }

  } catch (err) {
    console.error("leaveGroup failed", err);
    toast(err?.userMessage || "Błąd opuszczania grupy");
  }
}
function openGroupMenu() {
  const groupId = App.selectedGroupId;
  const inGroup = isUserInGroup(groupId);
  const canInvite = canInviteFriendsToGroup();
  const allGroups = [...(App.myGroups || []), ...(App.groups || [])];
  const g = allGroups.find(x => String(x.id) === String(groupId));
  const isCreator = !!g?.isCreator;
  const isMuted = isGroupMuted(groupId);

  openModal("Menu grupy", `
    <button class="btn secondary" type="button" onclick="setGroupMuted('${groupId}', ${isMuted ? "false" : "true"}); closeModal(); renderGroups(); refreshGroupBadgeCount(); toast('${isMuted ? "Powiadomienia dla grupy zostały włączone" : "Grupa została wyciszona"}');">
      ${isMuted ? "Włącz powiadomienia" : "Wycisz grupę"}
    </button>

    <button class="btn secondary mt12" type="button"
             onclick="closeModal(); openGroupPeopleScreen();">
             Ludzie w grupie
           </button>

    ${
      inGroup && isCreator
        ? `<button class="btn danger mt12" type="button"
             onclick="closeGroup('${groupId}'); closeModal();">
             Zamknij grupę
           </button>`
        : inGroup
          ? `<button class="btn danger mt12" type="button"
               onclick="leaveGroup('${groupId}'); closeModal();">
               Opuść grupę
             </button>`
          : ``
    }
  `);
}

// Punkt 9: dodanie znajomego do grupy, nawet jeśli jej nie widzi

async function inviteFriendToSelectedGroup(userId) {
  const groupId = App.selectedGroupId;
  if (!groupId || !userId) {
    toast("Brak danych zaproszenia");
    return;
  }

  try {
    const res = await apiFetch(`/groups/${groupId}/invite`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ invitee_user_id: Number(userId) }),
    });

    if (res?.success) {
      toast("Zaproszenie do grupy zostało wysłane");
      await refreshProfileRelations();
      if (App.currentView === "S12_NOTIFICATIONS") await renderNotifications();
      closeModal();
    } else {
      toast("Nie udało się wysłać zaproszenia do grupy");
    }
  } catch (err) {
    console.error("inviteFriendToSelectedGroup failed", err);
    toast(err?.userMessage || "Nie udało się wysłać zaproszenia do grupy");
  }
}


async function openGroupPeopleScreen() {
  App.groupInviteTab = App.groupInviteTab || "invite";
  const canInvite = canInviteFriendsToGroup();
  if (!canInvite && App.groupInviteTab === "invite") {
    App.groupInviteTab = "members";
  }

  if (!window._lastFriendsList || window._lastFriendsList.length === 0) {
    try {
      await refreshProfileRelations();
    } catch (_) {}
  }

  const allGroups = [...(App.myGroups || []), ...(App.groups || [])];
  const g = allGroups.find(x => String(x.id) === String(App.selectedGroupId));
  if (!g) return;

  safeSetText("groupPeopleTitle", "Ludzie w grupie");
  safeSetText("groupPeopleTagline", g.title ? `${g.title}${g.interestTag ? ` • #${g.interestTag}` : ""}` : (g.interestTag ? `#${g.interestTag}` : ""));

  let groupPeople = { members: [], invited: [] };
  try {
    const peopleRes = await apiFetch(`/groups/${g.id}/people`);
    const peopleData = peopleRes?.data || peopleRes || {};
    groupPeople = {
      members: Array.isArray(peopleData.members) ? peopleData.members : [],
      invited: Array.isArray(peopleData.invited) ? peopleData.invited : [],
    };
    window._lastGroupPeople = groupPeople;
  } catch (err) {
    console.error("group people load failed", err);
  }

  const allFriends = (window._lastFriendsList || []);
  const memberIds = new Set((groupPeople.members || []).map(x => String(x.id)));
  const invitedIds = new Set((groupPeople.invited || []).map(x => String(x.id)));
  const myId = String(App.currentUserId || "");
  const tag = String(g.interestTag || "").toLowerCase();

  const similarFriends = allFriends
    .filter(f => {
      const id = String(f.id || "");
      if (!Array.isArray(f.interests)) return false;
      if (!f.interests.map(x => x.toLowerCase()).includes(tag)) return false;
      if (!id || id === myId) return false;
      if (memberIds.has(id)) return false;
      if (invitedIds.has(id)) return false;
      return true;
    })
    .slice(0, 24);

  const members = Array.isArray(groupPeople.members) ? [...groupPeople.members] : [];
  members.sort((a, b) => {
    if (!!a.is_founder !== !!b.is_founder) return a.is_founder ? -1 : 1;
    return String(a.nick || "").localeCompare(String(b.nick || ""), "pl", { sensitivity: "base" });
  });

  const invited = Array.isArray(groupPeople.invited) ? [...groupPeople.invited] : [];
  invited.sort((a, b) => String(a.nick || "").localeCompare(String(b.nick || ""), "pl", { sensitivity: "base" }));

  const inviteHtml = similarFriends.map(p => `
        <div class="listItem groupPeopleRow" style="margin-bottom:10px; cursor:default;">
          <div class="groupPeopleMain">
            <div class="listAvatar">${p.avatarUrl ? `<img src="${String(p.avatarUrl).startsWith("http") ? p.avatarUrl : `${API_BASE_URL}${p.avatarUrl}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : p.emoji}</div>
            <div class="groupPeopleText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">Wspólne: ${commonInterests(p).slice(0,3).map(x => `#${x}`).join(" ")}</div>
            </div>
          </div>
          <div class="groupPeopleAction">
            <button class="btn small" type="button" onclick="inviteFriendToSelectedGroup('${p.id}')">Zaproś</button>
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak osób do zaproszenia.</div>';

  const membersHtml = members.map(p => `
        <div class="listItem groupPeopleRow" style="margin-bottom:10px; cursor:pointer;" onclick="${String(p.id) === myId ? "" : `openPerson('${String(p.id)}')`}">
          <div class="groupPeopleMain">
            <div class="listAvatar">${p.avatar_url ? `<img src="${String(p.avatar_url).startsWith("http") ? p.avatar_url : `${API_BASE_URL}${p.avatar_url}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : "🙂"}</div>
            <div class="groupPeopleText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">${p.city || "Grupowicz w USLY"}</div>
            </div>
          </div>
          <div class="groupPeopleAction">
            ${p.is_founder
              ? `<button class="btn secondary small" type="button" disabled>Założyciel</button>`
              : (String(p.id) === myId
                  ? `<button class="btn secondary small" type="button" disabled>Twój profil</button>`
                  : `<button class="btn secondary small" type="button" onclick="event.stopPropagation(); openPerson('${String(p.id)}')">Zobacz profil</button>`
                )
            }
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak grupowiczów.</div>';

  const invitedHtml = invited.map(p => `
        <div class="listItem groupPeopleRow" style="margin-bottom:10px; cursor:pointer;" onclick="openPerson('${String(p.id)}')">
          <div class="groupPeopleMain">
            <div class="listAvatar">${p.avatar_url ? `<img src="${String(p.avatar_url).startsWith("http") ? p.avatar_url : `${API_BASE_URL}${p.avatar_url}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : "🙂"}</div>
            <div class="groupPeopleText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">${p.city || "Zaproszenie oczekuje"}</div>
            </div>
          </div>
          <div class="groupPeopleAction">
            <button class="btn secondary small" type="button" onclick="event.stopPropagation(); openPerson('${String(p.id)}')">Zobacz profil</button>
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak oczekujących zaproszeń.</div>';

  const activeHtml = App.groupInviteTab === "members"
    ? membersHtml
    : (App.groupInviteTab === "invited" ? invitedHtml : inviteHtml);

  const screen = $("groupPeopleScreen");
  if (screen) {
    screen.innerHTML = `
      <div class="groupInviteModal">
        <div class="sectionTitle">Ludzie w grupie</div>
        <div class="sectionSub mt8">
          Zarządzaj zaproszeniami i sprawdź, kto już jest w grupie.
        </div>
        ${canInvite ? "" : `<div class="tMuted mt8">Zapraszanie do grup jest dostępne od planu PREMIUM.</div>`}
        <div class="segmented mt12">
          <button class="segBtn ${App.groupInviteTab === "invite" ? "on" : ""}" type="button" ${canInvite ? `onclick="App.groupInviteTab='invite'; openGroupPeopleScreen()"` : "disabled aria-disabled='true'"}>Do zaproszenia</button>
          <button class="segBtn ${App.groupInviteTab === "members" ? "on" : ""}" type="button" onclick="App.groupInviteTab='members'; openGroupPeopleScreen()">Grupowicze</button>
          <button class="segBtn ${App.groupInviteTab === "invited" ? "on" : ""}" type="button" onclick="App.groupInviteTab='invited'; openGroupPeopleScreen()">Zaproszeni</button>
        </div>
        <div class="mt16">
          ${activeHtml}
        </div>
      </div>
    `;
  }

  go("S8C_GROUP_PEOPLE");
}

async function openInviteFriendToGroup() {
  App.groupInviteTab = App.groupInviteTab || "invite";

  if (!window._lastFriendsList || window._lastFriendsList.length === 0) {
    try {
      await refreshProfileRelations();
    } catch (_) {}
  }

  const allGroups = [...(App.myGroups || []), ...(App.groups || [])];
  const g = allGroups.find(x => String(x.id) === String(App.selectedGroupId));
  if (!g) return;

  if (!canInviteFriendsToGroup()) {
    toast("Dodawanie znajomych do grup jest dostępne od planu PREMIUM");
    return;
  }

  let groupPeople = { members: [], invited: [] };
  try {
    const peopleRes = await apiFetch(`/groups/${g.id}/people`);
    const peopleData = peopleRes?.data || peopleRes || {};
    groupPeople = {
      members: Array.isArray(peopleData.members) ? peopleData.members : [],
      invited: Array.isArray(peopleData.invited) ? peopleData.invited : [],
    };
    window._lastGroupPeople = groupPeople;
  } catch (err) {
    console.error("group people load failed", err);
  }

  const allFriends = (window._lastFriendsList || []);
  const outgoingGroupInvites = Array.isArray(window._lastOutgoingGroupInvites) ? window._lastOutgoingGroupInvites : [];
  const pendingInviteUserIds = new Set(
    outgoingGroupInvites
      .filter(inv => String(inv?.group?.id || "") === String(g.id))
      .map(inv => String(inv?.user?.id || ""))
      .filter(Boolean)
  );
  const memberIds = new Set((groupPeople.members || []).map(x => String(x.id)));
  const invitedIds = new Set((groupPeople.invited || []).map(x => String(x.id)));
  const myId = String(App.user?.id || "");
  const tag = String(g.interestTag || "").toLowerCase();

  const similarFriends = allFriends
    .filter(f => {
      const id = String(f.id || "");
      if (!Array.isArray(f.interests)) return false;
      if (!f.interests.map(x => x.toLowerCase()).includes(tag)) return false;
      if (!id || id === myId) return false;
      if (memberIds.has(id)) return false;
      if (invitedIds.has(id)) return false;
      return true;
    })
    .slice(0, 6);

  const members = Array.isArray(groupPeople.members) ? [...groupPeople.members] : [];
  members.sort((a, b) => {
    if (!!a.is_founder !== !!b.is_founder) return a.is_founder ? -1 : 1;
    return String(a.nick || "").localeCompare(String(b.nick || ""), "pl", { sensitivity: "base" });
  });

  const invited = Array.isArray(groupPeople.invited) ? [...groupPeople.invited] : [];
  invited.sort((a, b) => String(a.nick || "").localeCompare(String(b.nick || ""), "pl", { sensitivity: "base" }));

  const inviteHtml = similarFriends.map(p => `
        <div class="listItem groupInviteCard" style="margin-bottom:10px; cursor:default;">
          <div class="groupInviteCardTop">
            <div class="listAvatar">${p.avatarUrl ? `<img src="${String(p.avatarUrl).startsWith("http") ? p.avatarUrl : `${API_BASE_URL}${p.avatarUrl}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : p.emoji}</div>
            <div class="groupInviteCardText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">Wspólne: ${commonInterests(p).slice(0,3).map(x => `#${x}`).join(" ")}</div>
            </div>
          </div>
          <div class="groupInviteCardAction">
            <button class="btn small" type="button" onclick="inviteFriendToSelectedGroup('${p.id}')">Dodaj</button>
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak osób do zaproszenia.</div>';

  const membersHtml = members.map(p => `
        <div class="listItem groupInviteCard" style="margin-bottom:10px; cursor:pointer;" onclick="openChatParticipantProfile('${String(p.id)}'); closeModal();">
          <div class="groupInviteCardTop">
            <div class="listAvatar">${p.avatar_url ? `<img src="${String(p.avatar_url).startsWith("http") ? p.avatar_url : `${API_BASE_URL}${p.avatar_url}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : "🙂"}</div>
            <div class="groupInviteCardText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">${p.city || "Grupowicz w USLY"}</div>
            </div>
          </div>
          <div class="groupInviteCardAction">
            ${p.is_founder
              ? `<button class="btn secondary small" type="button" disabled>Założyciel</button>`
              : `<button class="btn secondary small" type="button">Zobacz profil</button>`
            }
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak grupowiczów.</div>';

  const invitedHtml = invited.map(p => `
        <div class="listItem groupInviteCard" style="margin-bottom:10px; cursor:default;">
          <div class="groupInviteCardTop">
            <div class="listAvatar">${p.avatar_url ? `<img src="${String(p.avatar_url).startsWith("http") ? p.avatar_url : `${API_BASE_URL}${p.avatar_url}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : "🙂"}</div>
            <div class="groupInviteCardText">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">${p.city || "Zaproszenie oczekuje"}</div>
            </div>
          </div>
          <div class="groupInviteCardAction">
            <button class="btn secondary small" type="button" disabled>Zaproszeni</button>
          </div>
        </div>
      `).join("") || '<div class="tMuted">Brak oczekujących zaproszeń.</div>';

  const activeHtml = App.groupInviteTab === "members"
    ? membersHtml
    : (App.groupInviteTab === "invited" ? invitedHtml : inviteHtml);

  openModal("Dodaj znajomego do grupy", `
    <div class="groupInviteModal">
      <div class="tStrong">Wybierz znajomego</div>
    <div class="sectionSub mt10">
      Wybierz znajomego, którego chcesz zaprosić do tej grupy.
    </div>
    <div class="segmented mt12">
      <button class="segBtn ${App.groupInviteTab === "invite" ? "on" : ""}" type="button" onclick="App.groupInviteTab='invite'; openInviteFriendToGroup()">Do zaproszenia</button>
      <button class="segBtn ${App.groupInviteTab === "members" ? "on" : ""}" type="button" onclick="App.groupInviteTab='members'; openInviteFriendToGroup()">Grupowicze</button>
      <button class="segBtn ${App.groupInviteTab === "invited" ? "on" : ""}" type="button" onclick="App.groupInviteTab='invited'; openInviteFriendToGroup()">Zaproszeni</button>
    </div>
    <div class="mt16">
      ${activeHtml}
    </div>
    </div>
  `);
}

/* ------------------------- Organizer: create / events list -------------------------- */
function getPartnerEventSubmitBtn() {
  return document.querySelector('#S9_PARTNER_CREATE button[onclick="publishPartnerEvent()"]');
}

function syncPartnerPricingFields() {
  const paidMode = $("pePaidMode")?.value || "free";

  const priceInput = $("pePrice");
  const priceBox = priceInput?.parentElement;

  const priceFromInput = $("pePriceFrom");
  const priceFromBox = priceFromInput?.parentElement;

  const priceToInput = $("pePriceTo");
  const priceToLabel = priceToInput?.previousElementSibling;
  const ticketInput = $("peTicketLink");
  const ticketLabel = ticketInput?.previousElementSibling;

  const show = (el, display = "") => { if (el) el.style.display = display; };
  const hide = (el) => { if (el) el.style.display = "none"; };

  if (paidMode === "free") {
    hide(priceBox);
    hide(priceFromBox);
    hide(priceToLabel);
    hide(priceToInput);
    hide(ticketLabel);
    hide(ticketInput);

    if (priceInput) { priceInput.disabled = true; priceInput.required = false; priceInput.value = ""; }
    if (priceFromInput) { priceFromInput.disabled = true; priceFromInput.required = false; priceFromInput.value = ""; }
    if (priceToInput) { priceToInput.disabled = true; priceToInput.required = false; priceToInput.value = ""; }
    if (ticketInput) { ticketInput.disabled = true; ticketInput.required = false; ticketInput.value = ""; }
    return;
  }

  show(ticketLabel, "");
  show(ticketInput, "");
  if (ticketInput) { ticketInput.disabled = false; ticketInput.required = true; }

  if (paidMode === "paid_fixed") {
    show(priceBox, "");
    hide(priceFromBox);
    hide(priceToLabel);
    hide(priceToInput);

    if (priceInput) { priceInput.disabled = false; priceInput.required = true; }
    if (priceFromInput) { priceFromInput.disabled = true; priceFromInput.required = false; priceFromInput.value = ""; }
    if (priceToInput) { priceToInput.disabled = true; priceToInput.required = false; priceToInput.value = ""; }
    return;
  }

  hide(priceBox);
  show(priceFromBox, "");
  show(priceToLabel, "");
  show(priceToInput, "");

  if (priceInput) { priceInput.disabled = true; priceInput.required = false; priceInput.value = ""; }
  if (priceFromInput) { priceFromInput.disabled = false; priceFromInput.required = true; }
  if (priceToInput) { priceToInput.disabled = false; priceToInput.required = true; }
}

function syncPartnerCapacityFields() {
  const unlimited = $("peUnlimitedCapacity");
  const box = $("peCapacityBox");
  const input = $("peCapacity");
  if (!unlimited || !box || !input) return;

  if (unlimited.checked) {
    box.style.display = "none";
    input.disabled = true;
    input.required = false;
    input.value = "";
  } else {
    box.style.display = "block";
    input.disabled = false;
    input.required = true;
  }
}

function initPartnerPricingFields() {
  const mode = $("pePaidMode");
  if (mode && mode.dataset.bound !== "1") {
    mode.addEventListener("change", syncPartnerPricingFields);
    mode.dataset.bound = "1";
  }

  const unlimited = $("peUnlimitedCapacity");
  if (unlimited && unlimited.dataset.bound !== "1") {
    unlimited.addEventListener("change", syncPartnerCapacityFields);
    unlimited.dataset.bound = "1";
  }

  syncPartnerPricingFields();
  syncPartnerCapacityFields();
}

function syncPartnerEventSubmitBtn() {
  const btn = getPartnerEventSubmitBtn();
  const draftBtn = document.querySelector('#S9_PARTNER_CREATE button[onclick="savePartnerEventDraft()"]');
  if (!btn) return;

  if (App.partnerEventFormMode === "published_edit") {
    btn.textContent = "Zaktualizuj wydarzenie";
    if (draftBtn) draftBtn.style.display = "none";
    return;
  }

  if (App.partnerEventFormMode === "archived_edit") {
    btn.textContent = "Wznów wydarzenie";
    if (draftBtn) draftBtn.style.display = "none";
    return;
  }

  if (draftBtn) draftBtn.style.display = "";

  btn.textContent = App.selectedPartnerEventId ? "Opublikuj" : "Utwórz wydarzenie";
}

function resetPartnerEventFormMode() {
  App.selectedPartnerEventId = null;
  App.partnerEventFormMode = "create";
  syncPartnerEventSubmitBtn();
  const card = $("partnerEventParticipantsCard");
  const list = $("partnerEventParticipantsList");
  if (card) card.style.display = "none";
  if (list) list.innerHTML = "";
}

function clearPartnerEventForm() {
  resetPartnerEventFormMode();
  ["peTitle","peCity","peWhen","peWhere","peInterest","peDesc","pePrice","pePriceFrom","pePriceTo","peTicketLink","peCapacity"].forEach(id => {
    const el = $(id);
    if (el) el.value = "";
  });
  if ($("pePaidMode")) $("pePaidMode").value = "free";
  if ($("peUnlimitedCapacity")) $("peUnlimitedCapacity").checked = true;
  syncPartnerPricingFields();
  syncPartnerCapacityFields();
}

function openNewPartnerEventForm() {
  clearPartnerEventForm();
  go("S9_PARTNER_CREATE");
}

async function renderPartnerEventParticipants() {
  const card = $("partnerEventParticipantsCard");
  const list = $("partnerEventParticipantsList");
  const broadcastBox = $("partnerEventBroadcastBox");
  if (!card || !list) return;

  const rules = getPartnerPlanRules();
  if (broadcastBox) {
    broadcastBox.style.display = rules.canBroadcastParticipants ? "block" : "none";
  }

  if (!App.selectedPartnerEventId) {
    card.style.display = "none";
    list.innerHTML = "";
    return;
  }

  card.style.display = "block";
  list.innerHTML = '<div class="tMuted">Ładowanie...</div>';

  try {
    const data = await apiFetch(`/partners/events/${App.selectedPartnerEventId}/participants?limit=50`);
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    if (!items.length) {
      list.innerHTML = '<div class="tMuted">Na razie nikt się nie zapisał.</div>';
      return;
    }

    list.innerHTML = items.map(item => {
      const user = item?.user || {};
      const when = item?.signup?.created_at
        ? new Date(parseUslyTimestamp(item.signup.created_at)).toLocaleString("pl-PL")
        : "—";

      const canMessageParticipants = getPartnerPlanRules().canMessageParticipants;

      return `
        <div class="listItem">
          <div class="listTop">
            <div class="listLeft">
              <div class="listAvatar">🙂</div>
              <div style="min-width:0;">
                <div class="listTitle">${user.nick || user.email || `Użytkownik #${user.id || "?"}`}</div>
                <div class="listMeta">Zapis: ${when}</div>
              </div>
            </div>
            ${canMessageParticipants ? `
              <div class="listRight">
                <button class="btn secondary small" type="button" onclick="openPartnerParticipantMessageModal('${user.id}', '${(user.nick || user.email || '').replace(/'/g, "&apos;")}')">Napisz</button>
              </div>
            ` : ``}
          </div>
        </div>
      `;
    }).join("");
  } catch (err) {
    console.error("renderPartnerEventParticipants failed", err);
    list.innerHTML = '<div class="tMuted">Nie udało się załadować zapisanych.</div>';
  }
}

function openPartnerParticipantMessageModal(userId, userName) {
  const rules = getPartnerPlanRules();
  if (!rules.canMessageParticipants) {
    toast("Wiadomości do uczestników są dostępne od planu PRO");
    return;
  }

  openModal("Napisz do uczestnika", `
    <div class="sectionSub">Rozmowa z: <strong>${userName || "Uczestnik"}</strong></div>
    <textarea id="partnerParticipantMessageInput" class="mt12" maxlength="1000" placeholder="Napisz wiadomość..."></textarea>
    <div class="row mt16">
      <button class="btn" type="button" onclick="sendPartnerParticipantMessage('${userId}')">Wyślij</button>
      <button class="btn secondary" type="button" onclick="closeModal()">Anuluj</button>
    </div>
  `);
}

async function sendPartnerParticipantMessage(userId) {
  const input = $("partnerParticipantMessageInput");
  const text = input?.value?.trim();
  if (!text || !userId) return;

  try {
    await apiFetch("/messages/private", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recipient_user_id: Number(userId),
        content: text,
      }),
    });

    closeModal();
    toast("Wiadomość została wysłana");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wysłać wiadomości");
  }
}

async function sendPartnerBroadcastMessage() {
  const rules = getPartnerPlanRules();
  if (!rules.canBroadcastParticipants) {
    toast("Ta funkcja jest dostępna od planu PREMIUM");
    return;
  }

  const input = $("partnerEventBroadcastInput");
  const btn = $("partnerEventBroadcastSendBtn");
  const text = input?.value?.trim();
  if (!text || !App.selectedPartnerEventId) return;

  const ev = (App.partnerEvents || []).find(x => String(x.id) === String(App.selectedPartnerEventId));
  const eventLabel = ev
    ? `${ev.title || "Wydarzenie"}${ev.city ? `, ${ev.city}` : ""}`
    : "Wydarzenie";

  try {
    if (btn) btn.disabled = true;

    const data = await apiFetch(`/partners/events/${App.selectedPartnerEventId}/participants?limit=100`);
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    if (!items.length) {
      toast("Brak zapisanych uczestników");
      return;
    }

    const content = `📣 ${ev?.title || "Wydarzenie"}${ev?.city ? ` (${ev.city})` : ""}
— wiadomość od organizatora —

${text}`;
    let sent = 0;

    for (const item of items) {
      const userId = Number(item?.user?.id);
      if (!userId) continue;

      await apiFetch("/messages/private", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipient_user_id: userId,
          content,
        }),
      });
      sent += 1;
    }

    if (input) input.value = "";
    toast(sent > 0 ? `Wysłano do ${sent} uczestników` : "Brak zapisanych uczestników");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wysłać wiadomości do uczestników");
  } finally {
    if (btn) btn.disabled = false;
  }
}

function openPartnerEventParticipantsView(eventId) {
  const ev = (App.partnerEvents || []).find(x => String(x.id) === String(eventId));
  if (!ev) return;

  App.selectedPartnerEventId = ev.id;
  go("S9_PARTNER_EVENT_PARTICIPANTS");
  renderPartnerEventParticipants();

  const btn = $("partnerEventBroadcastSendBtn");
  if (btn && btn.dataset.bound !== "1") {
    btn.addEventListener("click", sendPartnerBroadcastMessage);
    btn.dataset.bound = "1";
  }
}


function openPartnerEventEditor(eventId) {
  const ev = (App.partnerEvents || []).find(x => String(x.id) === String(eventId));
  if (!ev) return;

  App.selectedPartnerEventId = ev.id;
  const eventStatus = String(ev.status || "").toLowerCase();
  App.partnerEventFormMode = eventStatus === "published"
    ? "published_edit"
    : (eventStatus === "archived" ? "archived_edit" : "draft_edit");
  syncPartnerEventSubmitBtn();

  if ($("peTitle")) $("peTitle").value = ev.title || "";
  if ($("peCity")) $("peCity").value = ev.city || "";
  if ($("peWhen")) {
    if (ev.start_at) {
      $("peWhen").value = String(ev.start_at).trim().replace(" ", "T").slice(0, 16);
    } else {
      $("peWhen").value = "";
    }
  }
  if ($("peWhere")) $("peWhere").value = ev.where || ev.location || "";
  if ($("peInterest")) $("peInterest").value = ev.interest_tag || ev.interest || "";
  if ($("peDesc")) $("peDesc").value = ev.description || "";

  const pricingTypeMap = {
    free: "free",
    paid_fixed: "paid_fixed",
    paid_range: "paid_range",
  };
  if ($("pePaidMode")) $("pePaidMode").value = pricingTypeMap[ev.pricing_type] || "free";
  if ($("pePrice")) $("pePrice").value = ev.price_fixed != null ? (ev.price_fixed / 100) : "";
  if ($("pePriceFrom")) $("pePriceFrom").value = ev.price_min != null ? (ev.price_min / 100) : "";
  if ($("pePriceTo")) $("pePriceTo").value = ev.price_max != null ? (ev.price_max / 100) : "";
  if ($("peTicketLink")) $("peTicketLink").value = ev.payment_link || "";
  if ($("peUnlimitedCapacity")) $("peUnlimitedCapacity").checked = ev.capacity == null;
  if ($("peCapacity")) $("peCapacity").value = ev.capacity != null ? ev.capacity : "";
  syncPartnerPricingFields();
  syncPartnerCapacityFields();

  toast("Otwarto wydarzenie do edycji");
  go("S9_PARTNER_CREATE");
  renderPartnerEventParticipants();
}


async function savePartnerEventDraft() {
  if (App.role !== "partner") {
    toast("To jest dostępne tylko dla organizatora");
    return;
  }

  const title = $("peTitle")?.value?.trim();
  const city = normalizeCity($("peCity")?.value);
  const when = $("peWhen")?.value?.trim();
  const where = $("peWhere")?.value?.trim();
  const interest = normalizeTag($("peInterest")?.value?.trim());
  const desc = $("peDesc")?.value?.trim();

  if (!title || !city || !when || !where || !interest) {
    toast("Aby zapisać szkic, uzupełnij: nazwa, miasto, kiedy, gdzie, hashtag");
    return;
  }

  const startAt = new Date(when);
  if (Number.isNaN(startAt.getTime())) {
    toast("Podaj poprawną datę wydarzenia");
    return;
  }

  const endAt = new Date(startAt.getTime() + 60 * 60 * 1000);

  const paidMode = $("pePaidMode")?.value || "free";
  const price = Number($("pePrice")?.value || 0);
  const priceFrom = Number($("pePriceFrom")?.value || 0);
  const priceTo = Number($("pePriceTo")?.value || 0);
  const ticketLink = $("peTicketLink")?.value?.trim() || null;
  const unlimitedCapacity = $("peUnlimitedCapacity")?.checked !== false;
  const capacityRaw = $("peCapacity")?.value?.trim() || "";
  const capacityValue = capacityRaw ? Number(capacityRaw) : 0;

  if (!unlimitedCapacity) {
    if (!Number.isInteger(capacityValue) || capacityValue < 1) {
      toast("Podaj poprawną liczbę miejsc");
      return;
    }
  }

  if (paidMode === "paid_fixed") {
    if (!ticketLink) {
      toast("Dodaj link do biletów / rezerwacji");
      return;
    }
    if (!(price > 0)) {
      toast("Podaj poprawną cenę");
      return;
    }
  }

  if (paidMode === "paid_range") {
    if (!ticketLink) {
      toast("Dodaj link do biletów / rezerwacji");
      return;
    }
    if (!(priceFrom > 0) || !(priceTo > 0)) {
      toast("Podaj poprawny zakres cen");
      return;
    }
    if (priceFrom > priceTo) {
      toast("Cena od nie może być większa niż cena do");
      return;
    }
  }

  const pricingTypeMap = {
    free: "free",
    paid_fixed: "paid_fixed",
    paid_range: "paid_range",
  };

  const payload = {
    title,
    description: desc || "",
    city,
    where,
    interest_tag: interest,
    start_at: toLocalApiDateTime(when),
    end_at: addHourToLocalDateTime(when),
    pricing_type: pricingTypeMap[paidMode] || "free",
    payment_link: ticketLink,
    capacity: unlimitedCapacity ? null : capacityValue,
  };

  if (payload.pricing_type === "paid_fixed") {
    payload.price_fixed = Math.round(price * 100);
  } else if (payload.pricing_type === "paid_range") {
    payload.price_min = Math.round(priceFrom * 100);
    payload.price_max = Math.round(priceTo * 100);
  }

  try {
    if (App.selectedPartnerEventId) {
      const data = await apiFetch(`/partners/events/${App.selectedPartnerEventId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!data?.success || !data?.data) {
        toast(data?.error?.message || "Nie udało się zapisać szkicu");
        return;
      }

      await loadPartnerEvents();
      toast("Zapisano szkic wydarzenia");
    } else {
      const data = await apiFetch("/partners/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!data?.success || !data?.data) {
        toast(data?.error?.message || "Nie udało się zapisać szkicu");
        return;
      }

      await loadPartnerEvents();
      toast("Zapisano wydarzenie jako szkic");
    }

    resetPartnerEventFormMode();
    ["peTitle","peCity","peWhen","peWhere","peInterest","peDesc","pePrice","pePriceFrom","pePriceTo","peTicketLink"].forEach(id => {
      const el = $(id);
      if (el) el.value = "";
    });

    go("S9_PARTNER_EVENTS");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zapisać szkicu");
  }
}


function getPartnerActivePublishedEventsCount() {
  const now = new Date();
  return (Array.isArray(App.partnerEvents) ? App.partnerEvents : []).filter((ev) => {
    const status = String(ev?.status || "").toLowerCase();
    const endAt = ev?.end_at ? new Date(ev.end_at) : null;
    return status === "published" && endAt && !Number.isNaN(endAt.getTime()) && endAt >= now;
  }).length;
}

function getPartnerPublishLimitBlockMessage() {
  const rules = getPartnerPlanRules();
  if (rules.maxActiveEvents == null) return null;

  const activeCount = getPartnerActivePublishedEventsCount();
  if (activeCount < rules.maxActiveEvents) return null;

  return `Plan ${String(rules.plan || "free").toUpperCase()} pozwala na maksymalnie ${rules.maxActiveEvents} aktywne wydarzenia. Zapisz kolejne jako szkic albo przejdź na wyższy plan.`;
}


async function publishPartnerEvent() {
  if (App.role !== "partner") {
    toast("To jest dostępne tylko dla organizatora");
    return;
  }

  const title = $("peTitle")?.value?.trim();
  const city = normalizeCity($("peCity")?.value);
  const when = $("peWhen")?.value?.trim();
  const where = $("peWhere")?.value?.trim();
  const interest = normalizeTag($("peInterest")?.value?.trim());
  const desc = $("peDesc")?.value?.trim();

  if (App.selectedPartnerEventId) {
    if (!title || !city || !when) {
      toast("Uzupełnij: nazwa, miasto, kiedy");
      return;
    }
  } else {
    if (!title || !city || !when || !where || !interest) {
      toast("Uzupełnij: nazwa, miasto, kiedy, gdzie, hashtag");
      return;
    }
  }

  const startAt = new Date(when);
  if (Number.isNaN(startAt.getTime())) {
    toast("Podaj poprawną datę wydarzenia");
    return;
  }

  const endAt = new Date(startAt.getTime() + 60 * 60 * 1000);

  const paidMode = $("pePaidMode")?.value || "free";
  const price = Number($("pePrice")?.value || 0);
  const priceFrom = Number($("pePriceFrom")?.value || 0);
  const priceTo = Number($("pePriceTo")?.value || 0);
  const ticketLink = $("peTicketLink")?.value?.trim() || null;
  const unlimitedCapacity = $("peUnlimitedCapacity")?.checked !== false;
  const capacityRaw = $("peCapacity")?.value?.trim() || "";
  const capacityValue = capacityRaw ? Number(capacityRaw) : 0;

  if (!unlimitedCapacity) {
    if (!Number.isInteger(capacityValue) || capacityValue < 1) {
      toast("Podaj poprawną liczbę miejsc");
      return;
    }
  }

  if (paidMode === "paid_fixed") {
    if (!ticketLink) {
      toast("Dodaj link do biletów / rezerwacji");
      return;
    }
    if (!(price > 0)) {
      toast("Podaj poprawną cenę");
      return;
    }
  }

  if (paidMode === "paid_range") {
    if (!ticketLink) {
      toast("Dodaj link do biletów / rezerwacji");
      return;
    }
    if (!(priceFrom > 0) || !(priceTo > 0)) {
      toast("Podaj poprawny zakres cen");
      return;
    }
    if (priceFrom > priceTo) {
      toast("Cena od nie może być większa niż cena do");
      return;
    }
  }

  const pricingTypeMap = {
    free: "free",
    paid_fixed: "paid_fixed",
    paid_range: "paid_range",
  };

  const payload = {
    title,
    description: desc || "",
    city,
    where,
    interest_tag: interest,
    start_at: toLocalApiDateTime(when),
    end_at: addHourToLocalDateTime(when),
    pricing_type: pricingTypeMap[paidMode] || "free",
    payment_link: ticketLink,
    capacity: unlimitedCapacity ? null : capacityValue,
  };

  if (payload.pricing_type === "paid_fixed") {
    payload.price_fixed = Math.round(price * 100);
  } else if (payload.pricing_type === "paid_range") {
    payload.price_min = Math.round(priceFrom * 100);
    payload.price_max = Math.round(priceTo * 100);
  }

  try {
    if (App.selectedPartnerEventId) {
      const data = await apiFetch(`/partners/events/${App.selectedPartnerEventId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!data?.success || !data?.data) {
        toast(data?.error?.message || "Nie udało się zapisać zmian wydarzenia");
        return;
      }

      if (App.partnerEventFormMode === "published_edit") {
        await loadPartnerEvents();
        toast("Zaktualizowano wydarzenie");
      } else {
        const publishBlockMessage = getPartnerPublishLimitBlockMessage();
        if (publishBlockMessage) {
          toast(publishBlockMessage);
          await loadPartnerEvents();
          return;
        }

        const publishData = await apiFetch(`/partners/events/${App.selectedPartnerEventId}/publish`, {
          method: "POST",
        });

        if (!publishData?.success || !publishData?.data) {
          toast(publishData?.error?.message || "Zapisano szkic, ale nie udało się go opublikować");
          await loadPartnerEvents();
          return;
        }

        await loadPartnerEvents();
        toast(App.partnerEventFormMode === "archived_edit" ? "Wznowiono wydarzenie" : "Opublikowano wydarzenie");
      }
    } else {
      const data = await apiFetch("/partners/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!data?.success || !data?.data) {
        toast(data?.error?.message || "Nie udało się utworzyć wydarzenia");
        return;
      }

      const createdEventId = data?.data?.id;
      if (!createdEventId) {
        toast("Utworzono wydarzenie, ale brakuje ID do publikacji");
        return;
      }

      const publishBlockMessage = getPartnerPublishLimitBlockMessage();
      if (publishBlockMessage) {
        toast(publishBlockMessage);
        await loadPartnerEvents();
        return;
      }

      const publishData = await apiFetch(`/partners/events/${createdEventId}/publish`, {
        method: "POST",
      });

      if (!publishData?.success || !publishData?.data) {
        toast(publishData?.error?.message || "Wydarzenie utworzono, ale nie udało się go opublikować");
        await loadPartnerEvents();
        return;
      }

      await loadPartnerEvents();
      toast("Utworzono i opublikowano wydarzenie");
    }

    resetPartnerEventFormMode();
    ["peTitle","peCity","peWhen","peWhere","peInterest","peDesc","pePrice","pePriceFrom","pePriceTo","peTicketLink"].forEach(id => {
      const el = $(id);
      if (el) el.value = "";
    });

    go("S9_PARTNER_EVENTS");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zapisać wydarzenia");
  }
}

/* ------------------------- Notifications -------------------------- */
async function renderNotifications() {
  const list = $("notifList");
  if (!list) return;

  let items = [];
  updateNotifBadges(0);

  try {
    if (App.role === "partner") {
      const evRes = await apiFetch("/partners/events?limit=100");
      const events = Array.isArray(evRes?.data?.items) ? evRes.data.items : [];

      const notifBatches = await Promise.all(events.map(async (ev) => {
        const out = [];

        try {
          const res = await apiFetch(`/partners/events/${ev.id}/participants?limit=20`);
          const rows = Array.isArray(res?.data?.items) ? res.data.items : [];
          out.push(...rows.map((row) => ({
            type: "signup",
            eventId: ev.id,
            eventTitle: ev.title || "Wydarzenie",
            userNick: row?.user?.nick || row?.user?.email || `Użytkownik #${row?.user?.id || "?"}`,
            createdAt: row?.signup?.created_at || null,
          })));
        } catch (err) {
          console.error(`partner notifications participants failed for event ${ev.id}`, err);
        }

        try {
          const res = await apiFetch(`/partners/events/${ev.id}/observers?limit=20`);
          const rows = Array.isArray(res?.data?.items) ? res.data.items : [];
          out.push(...rows.map((row) => ({
            type: "observer",
            eventId: ev.id,
            eventTitle: ev.title || "Wydarzenie",
            userNick: row?.user?.nick || row?.user?.email || `Użytkownik #${row?.user?.id || "?"}`,
            createdAt: row?.saved?.created_at || null,
          })));
        } catch (err) {
          console.error(`partner notifications observers failed for event ${ev.id}`, err);
        }

        return out;
      }));

      items = notifBatches
        .flat()
        .sort((a, b) => {
          const ad = parseUslyTimestamp(a?.createdAt);
          const bd = parseUslyTimestamp(b?.createdAt);
          return bd - ad;
        })
        .slice(0, 20)
        .map((item) => ({
          title: item.type === "observer" ? "Nowe obserwowanie wydarzenia" : "Nowy zapis na wydarzenie",
          body: item.type === "observer"
            ? `${item.userNick} obserwuje: ${item.eventTitle}`
            : `${item.userNick} zapisał(a) się na: ${item.eventTitle}`,
          targetView: "S9_PARTNER_EVENTS",
          createdAt: item.createdAt || null,
        }));
    } else {
      const [reqRes, groupInvRes, eventNotifRes] = await Promise.all([
        apiFetch("/friends/requests"),
        apiFetch("/group-invitations"),
        apiFetch("/users/me/notifications?limit=50"),
      ]);

      const incoming = Array.isArray(reqRes?.data?.incoming) ? reqRes.data.incoming : [];
      const incomingGroupInvites = Array.isArray(groupInvRes?.data?.incoming) ? groupInvRes.data.incoming : [];
      const eventNotifItems = Array.isArray(eventNotifRes?.data?.items) ? eventNotifRes.data.items : [];

      incoming.forEach((req) => {
        const nick = req?.user?.nick || req?.user?.email || "Nowa osoba";
        items.push({
          title: "Zaproszenie do znajomych",
          body: `${nick} chce dodać Cię do znajomych`,
          targetView: "S10E_PROFILE_INVITES",
          createdAt: req?.created_at || null,
        });
      });

      eventNotifItems.forEach((row) => {
        const notification = row?.notification || {};
        const event = row?.event || {};
        const isTimeAndLocationChange = notification.type === "event_time_and_location_changed";
        const isTimeChange = notification.type === "event_time_changed";
        const isLocationChange = notification.type === "event_location_changed";
        const isLegacyUpdate = notification.type === "event_updated";

        if (!isTimeAndLocationChange && !isTimeChange && !isLocationChange && !isLegacyUpdate) return;

        const title = event?.title || "Wydarzenie";
        const place = [event?.city, event?.where].filter(Boolean).join(", ");
        const when = event?.start_at
          ? String(event.start_at).trim().replace("T", " ").slice(0, 16)
          : "";

        items.push({
          title: isTimeAndLocationChange
            ? "Zmiana godziny i miejsca wydarzenia"
            : isTimeChange
              ? "Zmiana godziny wydarzenia"
              : isLocationChange
                ? "Zmiana miejsca wydarzenia"
                : "Zmiana w zapisanym wydarzeniu",
          body: place || when
            ? `${title} — ${[when, place].filter(Boolean).join(" • ")}`
            : `${title} zostało zaktualizowane`,
          targetView: "S7_EVENTS",
          createdAt: notification?.created_at || null,
        });
      });

      incomingGroupInvites.forEach((inv) => {
        const nick = inv?.user?.nick || inv?.user?.email || "Użytkownik";
        const groupTitle = inv?.group?.title || "Grupa";
        items.push({
          title: "Zaproszenie do grupy",
          body: `${nick} zaprasza Cię do grupy: ${groupTitle}`,
          targetView: "S10E_PROFILE_INVITES",
          createdAt: inv?.created_at || null,
        });
      });

      items.sort((a, b) => {
        const ad = parseUslyTimestamp(a?.createdAt);
        const bd = parseUslyTimestamp(b?.createdAt);
        return bd - ad;
      });
    }

  } catch (e) {
    console.error("notifications error", e);
  }

  const seenAtRaw = localStorage.getItem(
    App.role === "partner" ? "usly_partner_notifications_seen_at" : "usly_user_notifications_seen_at"
  );
  const seenAt = parseUslyTimestamp(seenAtRaw);

  if (items.length === 0) {
    list.innerHTML = `
      <div class="card">
        <div class="sectionSub">Brak powiadomień</div>
      </div>
    `;
    updateNotifBadges(0);
    return;
  }

  list.innerHTML = items.map(n => {
    const isNew = parseUslyTimestamp(n?.createdAt) > seenAt;
    const ts = n?.createdAt
      ? new Date(parseUslyTimestamp(n.createdAt)).toLocaleString("pl-PL", {
          day: "2-digit",
          month: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "";
    return `
    <div class="listItem ${isNew ? 'notifNew' : ''}" style="cursor:pointer;" onclick="go('${n.targetView}')">
      <div class="row" style="align-items:flex-start;justify-content:space-between;gap:12px;">
        <div class="listTitle" style="flex:1;min-width:0;">${n.title}</div>
        <div class="sectionSub" style="white-space:nowrap;flex-shrink:0;">${ts}</div>
      </div>
      <div class="listBody">${n.body}</div>
    </div>
  `;
  }).join("");

  if (App.role === "partner") {
    localStorage.setItem("usly_partner_notifications_seen_at", new Date().toISOString());
    updateNotifBadges(0);
  } else {
    localStorage.setItem("usly_user_notifications_seen_at", new Date().toISOString());
    updateNotifBadges(0);
  }
}




function updateNotifBadges(count) {
  const buttons = document.querySelectorAll('button[id^="notifBtn"]');
  buttons.forEach(btn => {
    if (count > 0) {
      btn.classList.add("hasBadge");
      btn.setAttribute("data-badge", String(count));
    } else {
      btn.classList.remove("hasBadge");
      btn.removeAttribute("data-badge");
    }
  });
}

function parseUslyTimestamp(value) {
  if (!value) return 0;
  const normalized = typeof value === "string" && !/[zZ]|[+-]\d\d:\d\d$/.test(value)
    ? `${value}Z`
    : value;
  const ts = new Date(normalized).getTime();
  return Number.isFinite(ts) ? ts : 0;
}

async function refreshNotifBadgeCount() {
  if (!App.isLoggedIn || App.role !== "user") {
    updateNotifBadges(0);
    return;
  }

  if (App.currentView === "S10E_PROFILE_INVITES" || App.currentView === "S12_NOTIFICATIONS") {
    updateNotifBadges(0);
    return;
  }

  try {
    const seenAtRaw = localStorage.getItem("usly_user_notifications_seen_at");
    const seenAt = parseUslyTimestamp(seenAtRaw);

    const [reqRes, groupInvRes, eventNotifRes] = await Promise.all([
      apiFetch("/friends/requests"),
      apiFetch("/group-invitations"),
      apiFetch("/users/me/notifications?limit=50"),
    ]);

    const incoming = Array.isArray(reqRes?.data?.incoming) ? reqRes.data.incoming : [];
    const incomingGroupInvites = Array.isArray(groupInvRes?.data?.incoming) ? groupInvRes.data.incoming : [];
    const eventNotifItems = Array.isArray(eventNotifRes?.data?.items) ? eventNotifRes.data.items : [];

    const totalUnread =
      incoming.filter((req) => {
        const createdAt = parseUslyTimestamp(req?.created_at);
        return createdAt > seenAt;
      }).length +
      incomingGroupInvites.filter((inv) => {
        const createdAt = parseUslyTimestamp(inv?.created_at);
        return createdAt > seenAt;
      }).length +
      eventNotifItems.filter((row) => {
        const createdAt = parseUslyTimestamp(row?.notification?.created_at);
        return createdAt > seenAt;
      }).length;

    updateNotifBadges(totalUnread);
  } catch (e) {
    console.error("notif badge refresh error", e);
  }
}

async function refreshPartnerMsgBadgeCount() {
  const badge = $("badgePartnerMsgs");
  if (!badge) return;

  if (!App.isLoggedIn || App.role !== "partner") {
    badge.style.display = "none";
    return;
  }

  if (App.currentView === "S9_PARTNER_MESSAGES" || App.currentView === "S6B_CHAT_THREAD") {
    badge.style.display = "none";
    return;
  }

  try {
    const data = await apiFetch("/messages/private");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];
    const totalUnread = items.reduce((sum, item) => {
      const chatId = `pm_${item?.other_user_id}`;
      const muted = isChatMuted(chatId);
      return sum + (muted ? 0 : Number(item?.unread_count || 0));
    }, 0);

    badge.textContent = String(totalUnread);
    badge.style.display = totalUnread > 0 ? "inline-flex" : "none";
  } catch (e) {
    console.error("partner msg badge refresh error", e);
    badge.style.display = "none";
  }
}

function getGroupSeenMapStorageKey() {
  return `usly_group_seen_map_${App.role || "user"}_${App.currentUserId || "guest"}`;
}

function getMutedGroupsStorageKey() {
  return `usly_muted_groups_${App.role || "user"}_${App.currentUserId || "guest"}`;
}

function getMutedChatsStorageKey() {
  return `usly_muted_chats_${App.role || "user"}_${App.currentUserId || "guest"}`;
}

function getChatSeenMapStorageKey() {
  return `usly_chat_seen_map_${App.role || "user"}_${App.currentUserId || "guest"}`;
}

function readChatSeenMap() {
  try {
    const raw = localStorage.getItem(getChatSeenMapStorageKey());
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (_) {
    return {};
  }
}

function writeChatSeenMap(map) {
  try {
    localStorage.setItem(getChatSeenMapStorageKey(), JSON.stringify(map || {}));
  } catch (_) {}
}

function markChatAsSeen(chatId) {
  if (!chatId) return;
  const seenMap = readChatSeenMap();
  seenMap[String(chatId)] = new Date().toISOString();
  writeChatSeenMap(seenMap);
}

function readMutedChatsMap() {
  try {
    const raw = localStorage.getItem(getMutedChatsStorageKey());
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (_) {
    return {};
  }
}

function writeMutedChatsMap(map) {
  try {
    localStorage.setItem(getMutedChatsStorageKey(), JSON.stringify(map || {}));
  } catch (_) {}
}

function isChatMuted(chatId) {
  if (!chatId) return false;
  const map = readMutedChatsMap();
  return !!map[String(chatId)];
}

function setChatMuted(chatId, muted) {
  if (!chatId) return;
  const map = readMutedChatsMap();
  if (muted) {
    map[String(chatId)] = true;
  } else {
    delete map[String(chatId)];
  }
  writeMutedChatsMap(map);
}

function readMutedGroupsMap() {
  try {
    const raw = localStorage.getItem(getMutedGroupsStorageKey());
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (_) {
    return {};
  }
}

function writeMutedGroupsMap(map) {
  try {
    localStorage.setItem(getMutedGroupsStorageKey(), JSON.stringify(map || {}));
  } catch (_) {}
}

function isGroupMuted(groupId) {
  if (!groupId) return false;
  const mutedMap = readMutedGroupsMap();
  return !!mutedMap[String(groupId)];
}

function setGroupMuted(groupId, muted) {
  if (!groupId) return;
  const mutedMap = readMutedGroupsMap();
  if (muted) {
    mutedMap[String(groupId)] = true;
  } else {
    delete mutedMap[String(groupId)];
  }
  writeMutedGroupsMap(mutedMap);
}

function readGroupSeenMap() {
  try {
    const raw = localStorage.getItem(getGroupSeenMapStorageKey());
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (_) {
    return {};
  }
}

function writeGroupSeenMap(map) {
  try {
    localStorage.setItem(getGroupSeenMapStorageKey(), JSON.stringify(map || {}));
  } catch (_) {}
}

function markGroupAsSeen(groupId) {
  if (!groupId) return;
  const seenMap = readGroupSeenMap();
  seenMap[String(groupId)] = new Date().toISOString();
  writeGroupSeenMap(seenMap);
}

async function getGroupUnreadSummary() {
  if (!App.isLoggedIn || App.role !== "user") {
    return { totalGroupsWithUnread: 0, byGroupId: {} };
  }

  const seenMap = readGroupSeenMap();
  const myGroups = Array.isArray(App.myGroups) ? App.myGroups : [];
  const byGroupId = {};
  let totalGroupsWithUnread = 0;

  for (const g of myGroups) {
    try {
      const data = await apiFetch(`/messages/group/${g.id}`);
      const items = Array.isArray(data?.data?.items) ? data.data.items : [];
      const seenAt = parseUslyTimestamp(seenMap[String(g.id)]);
      const unreadCount = items.filter((m) => {
        const createdAt = parseUslyTimestamp(m?.created_at);
        return createdAt > seenAt && String(m?.sender_user_id) !== String(App.currentUserId);
      }).length;

      const muted = isGroupMuted(g.id);
      const finalUnread = muted ? 0 : unreadCount;

      byGroupId[String(g.id)] = finalUnread;
      if (finalUnread > 0) totalGroupsWithUnread += 1;
    } catch (_) {
      byGroupId[String(g.id)] = 0;
    }
  }

  return { totalGroupsWithUnread, byGroupId };
}


async function refreshGroupBadgeCount() {
  const badge = $("badgeGroups");
  if (!badge) return;

  if (!App.isLoggedIn || App.role !== "user") {
    badge.style.display = "none";
    return;
  }

  try {
    const summary = await getGroupUnreadSummary();
    const count = Number(summary?.totalGroupsWithUnread || 0);

    badge.textContent = String(count);
    badge.style.display = count > 0 ? "inline-flex" : "none";
  } catch (e) {
    console.error("group badge refresh error", e);
    badge.style.display = "none";
  }
}

async function refreshPartnerNotifBadgeCount() {
  if (!App.isLoggedIn || App.role !== "partner") {
    updateNotifBadges(0);
    return;
  }

  if (App.currentView === "S12_NOTIFICATIONS") {
    updateNotifBadges(0);
    return;
  }

  try {
    const seenAtRaw = localStorage.getItem("usly_partner_notifications_seen_at");
    const seenAt = seenAtRaw ? new Date(seenAtRaw).getTime() : 0;

    const evRes = await apiFetch("/partners/events?limit=100");
    const events = Array.isArray(evRes?.data?.items) ? evRes.data.items : [];

    const notifBatches = await Promise.all(events.map(async (ev) => {
      const out = [];

      try {
        const res = await apiFetch(`/partners/events/${ev.id}/participants?limit=20`);
        const rows = Array.isArray(res?.data?.items) ? res.data.items : [];
        out.push(...rows.map((row) => ({
          createdAt: row?.signup?.created_at || null,
        })));
      } catch (err) {
        console.error(`partner notif badge participants failed for event ${ev.id}`, err);
      }

      try {
        const res = await apiFetch(`/partners/events/${ev.id}/observers?limit=20`);
        const rows = Array.isArray(res?.data?.items) ? res.data.items : [];
        out.push(...rows.map((row) => ({
          createdAt: row?.saved?.created_at || null,
        })));
      } catch (err) {
        console.error(`partner notif badge observers failed for event ${ev.id}`, err);
      }

      return out;
    }));

    const totalUnread = notifBatches
      .flat()
      .filter((row) => {
        const createdAt = parseUslyTimestamp(row?.createdAt);
        return createdAt > seenAt;
      })
      .length;

    updateNotifBadges(totalUnread);
  } catch (e) {
    console.error("partner notif badge refresh error", e);
    updateNotifBadges(0);
  }
}

function getEventCapacityCopy(ev) {
  const signups = Number(ev?.signupsCount || 0);
  const capacity = ev?.capacity ?? null;
  const spotsLeft = ev?.spotsLeft ?? null;

  if (capacity == null) {
    return {
      line: `${signups} zapisanych`,
      alert: "",
      full: false,
    };
  }

  if (spotsLeft === 0) {
    return {
      line: `${signups} z ${capacity} miejsc zajętych`,
      alert: "Komplet miejsc",
      full: true,
    };
  }

  if (typeof spotsLeft === "number" && spotsLeft > 0 && spotsLeft <= 3) {
    return {
      line: `${signups} z ${capacity} miejsc zajętych`,
      alert: `Zostały ostatnie ${spotsLeft} ${spotsLeft === 1 ? "miejsce" : "miejsca"}`,
      full: false,
    };
  }

  return {
    line: `${signups} z ${capacity} miejsc zajętych`,
    alert: "",
    full: false,
  };
}

/* ------------------------- Rendering Lists -------------------------- */
function renderNearby() {
  initNearbyMap();
  renderNearbyMapMarkers();

  // People list in nearby tab
  const pList = $("nearbyPeopleList");
  if (pList) {
    const people = getNearbyPeopleForView();

    if (!people.length) {
      pList.innerHTML = '<div class="tMuted">Nie widzimy jeszcze osób z wspólnymi zainteresowaniami w Twojej okolicy.</div>';
    } else {
      pList.innerHTML = people.map(p => `
      <div class="listItem" onclick="openPerson('${p.id}')">
        <div class="listTop">
          <div class="listLeft">
              <div class="listAvatar">${p.avatarUrl ? `<img src="${String(p.avatarUrl).startsWith("http") ? p.avatarUrl : `${API_BASE_URL}${p.avatarUrl}`}" alt="${p.nick}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />` : p.emoji}</div>
            <div style="min-width:0;">
              <div class="listTitle">${p.nick}</div>
              <div class="listMeta">${p.distance_km != null ? (p.distance_km < 1 ? "< 1 km od Ciebie" : `${String(p.distance_km).replace(".", ",")} km od Ciebie`) : "W okolicy"} • ${p.age} lat</div>
            </div>
          </div>
          <div class="listRight">
            <div class="listTag">${sharedScore(p)}% wspólne</div>
          </div>
        </div>
        <div class="listBody">${p.interests.slice(0,3).map(t => `#${t}`).join(" ")}</div>
      </div>
    `).join("");
    }
  }

  // Events list in nearby tab
  const eList = $("nearbyEventsList");
  if (eList) {
    const events = App.events
      .filter(ev => matchesUserEventInterest(ev) && isEventInMyCity(ev))
      .slice(0, 8);

    if (!events.length) {
      eList.innerHTML = '<div class="tMuted">Nie widzimy jeszcze wydarzeń zgodnych z Twoimi zainteresowaniami w Twojej okolicy.</div>';
      return;
    }

    eList.innerHTML = events.map(ev => `
      <div class="listItem" onclick="openEvent('${ev.id}')">
        <div class="listTop">
          <div class="listLeft">
            <div class="listAvatar">🎫</div>
            <div style="min-width:0;">
              <div class="listTitle">${ev.title}</div>
              <div class="listMeta">${ev.city} • ${ev.where} • ${ev.when}</div>
            </div>
          </div>
          <div class="listRight">
            <div class="listTag ${ev.paidMode === 'free' ? '' : 'paid'}">
              ${ev.paidMode === "free" ? "Bezpłatne" : "Płatne"}
            </div>
          </div>
        </div>
        <div class="listBody">
        #${ev.interest} • ${getEventCapacityCopy(ev).line}${getEventCapacityCopy(ev).alert ? ` • ${getEventCapacityCopy(ev).alert}` : ""}
        ${(ev.saved || ev.interested) ? `<div class="chips" style="margin-top:8px;">
          ${ev.saved ? `<div class="chip">Obserwowane</div>` : ``}
          ${ev.interested ? `<div class="chip">Biorę udział</div>` : ``}
        </div>` : ``}
      </div>
      </div>
    `).join("");
  }
}

function renderEventsList() {
  const list = $("eventsList");
  if (!list) return;

  const q = ($("eventsSearch")?.value || "").trim().toLowerCase();

  let events = App.events.slice();
  if (App.eventsTab === "followed") {
    events = events.filter(e => e.saved || e.interested);
  } else {
    events = events.filter(e =>
      matchesUserEventInterest(e) &&
      !isEventInMyCity(e) &&
      !e.saved &&
      !e.interested
    );
  }

  if (q) {
    const qClean = q.replace("#", "");
    events = events.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.interest.toLowerCase().includes(qClean)
    );
  }

  list.innerHTML = events.map(ev => `
    <div class="listItem" onclick="openEvent('${ev.id}')">
      <div class="listTop">
        <div class="listLeft">
          <div class="listAvatar">🎫</div>
          <div style="min-width:0;">
            <div class="listTitle">${ev.title}</div>
            <div class="listMeta">${ev.city} • ${ev.where} • ${ev.when}</div>
          </div>
        </div>
        <div class="listRight">
          <div class="listTag ${ev.paidMode === 'free' ? '' : 'paid'}">
            ${ev.paidMode === "free" ? "Bezpłatne" : "Płatne"}
          </div>
        </div>
      </div>

      <div class="listBody">
        #${ev.interest} • ${getEventCapacityCopy(ev).line}${getEventCapacityCopy(ev).alert ? ` • ${getEventCapacityCopy(ev).alert}` : ""}

        ${(ev.saved || ev.interested) ? `
          <div class="chips" style="margin-top:8px;">
            ${ev.saved ? `<div class="chip">Obserwowane</div>` : ``}
            ${ev.interested ? `<div class="chip">Biorę udział</div>` : ``}
          </div>
        ` : ``}
      </div>
    </div>
  `).join("");
}

async function renderGroups() {
  const list = $("groupList");
  if (!list) return;

  refreshCreateGroupUi();

  const q = ($("groupSearch")?.value || "").trim().toLowerCase().replace("#", "");

  let myGroups = Array.isArray(App.myGroups) ? [...App.myGroups] : [];
  let suggestedGroups = Array.isArray(App.groups) ? [...App.groups] : [];
  const unreadSummary = await getGroupUnreadSummary().catch(() => ({ totalGroupsWithUnread: 0, byGroupId: {} }));
  const unreadByGroupId = unreadSummary?.byGroupId || {};

  const myInterestTags = (Array.isArray(App.user?.interests) ? App.user.interests : [])
    .map(x => normalizeTag(String(x)))
    .filter(Boolean);

  if (myInterestTags.length) {
    suggestedGroups = suggestedGroups.filter(g =>
      myInterestTags.includes(normalizeTag(String(g.interestTag || "")))
    );
  }

  if (q) {
    myGroups = myGroups.filter(g =>
      (g.title || "").toLowerCase().includes(q) ||
      (g.interestTag || "").toLowerCase().includes(q)
    );

    suggestedGroups = suggestedGroups.filter(g =>
      (g.title || "").toLowerCase().includes(q) ||
      (g.interestTag || "").toLowerCase().includes(q)
    );
  }

  const renderGroupCard = (g) => {
    const unread = Number(unreadByGroupId[String(g.id)] || 0);
    const muted = isGroupMuted(g.id);
    const m = Number(g.members);
const membersLabel = m === 1
  ? "1 osoba"
  : (m >= 2 && m <= 4)
    ? `${m} osoby`
    : `${m} osób`;
    return `
      <div class="listItem ${unread > 0 ? 'unread' : ''}" onclick="openGroup('${g.id}')" style="position:relative; padding-bottom:36px;">
        ${g.isCreator ? `<div style="
  position:absolute;
  bottom:10px;
  right:12px;
  max-width:110px;
  padding:6px 8px;
  border-radius:12px;
  font-size:10.5px;
  font-weight:900;
  line-height:1.15;
  text-align:center;
  word-break:break-word;
  color:#f4f8ff;
  background: rgba(9,12,24,.55);
  border:1px solid rgba(255,255,255,.14);
  box-shadow:
    0 6px 16px rgba(0,0,0,.35),
    0 0 0 1px rgba(255,255,255,.04) inset,
    0 0 12px rgba(52,230,255,.18);
  backdrop-filter: blur(6px);
">Założona<br>przez Ciebie</div>` : ``}
        <div class="listTop">
          <div class="listLeft">
            <div class="listAvatar">👥</div>
            <div style="min-width:0;">
              <div class="listTitle">${g.title}</div>
              <div class="listMeta">#${g.interestTag} • ${membersLabel}</div>
            </div>
          </div>
          <div class="listRight">
            ${muted ? `<div style="font-size:14px;opacity:.7;">🔕</div>` : ``}
            ${unread > 0 ? `<div class="badgeMini">${unread}</div>` : ``}
          </div>
        </div>
        <div class="listBody">${g.desc}</div>
      </div>
    `;
  };

  let html = "";

  if (myGroups.length) {
    html += `
      <div class="card">
        <div class="sectionTitle">Twoje grupy</div>
        <div class="sectionSub">Grupy, do których już należysz.</div>
        <div class="col mt12">
          ${myGroups.map(renderGroupCard).join("")}
        </div>
      </div>
    `;
  }

  html += `
    <div class="card ${myGroups.length ? "mt16" : ""}">
      <div class="sectionTitle">Proponowane grupy</div>
      <div class="sectionSub">Dopasowane do Twoich zainteresowań i wykluczające grupy, w których już jesteś.</div>
      <div class="col mt12">
        ${suggestedGroups.length ? suggestedGroups.map(renderGroupCard).join("") : '<div class="tMuted">Brak proponowanych grup</div>'}
      </div>
    </div>
  `;

  list.innerHTML = html;

  const sug = $("groupPeopleSuggestions");
  if (sug) {
    sug.innerHTML = "";
    sug.style.display = "none";
  }
}

async function renderChatList() {
  const list = $("chatList");
  const q = ($("chatSearch")?.value || "").trim().toLowerCase();

  try {
    const data = await apiFetch("/messages/private");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    const chats = items
      .filter(c => !q || String(c.other_user_name || "").toLowerCase().includes(q))
      .map(c => {
        const existing = App.chats.find(x => String(x.with?.id) === String(c.other_user_id));
        const chatId = existing?.id || `pm_${c.other_user_id}`;
        const isPartner = String(c.other_user_role || existing?.with?.role || "").toLowerCase() === "partner";
        const displayName = isPartner
          ? (c.other_user_company || existing?.with?.company || c.other_user_name || `Organizator #${c.other_user_id}`)
          : (c.other_user_name || existing?.with?.nick || `Użytkownik #${c.other_user_id}`);

        if (!existing) {
          App.chats.unshift({
            id: chatId,
            with: {
              id: c.other_user_id,
              nick: displayName,
              role: isPartner ? "partner" : "user",
              company: c.other_user_company || "",
              city: c.other_user_city || "",
              category: c.other_user_category || "",
              bio: c.other_user_bio || "",
              avatarUrl: c.other_user_avatar_url || "",
              logoUrl: c.other_user_logo_url || c.other_user_avatar_url || "",
              emoji: isPartner ? "🏢" : "💬",
            },
            last: c.last_message || "",
            unread: Number(c.unread_count || 0),
            messages: [],
          });
        } else {
          existing.with = {
            ...(existing.with || {}),
            id: c.other_user_id,
            nick: displayName,
            role: isPartner ? "partner" : (existing.with?.role || "user"),
            company: c.other_user_company || existing.with?.company || "",
            city: c.other_user_city || existing.with?.city || "",
            category: c.other_user_category || existing.with?.category || "",
            bio: c.other_user_bio || existing.with?.bio || "",
            avatarUrl: c.other_user_avatar_url || existing.with?.avatarUrl || "",
            logoUrl: c.other_user_logo_url || existing.with?.logoUrl || c.other_user_avatar_url || existing.with?.avatarUrl || "",
            emoji: isPartner ? "🏢" : (existing.with?.emoji || "💬"),
          };
          existing.last = c.last_message || existing.last || "";
          existing.unread = Number(c.unread_count || existing.unread || 0);
        }

        const rawUnread = Number(c.unread_count || 0);
        const muted = isChatMuted(chatId);
        const finalUnread = muted ? 0 : rawUnread;

        return {
          id: chatId,
          with: {
            ...(existing?.with || {}),
            id: c.other_user_id,
            nick: displayName,
            role: isPartner ? "partner" : (existing?.with?.role || "user"),
            company: c.other_user_company || existing?.with?.company || "",
            city: c.other_user_city || existing?.with?.city || "",
            category: c.other_user_category || existing?.with?.category || "",
            bio: c.other_user_bio || existing?.with?.bio || "",
            avatarUrl: c.other_user_avatar_url || existing?.with?.avatarUrl || "",
            logoUrl: c.other_user_logo_url || existing?.with?.logoUrl || c.other_user_avatar_url || existing?.with?.avatarUrl || "",
            emoji: isPartner ? "🏢" : (existing?.with?.emoji || "💬"),
          },
          last: c.last_message || "",
          unread: finalUnread,
        };
      });

    const finalChats = chats;

    if (list) {
      if (!(finalChats || []).length) {
        list.innerHTML = '<div class="tMuted">Brak rozmów</div>';
      } else {
        list.innerHTML = (finalChats || []).map(c => {
        const muted = isChatMuted(c.id);
        return `
        <div class="listItem ${c.unread > 0 ? 'unread' : ''}" onclick="openChat('${c.id}')">
          <div class="listTop">
            <div class="listLeft">
              <div class="listAvatar">${c.with.emoji || "💬"}</div>
              <div style="min-width:0;">
                <div class="listTitle">${c.with.nick}</div>
                <div class="listMeta">${c.last || "—"}</div>
              </div>
            </div>
            ${(muted || c.unread > 0) ? `<div class="listRight">${muted ? `<div style="font-size:14px;opacity:.7;">🔕</div>` : ``}${c.unread > 0 ? `<div class="badgeMini">${c.unread}</div>` : ``}</div>` : ``}
          </div>
        </div>
      `;
      }).join("");
      }
    }

    const badge = $("badgeChats");
    if (badge) {
      const unreadTotal = (finalChats || []).reduce((sum, c) => sum + Number(c.unread || 0), 0);
      if (unreadTotal > 0) {
        badge.textContent = String(unreadTotal);
        badge.style.display = "inline-flex";
      } else {
        badge.textContent = "0";
        badge.style.display = "none";
      }
    }
  } catch (err) {
    console.error("renderChatList failed", err);

    const fallbackChats = (App.chats || []).filter(c =>
      c?.with?.id != null &&
      (!q || String(c.with?.nick || "").toLowerCase().includes(q))
    );

    if (list) {
      if (!fallbackChats.length) {
        list.innerHTML = '<div class="tMuted">Nie udało się załadować rozmów</div>';
      } else {
        list.innerHTML = fallbackChats.map(c => `
        <div class="listItem" onclick="openChat('${c.id}')">
          <div class="listTop">
            <div class="listLeft">
              <div class="listAvatar">${c.with?.emoji || "💬"}</div>
              <div style="min-width:0;">
                <div class="listTitle">${c.with?.nick || "Czat"}</div>
                <div class="listMeta">${c.last || "—"}</div>
              </div>
            </div>
          </div>
        </div>
      `).join("");
      }
    }
  }
}

function renderPartnerEvents() {
  const list = $("partnerEventsList");
  if (!list) return;

  const events = Array.isArray(App.partnerEvents) ? App.partnerEvents : [];

  if (!events.length) {
    list.innerHTML = '<div class="tMuted">Brak wydarzeń organizatora</div>';
    return;
  }

  const now = new Date();

  const formatWhen = (value) => {
    if (!value) return "Brak daty";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return d.toLocaleString("pl-PL", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const priceText = (ev) => {
    if (ev.pricing_type === "free") return "Bezpłatne";
    if (ev.pricing_type === "paid_fixed") {
      return ev.price_fixed != null ? `${Math.round(Number(ev.price_fixed) / 100)} zł` : "Płatne";
    }
    if (ev.pricing_type === "paid_range") {
      if (ev.price_min != null && ev.price_max != null) {
        return `${Math.round(Number(ev.price_min) / 100)}-${Math.round(Number(ev.price_max) / 100)} zł`;
      }
      return "Płatne";
    }
    return "—";
  };

  const getLifecycleLabel = (ev) => {
    const status = String(ev.status || "draft").toLowerCase();
    const endAt = ev?.end_at ? new Date(ev.end_at) : null;

    if (status === "archived") return "Archiwalne";
    if (status === "draft") return "Szkic";
    if (status === "published" && endAt && !Number.isNaN(endAt.getTime()) && endAt < now) return "Zakończone";
    if (status === "published") return "Aktywne";
    return status;
  };

    const renderEventCard = (ev) => {
      const isFeatured = getPartnerPlanRules().canFeatureEvents;
      return `
      <div class="listItem ${isFeatured ? "isFeatured" : ""}" onclick="openPartnerEventEditor('${ev.id}')">
        <div class="listTop">
          <div class="listLeft">
            <div class="listAvatar">🗓️</div>
            <div style="min-width:0;">
              <div class="listTitle">${ev.title || "Bez nazwy"}</div>
              <div class="listMeta">${ev.city || "—"} • ${ev.where || "—"} • ${formatWhen(ev.start_at)}</div>
              ${isFeatured ? `<div class="mt12"><span class="listTag featured">Wyróżnione</span></div>` : ""}
            </div>
          </div>
          <div class="listRight">
            <div class="listTag ${ev.pricing_type === 'free' ? '' : 'paid'}">${priceText(ev)}</div>
          </div>
        </div>
        <div class="listBody">
          <span class="eventStatusBadge">${getLifecycleLabel(ev)}</span> • Zapisy: ${Number(ev.signups_count || 0)}
          ${ev.capacity != null ? ` • Wolne miejsca: ${ev.spots_left != null ? ev.spots_left : "—"}` : ""}
        </div>
        ${String(ev.status || "").toLowerCase() !== "draft" ? `
          <div class="row mt12">
            <button class="btn secondary" type="button" onclick="event.stopPropagation(); openPartnerEventParticipantsView('${ev.id}')">Uczestnicy</button>
          </div>
        ` : ""}
        ${String(ev.status || "").toLowerCase() === "draft" ? `
          <div class="row mt12">
            <button class="btn" type="button" onclick="event.stopPropagation(); quickPublishPartnerEvent('${ev.id}')">Opublikuj</button>
          </div>
        ` : ""}
        ${String(ev.status || "").toLowerCase() === "published" ? `
          <div class="row mt12">
            <button class="btn secondary" type="button" onclick="event.stopPropagation(); quickArchivePartnerEvent('${ev.id}')">${(() => {
              const endAt = ev?.end_at ? new Date(ev.end_at) : null;
              return endAt && !Number.isNaN(endAt.getTime()) && endAt < now
                ? "Zarchiwizuj"
                : "Zamknij wydarzenie";
            })()}</button>
          </div>
        ` : ""}
      </div>
    `;
    };

  const drafts = [];
  const active = [];
  const finished = [];
  const archived = [];

  events.forEach((ev) => {
    const status = String(ev.status || "draft").toLowerCase();
    const endAt = ev?.end_at ? new Date(ev.end_at) : null;

    if (status === "archived") {
      archived.push(ev);
    } else if (status === "draft") {
      drafts.push(ev);
    } else if (status === "published" && endAt && !Number.isNaN(endAt.getTime()) && endAt < now) {
      finished.push(ev);
    } else {
      active.push(ev);
    }
  });

  const renderSection = (title, sub, items) => {
    const count = items.length;
    const titleWithCount = `${title} (${count})`;
    return `
      <div class="card mt16">
        <div class="sectionTitle">${titleWithCount}</div>
        <div class="sectionSub">${sub}</div>
        <div class="col mt12">
          ${items.length
            ? items.map(renderEventCard).join("")
            : '<div class="tMuted">Brak wydarzeń w tej sekcji</div>'}
        </div>
      </div>
    `;
  };

  list.innerHTML = [
    renderSection("Aktywne", "Opublikowane wydarzenia, które jeszcze się nie zakończyły.", active),
    renderSection("Szkice", "Wydarzenia zapisane roboczo przed publikacją.", drafts),
    renderSection("Zakończone", "Wydarzenia, których czas już minął.", finished),
    renderSection("Archiwalne", "Wydarzenia ręcznie przeniesione do archiwum.", archived),
  ].join("");
}

async function quickPublishPartnerEvent(eventId) {
  if (!eventId) return;

  try {
    const publishBlockMessage = getPartnerPublishLimitBlockMessage();
    if (publishBlockMessage) {
      toast(publishBlockMessage);
      return;
    }

    const data = await apiFetch(`/partners/events/${eventId}/publish`, {
      method: "POST",
    });

    if (!data?.success || !data?.data) {
      toast(data?.error?.message || "Nie udało się opublikować wydarzenia");
      return;
    }

    await loadPartnerEvents();
    if (App.currentView === "S9_PARTNER_EVENTS") renderPartnerEvents();
    toast("Wydarzenie opublikowane");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się opublikować wydarzenia");
  }
}


async function quickArchivePartnerEvent(eventId) {
  if (!eventId) return;

  try {
    const data = await apiFetch(`/partners/events/${eventId}/archive`, {
      method: "POST",
    });

    if (!data?.success || !data?.data) {
      toast(data?.error?.message || "Nie udało się zarchiwizować wydarzenia");
      return;
    }

    await loadPartnerEvents();
    if (App.currentView === "S9_PARTNER_EVENTS") renderPartnerEvents();
    toast("Wydarzenie przeniesiono do archiwum");
  } catch (err) {
    toast(err?.userMessage || "Nie udało się zarchiwizować wydarzenia");
  }
}


async function renderPartnerMsgList() {
  const list = $("partnerMsgList");
  if (!list) return;

  const q = ($("partnerMsgSearch")?.value || "").trim().toLowerCase();

  try {
    const data = await apiFetch("/messages/private");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    const chats = items
      .filter(c => !q || String(c.other_user_name || "").toLowerCase().includes(q))
      .map(c => {
        const rawUnread = Number(c.unread_count || 0);
        const existing = App.chats.find(x => String(x.with?.id) === String(c.other_user_id));
        const chatId = existing?.id || `pm_${c.other_user_id}`;
        const muted = isChatMuted(chatId);
        const unread = muted ? 0 : rawUnread;

        if (!existing) {
          App.chats.unshift({
            id: chatId,
            with: {
              id: c.other_user_id,
              nick: c.other_user_name || `Użytkownik #${c.other_user_id}`,
              role: c.other_user_role || "user",
              company: c.other_user_company || "",
              bio: c.other_user_bio || "",
              avatarUrl: c.other_user_avatar_url || "",
              emoji: c.other_user_role === "partner" ? "🏷️" : "✉️",
            },
            last: c.last_message || "",
            unread,
            rawUnread,
            messages: [],
          });
        } else {
          existing.with = {
            ...(existing.with || {}),
            id: c.other_user_id,
            nick: c.other_user_name || existing.with?.nick || `Użytkownik #${c.other_user_id}`,
            role: c.other_user_role || existing.with?.role || "user",
            company: c.other_user_company || existing.with?.company || "",
            bio: c.other_user_bio || existing.with?.bio || "",
            avatarUrl: c.other_user_avatar_url || existing.with?.avatarUrl || "",
            emoji: existing.with?.emoji || (c.other_user_role === "partner" ? "🏷️" : "✉️"),
          };
          existing.last = c.last_message || existing.last || "";
          existing.unread = unread;
          existing.rawUnread = rawUnread;
        }

        return {
          id: chatId,
          with: {
            id: c.other_user_id,
            nick: c.other_user_name || `Użytkownik #${c.other_user_id}`,
            role: c.other_user_role || "user",
            company: c.other_user_company || "",
            bio: c.other_user_bio || "",
            avatarUrl: c.other_user_avatar_url || "",
            emoji: c.other_user_role === "partner" ? "🏷️" : "✉️",
          },
          last: c.last_message || "",
          unread,
          rawUnread,
        };
      });

    const finalChats = chats;

    if (!(finalChats || []).length) {
      list.innerHTML = '<div class="tMuted">Brak rozmów</div>';
    } else {
      list.innerHTML = (finalChats || []).map(c => {
        const muted = isChatMuted(c.id);
        return `
        <div class="listItem ${c.unread > 0 ? 'unread' : ''}" onclick="openChat('${c.id}')">
          <div class="listTop">
            <div class="listLeft">
              <div class="listAvatar">${c.with.emoji || "✉️"}</div>
              <div style="min-width:0;">
                <div class="listTitle">${c.with.nick}</div>
                <div class="listMeta">${c.last || "—"}</div>
              </div>
            </div>
            ${(muted || c.unread > 0) ? `<div class="listRight">${muted ? `<div style="font-size:14px;opacity:.7;">🔕</div>` : ``}${c.unread > 0 ? `<div class="badgeMini">${c.unread}</div>` : ``}</div>` : ``}
          </div>
        </div>
      `;
      }).join("");
    }

    const badge = $("badgePartnerMsgs");
    if (badge) {
      const totalUnread = (finalChats || []).reduce((sum, c) => sum + Number(c.unread || 0), 0);
      badge.textContent = String(totalUnread);
      badge.style.display = totalUnread > 0 ? "inline-flex" : "none";
    }
  } catch (err) {
    console.error("renderPartnerMsgList failed", err);
    list.innerHTML = '<div class="tMuted">Nie udało się załadować rozmów</div>';
  }
}

/* ------------------------- Interests (chips + suggestions) -------------------------- */
/**
 * We support 3 areas:
 * - Registration user: regInterestInput + regInterestChips + regInterestTypeahead
 * - Profile setup: interestInput + interestChips + interestTypeahead
 * - Settings: setInterestInput + setInterestChips + setInterestTypeahead
 *
 * Input behavior:
 * - User types (optionally with #)
 * - Press Enter or comma => add chip
 * - Clicking suggestion => add chip
 */
function initInterestInputs() {
  const configs = [
    { inputId: "regInterestInput", chipsId: "regInterestChips", taId: "regInterestTypeahead", target: "user" },
    { inputId: "interestInput", chipsId: "interestChips", taId: "interestTypeahead", target: "user" },
    { inputId: "setInterestInput", chipsId: "setInterestChips", taId: "setInterestTypeahead", target: "user" },
    { inputId: "peInterest", chipsId: null, taId: null, target: "event" }, // organizer create uses datalist only
  ];

  const suggestions = getInterestSuggestionsFromDatalist();

  configs.forEach(cfg => {
    const input = $(cfg.inputId);
    if (!input) return;
    const addBtn = cfg.inputId === "regInterestInput" ? $("regInterestAddBtn") : (cfg.inputId === "interestInput" ? $("interestAddBtn") : null);
    if (addBtn && !addBtn.dataset.bound) {
      addBtn.addEventListener("click", () => {
        const val = input.value.trim();
        if (!val) return;

        const parts = val
          .split(/[;,\n]+/)
          .map(x => normalizeTag(x))
          .filter(Boolean);

        if (!parts.length) return;

        parts.forEach(tag => addUserInterest(tag, cfg.chipsId));
        input.value = "";
        hideTypeahead(cfg.taId);
        renderAll();
      });
      addBtn.dataset.bound = "1";
    }

    // Key handlers
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === "," ) {
        e.preventDefault();
        const val = input.value.trim();
        const cleaned = normalizeTag(val);
        if (!cleaned) return;
        if (cfg.target === "user") addUserInterest(cleaned, cfg.chipsId);
        input.value = "";
        hideTypeahead(cfg.taId);
        renderAll();
      }
      if (e.key === "Escape") hideTypeahead(cfg.taId);
    });

    input.addEventListener("input", () => {
      if (!cfg.taId) return; // no typeahead needed
      const q = normalizeTag(input.value.trim());
      if (!q) { hideTypeahead(cfg.taId); return; }
      const items = suggestions
        .filter(s => s.toLowerCase().startsWith(q.toLowerCase()))
        .slice(0, 12);
      renderTypeahead(cfg.taId, items, (picked) => {
        addUserInterest(picked, cfg.chipsId);
        input.value = "";
        hideTypeahead(cfg.taId);
        renderAll();
      });
    });
  });

  // initial chips render
  renderInterestChips("regInterestChips");
  renderInterestChips("interestChips");
  refreshInterestUi();
  renderInterestChips("setInterestChips");
}

function getInterestSuggestionsFromDatalist() {
  const dl = $("interestsDatalist");
  if (!dl) return [];
  const opts = Array.from(dl.querySelectorAll("option"))
    .map(o => (o.getAttribute("value") || "").trim())
    .filter(Boolean);
  return Array.from(new Set(opts));
}

const INTEREST_CANONICAL_ALIASES = {
  "ai": "AI",
  "artificial intelligence": "AI",
  "ux/ui": "UX",
  "ui/ux": "UX",
  "user experience": "UX",
  "coffee": "kawa",
  "cafe": "kawiarnie",
  "tea": "herbata",
  "matcha tea": "matcha",
  "movies": "kino",
  "movie": "kino",
  "films": "filmy",
  "series": "seriale",
  "tv series": "seriale",
  "concert": "koncerty",
  "concerts": "koncerty",
  "festival": "festiwale",
  "festivals": "festiwale",
  "photography": "fotografia",
  "photo": "fotografia",
  "gym": "siłownia",
  "running": "bieganie",
  "walks": "spacer",
  "walking": "spacer",
  "hiking": "trekking",
  "mountains": "góry",
  "climbing": "wspinaczka",
  "yoga": "joga",
  "pilates workout": "pilates",
  "swimming": "pływanie",
  "dance": "taniec",
  "martial arts": "sztuki walki",
  "boxing": "boks",
  "technology": "technologia",
  "tech": "technologia",
  "programming": "programowanie",
  "coding": "programowanie",
  "board games": "planszówki",
  "boardgaming": "planszówki",
  "rpg games": "RPG",
  "esport": "e-sport",
  "anime shows": "anime",
  "mangas": "manga",
  "reading": "czytanie",
  "books": "książki",
  "personal growth": "rozwój osobisty",
  "languages": "nauka języków",
  "language learning": "nauka języków",
  "meditation": "medytacja",
  "science": "nauka",
  "drawing": "rysunek",
  "painting": "malarstwo",
  "graphics": "grafika",
  "illustration": "ilustracja",
  "ceramics": "ceramika",
  "crafts": "rękodzieło",
  "writing": "pisanie",
  "travel": "podróże",
  "travels": "podróże",
  "city breaks": "city break",
  "camping trips": "camping",
  "dogs": "psy",
  "cats": "koty",
  "animals": "zwierzęta",
  "plants": "rośliny",
  "volunteering": "wolontariat",
  "events": "eventy",
  "network": "networking",
  "business": "biznes",
  "content creation": "tworzenie treści",
  "video editing": "montaż wideo",
  "podcasts": "podcasty",
  "podcasting": "podcast",
  "standup": "stand-up",
  "comedy": "komedia",
  "cafes": "kawiarnie",
  "urban culture": "kultura miejska",
  "architecture": "architektura",
  "fashion": "moda",
  "skincare": "pielęgnacja",
  "tattoos": "tatuaże",
  "cars": "motoryzacja",
  "motorcycles": "motocykle",
  "vinyl": "winyle",
  "logic games": "gry logiczne",
  "crosswords": "krzyżówki",
  "puzzles": "łamigłówki",
  "escape rooms": "escape roomy",
  "crypto": "kryptowaluty",
  "personal finance": "finanse osobiste",
  "investing": "inwestowanie",
  "real estate": "nieruchomości",
  "healthy food": "zdrowe jedzenie",
  "meal prep sunday": "meal prep",
  "eco": "ekologia",
  "recycling": "recykling",
  "planning": "planowanie",
  "organization": "organizacja",
  "mindset work": "mindset",
};

function normalizeTag(val) {
  if (!val) return "";

  const raw = val.replace(/^#/, "").trim().replace(/\s+/g, " ").slice(0, 40);
  if (!raw) return "";

  const suggestions = getInterestSuggestionsFromDatalist();
  const canonicalByLower = new Map(suggestions.map(x => [x.toLowerCase(), x]));

  const lower = raw.toLowerCase();
  if (canonicalByLower.has(lower)) {
    return canonicalByLower.get(lower);
  }

  const aliasTarget = INTEREST_CANONICAL_ALIASES[lower];
  if (aliasTarget) {
    return canonicalByLower.get(aliasTarget.toLowerCase()) || aliasTarget;
  }

  return raw;
}


function normalizeCity(raw) {
  const value = String(raw || "")
    .replace(/\s+/g, " ")
    .trim();

  if (!value) return "";

  const aliases = {
    "wawa": "Warszawa",
    "warszawa": "Warszawa",
    "krakow": "Kraków",
    "kraków": "Kraków",
    "gdansk": "Gdańsk",
    "gdańsk": "Gdańsk",
    "wroclaw": "Wrocław",
    "wrocław": "Wrocław",
    "poznan": "Poznań",
    "poznań": "Poznań"
  };

  const lower = value.toLocaleLowerCase("pl-PL");
  if (aliases[lower]) return aliases[lower];

  return value
    .toLocaleLowerCase("pl-PL")
    .replace(/(^|[\s-])([\p{L}])/gu, (_, sep, ch) => sep + ch.toLocaleUpperCase("pl-PL"));
}

async function syncUserInterests() {
  if (!App.isLoggedIn || App.role !== "user") return;

  try {
    const data = await apiFetch("/users/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        zainteresowania: Array.isArray(App.user.interests) ? App.user.interests : [],
      }),
    });

    if (data?.success && data?.data) {
      const backendInterests = Array.isArray(data.data.zainteresowania) ? data.data.zainteresowania : [];
      App.user.interests = backendInterests;
      try { localStorage.setItem("usly_user_interests", JSON.stringify(backendInterests)); } catch(_) {}
      renderInterestChips("setInterestChips");
      renderInterestChips("interestChips");
      renderInterestChips("regInterestChips");
    }
  } catch (err) {
    console.error("syncUserInterests failed", err);
  }
}

function addUserInterest(tag, chipsId) {
  const t = normalizeTag(tag);
  if (!t) return;
  const exists = App.user.interests.some(x => x.toLowerCase() === t.toLowerCase());
  if (exists) {
    toast("To zainteresowanie już jest dodane");
    return;
  }
  const count = Array.isArray(App.user.interests) ? App.user.interests.length : 0;
  if (!canAddMoreInterests(count)) {
    toast("Limit zainteresowań osiągnięty • Odblokuj więcej w planie PLUS");
    return;
  }

  App.user.interests.push(t);
  try { localStorage.setItem("usly_user_interests", JSON.stringify(App.user.interests)); } catch(_) {}
  renderInterestChips(chipsId);
  syncUserInterests();
  toast(`Dodano #${t}`);
}

function removeUserInterest(tag, chipsId) {
  const t = normalizeTag(tag);
  App.user.interests = App.user.interests.filter(x => x.toLowerCase() !== t.toLowerCase());
  try { localStorage.setItem("usly_user_interests", JSON.stringify(App.user.interests)); } catch(_) {}
  refreshInterestUi();
  renderInterestChips(chipsId);
  syncUserInterests();
  toast(`Usunięto #${t}`);
}

function renderInterestChips(chipsId) {
  const box = $(chipsId);
  if (!box) return;

  box.innerHTML = "";
  App.user.interests.forEach(t => {
    const chip = makeChip(`#${t}`, () => removeUserInterest(t, chipsId));
    box.appendChild(chip);
  });
}

function makeChip(text, onRemove) {
  const span = document.createElement("div");
  span.className = "chip";
  span.textContent = text;
  if (onRemove) {
    span.title = "Kliknij, aby usunąć";
    span.addEventListener("click", onRemove);
  }
  return span;
}

function getPartnerCategoryLabel(value) {
  const key = String(value || "").trim().toLowerCase();
  const map = {
    gastro: "Gastro / restauracja / kawiarnia",
    bar_nocne: "Bar / klub / nightlife",
    kultura: "Kultura / koncerty / sztuka",
    fitness: "Fitness / sport / wellness",
    beauty: "Beauty / uroda",
    hotel_event: "Hotel / event / konferencje",
    rozrywka: "Rozrywka / atrakcje / gaming",
    zakupy: "Sklep / showroom / zakupy",
    edukacja: "Edukacja / warsztaty",
    cowork: "Cowork / biznes / networking",
    plener: "Plener / turystyka / rekreacja",
    inne: "Inne / trudno powiedzieć",
  };
  return map[key] || String(value || "").trim();
}

function renderTypeahead(taId, items, onPick) {
  const box = $(taId);
  if (!box) return;
  if (!items.length) { hideTypeahead(taId); return; }

  box.classList.add("open");
  box.innerHTML = items.map(x => `<div class="taItem" data-val="${escapeHtml(x)}">#${escapeHtml(x)}</div>`).join("");

  Array.from(box.querySelectorAll(".taItem")).forEach(item => {
    item.addEventListener("click", () => {
      const val = item.getAttribute("data-val") || "";
      onPick?.(val);
    });
  });
}

function hideTypeahead(taId) {
  const box = $(taId);
  if (!box) return;
  box.classList.remove("open");
  box.innerHTML = "";
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* ------------------------- Age sliders -------------------------- */
function initAgeSliders() {
  // Registration
  const regFrom = $("regPrefAgeFrom");
  const regTo = $("regPrefAgeTo");
  const regFromVal = $("regPrefAgeFromVal");
  const regToVal = $("regPrefAgeToVal");

  if (regFrom && regTo) {
    const upd = () => {
      const f = Number(regFrom.value || 16);
      const t = Number(regTo.value || 99);
      if (regFromVal) regFromVal.textContent = String(f);
      if (regToVal) regToVal.textContent = String(t);
    };
    regFrom.addEventListener("input", upd);
    regTo.addEventListener("input", upd);
    upd();
  }

  // Settings
  const setFrom = $("setPrefAgeFrom");
  const setTo = $("setPrefAgeTo");
  const setFromVal = $("setPrefAgeFromVal");
  const setToVal = $("setPrefAgeToVal");

  if (setFrom && setTo) {
    const setAgeAny = $("setAgeAny");
    const syncAgeAnyUi = () => {
      const disabled = !!setAgeAny?.checked;
      setFrom.disabled = disabled;
      setTo.disabled = disabled;
      setFrom.style.opacity = disabled ? ".55" : "";
      setTo.style.opacity = disabled ? ".55" : "";
      setFrom.style.cursor = disabled ? "not-allowed" : "";
      setTo.style.cursor = disabled ? "not-allowed" : "";
    };

    const upd2 = () => {
      const f = Number(setFrom.value || 16);
      const t = Number(setTo.value || 99);
      if (setFromVal) setFromVal.textContent = String(f);
      if (setToVal) setToVal.textContent = String(t);
      syncAgeAnyUi();
    };
    setFrom.addEventListener("input", upd2);
    setTo.addEventListener("input", upd2);
    setAgeAny?.addEventListener("change", syncAgeAnyUi);
    upd2();
  }

  // Setup ageAny toggle
  const setupAgeAny = $("setupAgeAny");
  const setupFrom = $("setupPrefAgeFrom");
  const setupTo = $("setupPrefAgeTo");

  if (setupAgeAny && setupFrom && setupTo) {
    const updateSetupAgeState = () => {
      const disabled = !!setupAgeAny.checked;
      setupFrom.disabled = disabled;
      setupTo.disabled = disabled;
      setupFrom.style.opacity = disabled ? "0.5" : "1";
      setupTo.style.opacity = disabled ? "0.5" : "1";
      setupFrom.style.cursor = disabled ? "not-allowed" : "";
      setupTo.style.cursor = disabled ? "not-allowed" : "";
    };

    setupAgeAny.addEventListener("change", updateSetupAgeState);
    updateSetupAgeState();
  }
}

/* ------------------------- Char counters -------------------------- */
function initCharCounters() {
  // Setup bio
  const setupBio = $("setupBio");
  if (setupBio) {
    setupBio.addEventListener("input", () => safeSetText("bioCount", String(setupBio.value.length)));
    safeSetText("bioCount", String(setupBio.value.length));
  }

  // Settings bio
  const setBio = $("setBio");
  if (setBio) {
    setBio.addEventListener("input", () => safeSetText("setBioCount", String(setBio.value.length)));
    safeSetText("setBioCount", String(setBio.value.length));
  }

  // Partner about
  const regOrgAbout = $("regOrgAbout");
  if (regOrgAbout) {
    regOrgAbout.addEventListener("input", () => safeSetText("regOrgAboutCount", String(regOrgAbout.value.length)));
    safeSetText("regOrgAboutCount", String(regOrgAbout.value.length));
  }
  const setOrgAbout = $("setOrgAbout");
  if (setOrgAbout) {
    setOrgAbout.addEventListener("input", () => safeSetText("setOrgAboutCount", String(setOrgAbout.value.length)));
    safeSetText("setOrgAboutCount", String(setOrgAbout.value.length));
  }
}

/* ------------------------- Geolocation (punkt 12) -------------------------- */
function initGeolocation() {
  // REQUIRED: bind by id="btnUseLocation" without inline onclick
  const btn = $("btnUseLocation");
  if (!btn) return;

  btn.addEventListener("click", useCurrentLocationForCity);
}

// Global function name as requested (punkt 12)
function useCurrentLocationForCity() {
  if (!navigator.geolocation) {
    toast("Geolokalizacja niedostępna w tej przeglądarce");
    return;
  }

  toast("Pobieram lokalizację…");
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;

      // Save to hidden fields (backend-ready)
      const latEl = $("regGeoLat");
      const lngEl = $("regGeoLng");
      if (latEl) latEl.value = String(lat);
      if (lngEl) lngEl.value = String(lng);

      App.user.geo.lat = String(lat);
      App.user.geo.lng = String(lng);

      const city = $("regCity");
      if (city && App.role === "user") city.value = "Pobieramy miasto...";

      fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lng)}&zoom=10&addressdetails=1`)
        .then((r) => r.ok ? r.json() : null)
        .then((geoData) => {
          const a = geoData?.address || {};
          const cityName = a.city || a.town || a.village || a.municipality || a.county || "";
          if (cityName) {
            App.user.city = cityName;
            if (city && App.role === "user") city.value = cityName;
          } else if (city && App.role === "user") {
            city.value = "Lokalizacja pobrana";
          }
          toast("Lokalizacja ustawiona");
        })
        .catch(() => {
          if (city && App.role === "user") city.value = "Lokalizacja pobrana";
          toast("Lokalizacja ustawiona");
        });
    },
    () => {
      const city = $("regCity");
      if (city && App.role === "user") city.value = "Włącz lokalizację, aby kontynuować";
      toast("Nie udało się pobrać lokalizacji (brak zgody?)");
    },
    { enableHighAccuracy: true, timeout: 8000, maximumAge: 120000 }
  );
}

/* ------------------------- Tabbar + Active states -------------------------- */
function updateTabbars() {
  const userBar = $("tabbarUser");
  const partnerBar = $("tabbarPartner");

  const publicViews = ["S0_WELCOME", "S1_LOGIN", "S2_REGISTER"];
  if (!App.isLoggedIn || publicViews.includes(App.currentView)) {
    hide(userBar);
    hide(partnerBar);
    return;
  }

  // Show only relevant bar
  if (App.role === "user") {
    show(userBar);
    hide(partnerBar);
  } else {
    hide(userBar);
    show(partnerBar);
  }

  // Active tab highlight based on current view
  setActiveTabs();
}

function setActiveTabs() {
  // clear
  document.querySelectorAll(".tabbar button").forEach(b => b.classList.remove("active", "on"));

  const v = App.currentView;

  // User tabs
  if (App.role === "user") {
    if (v.startsWith("S4")) $("tabNearby")?.classList.add("active");
    else if (v.startsWith("S6")) $("tabChats")?.classList.add("active");
    else if (v.startsWith("S7")) $("tabEvents")?.classList.add("active");
    else if (v.startsWith("S8")) $("tabGroups")?.classList.add("active");
    else if (v.startsWith("S10")) $("tabSettingsUser")?.classList.add("active");
  } else {
    // Partner tabs
    if (v === "S9_PARTNER") $("ptabDash")?.classList.add("active");
    else if (v === "S9_PARTNER_CREATE") $("ptabCreate")?.classList.add("active");
    else if (v === "S9_PARTNER_EVENTS") $("ptabMyEvents")?.classList.add("active");
    else if (v === "S9_PARTNER_MESSAGES") $("ptabMsgs")?.classList.add("active");
    else if (v.startsWith("S10")) $("ptabSettings")?.classList.add("active");
  }
}

/* ------------------------- Helpers: matching interests -------------------------- */
function commonInterests(person) {
  const a = (App.user.interests || []).map(x => x.toLowerCase());
  const b = (person.interests || []).map(x => x.toLowerCase());
  return a.filter(x => b.includes(x));
}

function sharedScore(person) {
  const common = commonInterests(person).length;
  const base = Math.max(1, App.user.interests.length);
  return Math.min(99, Math.round((common / base) * 100));
}


function formatDistanceFromMe(person) {
  const d = Number(person?.distance_km);
  if (!Number.isFinite(d)) return "";
  if (d < 1) return "< 1 km od Ciebie";
  return `${String(Math.round(d * 10) / 10).replace(".", ",")} km od Ciebie`;
}

function suggestPeopleByInterest(tag) {
  const t = tag.toLowerCase();
  return App.people.filter(p => (p.interests || []).map(x => x.toLowerCase()).includes(t));
}

function matchesUserEventInterest(ev) {
  const mine = (App.user.interests || []).map(x => String(x).toLowerCase());
  const tag = String(ev?.interest || "").toLowerCase();
  return !!tag && mine.includes(tag);
}

function isEventInMyCity(ev) {
  return String(ev?.city || "").trim().toLowerCase() === String(App.user.city || "").trim().toLowerCase();
}

function priceLabel(ev) {
  if (ev.paidMode === "paid_fixed") return `${ev.price} zł`;
  if (ev.paidMode === "paid_range") return `${ev.priceFrom}–${ev.priceTo} zł`;
  return "0 zł";
}

function mapApiPersonToViewModel(p) {
  return {
    id: String(p.user_id),
    nick: p.nick || "Uzytkownik",
    city: p.miasto || "",
    age: Number.isFinite(Number(p.age)) ? Number(p.age) : 0,
    emoji: "🙂",
    interests: Array.isArray(p.zainteresowania) ? p.zainteresowania : [],
    bio: p.bio || "",
    avatarUrl: p.avatar_url || "",
    distance_km: p.distance_km ?? null,
  };
}

function mapApiGroupToViewModel(g) {
  return {
    id: String(g.id),
    title: g.title || "Grupa",
    interestTag: g.interest_tag || "",
    members: Number(g.members_count || 0),
    desc: g.description || "",
    isCreator: !!g.is_creator,
  };
}

function toLocalDateTimeInputValue(value) {
  if (!value) return "";
  const raw = String(value).trim().replace(" ", "T");
  const normalized = /[zZ]|[+-]\d\d:\d\d$/.test(raw) ? raw : `${raw}Z`;
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return raw.slice(0, 16);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function toLocalApiDateTime(value) {
  if (!value) return null;
  const raw = String(value).trim();
  return raw.length === 16 ? `${raw}:00` : raw;
}

function addHourToLocalDateTime(value) {
  const raw = String(value || "").trim();
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return null;
  const shifted = new Date(d.getTime() + 60 * 60 * 1000);
  const pad = (n) => String(n).padStart(2, "0");
  return `${shifted.getFullYear()}-${pad(shifted.getMonth() + 1)}-${pad(shifted.getDate())}T${pad(shifted.getHours())}:${pad(shifted.getMinutes())}:00`;
}

function mapApiEventToViewModel(e) {
  const start = e?.start_at ? new Date(e.start_at) : null;
  const when =
    start && !Number.isNaN(start.getTime())
      ? start.toLocaleString("pl-PL", {
          day: "2-digit",
          month: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        })
      : "Termin wkrótce";

  return {
    id: String(e.id),
    title: e.title || "Wydarzenie",
    city: e.city || "",
    when: when,
    where: e.where || e.location || "",
    interest: normalizeTag(
      e.interest_tag ||
      e.interest ||
      e.category ||
      e.tag ||
      "wydarzenie"
    ),
    desc: e.description || "",
    status: e.status || "draft",
    start_at: e.start_at || null,
    end_at: e.end_at || null,
    paidMode: e.pricing_type || "free",
    price: typeof e.price_fixed === "number" ? Math.round(e.price_fixed / 100) : null,
    priceFrom: typeof e.price_min === "number" ? Math.round(e.price_min / 100) : null,
    priceTo: typeof e.price_max === "number" ? Math.round(e.price_max / 100) : null,
    ticketLink: e.payment_link || "#",
    saved: false,
    interested: false,
    capacity: e.capacity ?? null,
    signupsCount: Number(e.signups_count || 0),
    spotsLeft: e.spots_left ?? null,
    organizer: {
      id: String(e.partner_user_id || e.organizer_id || ""),
      name:
        e.partner_name ||
        e.organizer_name ||
        e.partner_company ||
        e.company ||
        "Organizator",
      category:
        e.partner_category ||
        e.organizer_category ||
        e.kategoria_organizatora ||
        "",
      bio:
        e.partner_bio ||
        e.organizer_bio ||
        "",
      logoUrl:
        e.partner_logo_url ||
        e.organizer_logo_url ||
        "",
    },
  };
}


async function loadNearbyPeople() {
  try {
    const data = await apiFetch("/users/nearby?limit=20");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];
    App.people = items.map(mapApiPersonToViewModel);
    return true;
  } catch (err) {
    console.error("loadNearbyPeople failed", err);
    return false;
  }
}

async function loadEvents() {
  try {
    const data = await apiFetch("/events?limit=100");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    let joinedIds = new Set();
    try {
      const mine = await apiFetch("/users/me/events?limit=100");
      const myItems = Array.isArray(mine?.data?.items) ? mine.data.items : [];
      joinedIds = new Set(
        myItems
          .map(x => x?.signup?.event_id ?? x?.event?.id)
          .filter(v => v != null)
          .map(v => String(v))
      );
    } catch (err) {
      console.error("loadEvents joined state failed", err);
    }

    let savedIds = new Set();
    try {
      const savedRes = await apiFetch("/users/me/saved-events?limit=100");
      const savedItems = Array.isArray(savedRes?.data?.items) ? savedRes.data.items : [];
      savedIds = new Set(
        savedItems
          .map(x => x?.saved?.event_id ?? x?.event?.id)
          .filter(v => v != null)
          .map(v => String(v))
      );
    } catch (err) {
      console.error("loadEvents saved state failed", err);
    }

    App.events = items.map(raw => {
      const ev = mapApiEventToViewModel(raw);
      ev.interested = joinedIds.has(String(ev.id));
      ev.saved = savedIds.has(String(ev.id));
      return ev;
    });

    return true;
  } catch (err) {
    console.error("loadEvents failed", err);
    return false;
  }
}


async function loadMyGroups() {
  try {
    const data = await apiFetch("/groups/my");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];
    App.myGroups = items.map(mapApiGroupToViewModel);
    return true;
  } catch (err) {
    console.error("loadMyGroups failed", err);
    App.myGroups = [];
    return false;
  }
}

async function loadGroups() {
  try {
    const data = await apiFetch("/groups/suggested");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];
    App.groups = items.map(mapApiGroupToViewModel);
    return true;
  } catch (err) {
    console.error("loadGroups failed", err);
    App.groups = [];
    return false;
  }
}

async function loadPartnerEvents() {
  try {
    const data = await apiFetch("/partners/events?limit=100");
    const items = Array.isArray(data?.data?.items) ? data.data.items : [];

    const enriched = await Promise.all(
      items.map(async (ev) => {
        try {
          const stats = await apiFetch(`/partners/events/${ev.id}/stats`);
          return {
            ...ev,
            signups_count: Number(stats?.data?.signups_count || 0),
            spots_left: stats?.data?.spots_left ?? null,
            capacity: stats?.data?.capacity ?? null,
          };
        } catch (err) {
          console.error(`loadPartnerEvents stats failed for event ${ev.id}`, err);
          return {
            ...ev,
            signups_count: 0,
            spots_left: null,
            capacity: null,
          };
        }
      })
    );

    App.partnerEvents = enriched;
    return true;
  } catch (err) {
    console.error("loadPartnerEvents failed", err);
    App.partnerEvents = [];
    return false;
  }
}

/* ------------------------- Render All -------------------------- */
function renderAll() {
  // Keep role labels consistent
  safeSetText("roleLabelLogin", App.role === "user" ? "Towarzysz" : "Organizator");
  safeSetText("roleLabelRegister", App.role === "user" ? "Towarzysz" : "Organizator");

  // Plan pills
  safeSetText("planPillSetup", App.user.plan.toUpperCase());
  document.querySelectorAll("#partnerPlanPill").forEach((el) => {
    el.textContent = String(App.partner.plan || "free").toUpperCase();
  });

  [
    "uplan_free", "uplan_plus", "uplan_premium", "uplan_vip",
    "uplan_free_set", "uplan_plus_set", "uplan_premium_set", "uplan_vip_set",
  ].forEach((id) => {
    const b = $(id);
    if (!b) return;
    const isOn = b.dataset.plan === String(App.user.plan || "free");
    b.classList.toggle("on", isOn);
    b.classList.toggle("active", isOn);
  });

  [
    "pplan_free", "pplan_pro", "pplan_premium", "pplan_enterprise",
    "pplan_free_set", "pplan_pro_set", "pplan_premium_set", "pplan_enterprise_set",
  ].forEach((id) => {
    const b = $(id);
    if (!b) return;
    const isOn = b.dataset.plan === String(App.partner.plan || "free");
    b.classList.toggle("on", isOn);
    b.classList.toggle("active", isOn);
  });

  refreshUserPlanCardsUi();

  document.querySelectorAll('#S11_PLANS #plansPartnerOnly .card[data-plan]').forEach((card) => {
    const currentPlan = String(App.partner.plan || "free").toLowerCase();
    const isCurrent = String(card.dataset.plan || "").toLowerCase() === currentPlan;
    card.classList.toggle("is-current", isCurrent);
    const btn = card.querySelector(".btn");
    if (btn) btn.textContent = isCurrent ? "Aktualny plan" : "Wybierz";
  });

  if (App.currentView === "S3_PROFILE_SETUP") {
    if ($("setupNick")) $("setupNick").value = App.user.nick || "";
    const setupCity = $("setupCity");
    if (setupCity && App.user.city && setupCity.value !== "Pobieranie lokalizacji...") {
      setupCity.value = App.user.city;
    }
    if ($("setupBio")) $("setupBio").value = App.user.bio || "";
    if ($("setupNearbyRadiusKm")) $("setupNearbyRadiusKm").value = String(App.user.nearbyRadiusKm || 25);
    if ($("setPrefAgeFrom")) $("setPrefAgeFrom").value = String(App.user.prefAgeFrom);
    if ($("setPrefAgeTo")) $("setPrefAgeTo").value = String(App.user.prefAgeTo);
    safeSetText("setupAgeDisplay", `Wiek: ${App.user.age || "—"} lat`);
    safeSetText("bioCount", String(($("setupBio")?.value || "").length));
  }

  // Partner plan line in dashboard
  const partnerHubName = $("partnerHubName");
  if (partnerHubName) {
    partnerHubName.textContent = App.partner.company || "Twoje miejsce";
  }

  const partnerHubMeta = $("partnerHubMeta");
  if (partnerHubMeta) {
    const partnerCategoryLabels = {
      gastro: "Gastro / restauracja / kawiarnia",
      bar_nocne: "Bar / klub / nightlife",
      kultura: "Kultura / koncerty / sztuka",
      fitness: "Fitness / sport / wellness",
      beauty: "Beauty / uroda",
      hotel_event: "Hotel / event / konferencje",
      rozrywka: "Rozrywka / atrakcje / gaming",
      zakupy: "Sklep / showroom / zakupy",
      edukacja: "Edukacja / warsztaty i szkolenia",
      cowork: "Cowork / biznes / networking",
      plener: "Plener / turystyka / rekreacja",
      inne: "Inne / trudno powiedzieć"
    };
    const categoryLabel = partnerCategoryLabels[App.partner.category] || App.partner.category || "";
    const meta = [categoryLabel, App.partner.city].filter(Boolean).join(" • ");
    partnerHubMeta.textContent = meta || "Uzupełnij profil organizatora, aby pokazać markę i ofertę w lepszy sposób.";
  }

  const partnerHubLogoPreview = $("partnerHubLogoPreview");
  if (partnerHubLogoPreview) {
    if (App.partner.logoUrl) {
      const src = String(App.partner.logoUrl).startsWith("http")
        ? App.partner.logoUrl
        : `${API_BASE_URL}${App.partner.logoUrl}`;
      partnerHubLogoPreview.innerHTML = `<img src="${src}" alt="Logo organizatora" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`;
    } else {
      partnerHubLogoPreview.innerHTML = "";
      partnerHubLogoPreview.textContent = "🏷️";
    }
  }

  const planLine = $("partnerPlanLine");
  if (planLine) {
    planLine.textContent = `Plan ${String(App.partner.plan || "free").toUpperCase()} jest teraz aktywny.`;
  }

  // Partner analytics in profile hub
  const partnerStatsGrid = $("partnerStatsGrid");
  if (partnerStatsGrid) {
    const metricCards = partnerStatsGrid.querySelectorAll(".metricCard");
    const partnerPlanOrder = ["free", "pro", "premium", "enterprise"];
    const currentPartnerPlan = String(App.partner?.plan || "free").toLowerCase();
    const currentPartnerPlanIndex = Math.max(0, partnerPlanOrder.indexOf(currentPartnerPlan));

    metricCards.forEach((card) => {
      const minPlan = String(card.dataset.minPlan || "free").toLowerCase();
      const minPlanIndex = Math.max(0, partnerPlanOrder.indexOf(minPlan));
      card.style.display = currentPartnerPlanIndex >= minPlanIndex ? "" : "none";
    });

    if (metricCards[0]) {
      const label = metricCards[0].querySelector(".metricLabel");
      const sub = metricCards[0].querySelector(".metricSub");
      if (label) label.textContent = "Aktywne";
      if (sub) sub.textContent = "Opublikowane teraz";
    }

    if (metricCards[1]) {
      const label = metricCards[1].querySelector(".metricLabel");
      const sub = metricCards[1].querySelector(".metricSub");
      if (label) label.textContent = "Szkice";
      if (sub) sub.textContent = "Robocze";
    }

    if (metricCards[2]) {
      const label = metricCards[2].querySelector(".metricLabel");
      const sub = metricCards[2].querySelector(".metricSub");
      if (label) label.textContent = "Zapisy (łącznie)";
      if (sub) sub.textContent = "Do aktywnych";
    }

    if (metricCards[3]) {
      const label = metricCards[3].querySelector(".metricLabel");
      const sub = metricCards[3].querySelector(".metricSub");
      if (label) label.textContent = "Frekwencja";
      if (sub) sub.textContent = "W aktywnych";
    }

    safeSetText("m_events_val", "—");
    safeSetText("m_views_val", "—");
    safeSetText("m_clicks_val", "—");
    safeSetText("m_conv_val", "—");

    (App.role === "partner" ? apiFetch("/partners/dashboard/stats") : Promise.resolve(null))
      .then((res) => {
        if (!res?.success || !res?.data) return;

        safeSetText("m_events_val", String(res.data.total_events ?? 0));
        safeSetText("m_views_val", String(res.data.draft_events ?? 0));
        safeSetText("m_clicks_val", String(res.data.total_signups ?? 0));
        const signups = Number(res.data.total_signups ?? 0);
        const capacity = Number(res.data.total_capacity ?? 0);
        const freq = capacity > 0 ? Math.round((signups / capacity) * 100) : 0;
        safeSetText("m_conv_val", capacity > 0 ? `${freq}%` : "—");
      })
      .catch(() => {
        safeSetText("m_events_val", "—");
        safeSetText("m_views_val", "—");
        safeSetText("m_clicks_val", "—");
        safeSetText("m_conv_val", "—");
      });
  }

  // Setup avatar
  const renderAvatarBox = (el) => {
    if (!el) return;
    if (App.user.avatarUrl) {
      const src = String(App.user.avatarUrl).startsWith("http")
        ? App.user.avatarUrl
        : `${API_BASE_URL}${App.user.avatarUrl}`;
      el.innerHTML = `<img src="${src}" alt="Awatar użytkownika" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`;
    } else {
      el.innerHTML = "";
      el.textContent = "👤";
    }
  };

  renderAvatarBox($("userAvatar"));
  renderAvatarBox($("settingsUserAvatarPreview"));

  // Fill settings inputs moved out of renderAll to avoid overwriting unsaved form edits

  // Settings range values
  if ($("setPrefAgeFrom")) $("setPrefAgeFrom").value = String(App.user.prefAgeFrom ?? 18);
  if ($("setPrefAgeTo")) $("setPrefAgeTo").value = String(App.user.prefAgeTo ?? 99);
  if ($("setAgeAny")) $("setAgeAny").checked = App.user.prefAgeFrom == null && App.user.prefAgeTo == null;
  safeSetText("setPrefAgeFromVal", String(App.user.prefAgeFrom ?? 18));
  safeSetText("setPrefAgeToVal", String(App.user.prefAgeTo ?? 99));
  $("setAgeAny")?.dispatchEvent(new Event("change"));

  // Partner settings
  if ($("setOrgCompany")) $("setOrgCompany").value = App.partner.company || "";
  if ($("setOrgCategory")) $("setOrgCategory").value = App.partner.category || "inne";
  if ($("setOrgCity")) $("setOrgCity").value = App.partner.city || "Warszawa";
  if ($("setOrgAbout")) $("setOrgAbout").value = App.partner.about || "";

  const orgLogoPreview = $("setOrgLogoPreview");
  if (orgLogoPreview) {
    if (App.partner.logoUrl) {
      const src = String(App.partner.logoUrl).startsWith("http")
        ? App.partner.logoUrl
        : `${API_BASE_URL}${App.partner.logoUrl}`;
      orgLogoPreview.innerHTML = `<img src="${src}" alt="Logo organizatora" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" />`;
    } else {
      orgLogoPreview.textContent = App.partner.logoEmoji || "🏷️";
    }
  }

  // Interest chips in visible sections
  renderInterestChips("interestChips");
  refreshInterestUi();
  renderInterestChips("setInterestChips");
  renderInterestChips("regInterestChips");

  // Lists
  if (App.currentView === "S4_NEARBY") renderNearby();
  if (App.currentView === "S7_EVENTS") renderEventsList();
  if (App.currentView === "S8_GROUPS") renderGroups();
  if (App.currentView === "S6_CHATS_LIST") renderChatList();
  if (App.currentView === "S6B_CHAT_THREAD") renderChatThread();
  if (App.currentView === "S9_PARTNER_EVENTS") renderPartnerEvents();
  if (App.currentView === "S9_PARTNER_MESSAGES") renderPartnerMsgList();
  if (App.role === "user" && !["S2_REGISTER","S3_PROFILE_SETUP"].includes(App.currentView)) refreshNotifBadgeCount();
  if (App.role === "user" && !["S2_REGISTER","S3_PROFILE_SETUP"].includes(App.currentView)) refreshGroupBadgeCount();
  if (App.role === "partner") refreshPartnerNotifBadgeCount();
  if (App.role === "partner") refreshPartnerMsgBadgeCount();
  if (App.currentView === "S12_NOTIFICATIONS") renderNotifications();

  // tabbar active
  updateTabbars();
}

/* ------------------------- Search bindings -------------------------- */
function initSearchBindings() {
  $("nearbyPeopleSearch")?.addEventListener("input", renderNearby);
  $("eventsSearch")?.addEventListener("input", renderEventsList);
  $("groupSearch")?.addEventListener("input", renderGroups);
  $("chatSearch")?.addEventListener("input", renderChatList);

  // === polling wiadomości ===
  let inboxPollStarted = false;
  function startInboxPolling() {
    if (inboxPollStarted) return;
    inboxPollStarted = true;

    setInterval(async () => {
      if (!App.isLoggedIn) return;

      try {
        if (App.role === "partner") {
          await refreshPartnerNotifBadgeCount();
          await refreshPartnerMsgBadgeCount();

          if (App.currentView === "S12_NOTIFICATIONS") {
            await renderNotifications();
          }

          return;
        }

        await refreshNotifBadgeCount();

        if (App.currentView === "S10E_PROFILE_INVITES") {
          await refreshProfileRelations();
        }

        if (App.currentView === "S12_NOTIFICATIONS") {
          await renderNotifications();
        }

        await renderChatList();
        if (App.currentView === "S6B_CHAT_THREAD" && App.selectedChatUserId) {
          await renderChatThread();
        }
      } catch (err) {
        console.error("inbox polling failed", err);
      }
    }, 10000);
  }

  startInboxPolling();
  $("partnerMsgSearch")?.addEventListener("input", renderPartnerMsgList);
}

/* ------------------------- App Init -------------------------- */
async function init() {
  // Start view
  go("S0_WELCOME");

  // init hooks
  initGeolocation();
  initAgeSliders();
  initCharCounters();
  initInterestInputs();
  initSearchBindings();
  initPartnerLogoUpload();
  initPartnerPricingFields();
  syncPartnerEventSubmitBtn();

  // Default role toggle UI
  selectRole(App.role);

  // Default plan selections are synced passively in renderAll()/session restore.

  const regBirthDate = $("regBirthDate");
  const ageError = $("ageError");
  if (regBirthDate && ageError && regBirthDate.dataset.bound !== "1") {
    regBirthDate.addEventListener("input", () => {
      ageError.style.display = "none";
      ageError.textContent = "Nie możesz się zarejestrować – wymagane jest ukończone 18 lat.";
    });
    regBirthDate.dataset.bound = "1";
  }

  // Default events tab
  setEventsTab(App.eventsTab);
  refreshUserPlanCardsUi();

  // Default: logged out
  $("appRoot")?.classList.toggle("isLoggedIn", App.isLoggedIn);
  updateTabbars();
  // initAuthMvp(); // martwy debug auth flow

  const token = localStorage.getItem("usly_token");

  if (token) {
    try {
      const me = await apiFetch("/auth/me");
      App.currentUserId = me?.id ?? me?.data?.id ?? null;
      App.role = (me?.data?.role || me?.role) === "partner" ? "partner" : "user";
      selectRole(App.role);
      App.isLoggedIn = true;
      $("appRoot")?.classList.add("isLoggedIn");
      updateTabbars();

      if (App.role === "user") {
        const profile = await apiFetch("/users/me");
        if (profile?.success && profile?.data) {
          App.user.nick = profile.data.nick || App.user.nick;
          App.user.city = profile.data.miasto || App.user.city;
          App.user.bio = profile.data.bio || "";
          App.user.interests = Array.isArray(profile.data.zainteresowania) ? profile.data.zainteresowania : [];
          App.user.prefAgeFrom = Object.prototype.hasOwnProperty.call(profile.data, "age_min") ? profile.data.age_min : App.user.prefAgeFrom;
          App.user.prefAgeTo = Object.prototype.hasOwnProperty.call(profile.data, "age_max") ? profile.data.age_max : App.user.prefAgeTo;
          App.user.plan = profile.data.plan || App.user.plan;
          App.user.avatarUrl = profile.data.avatar_url || App.user.avatarUrl || "";
          try { localStorage.setItem(USLY_STORAGE_KEYS.userPlan, App.user.plan); } catch (_) {}
          refreshUserPlanCardsUi();
          }
        await Promise.all([loadNearbyPeople(), loadEvents(), loadMyGroups(), loadGroups(), renderChatList()]);
        renderAll();
        bindMessageInputs();
        go("S4_NEARBY");
        return;
      } else {
        await loadPartnerProfile();
        try { localStorage.setItem(USLY_STORAGE_KEYS.partnerPlan, App.partner.plan || "free"); } catch (_) {}
        await loadPartnerEvents();
        renderAll();
        bindMessageInputs();
        go("S9_PARTNER");
        return;
      }
    } catch (err) {
      console.error("init session restore failed", err);
      try { localStorage.removeItem("usly_token"); } catch (_) {}
      App.isLoggedIn = false;
    }
  }

  Promise.all([loadNearbyPeople(), loadEvents(), loadMyGroups(), loadGroups(), renderChatList()]).finally(() => {
    renderAll();
    bindMessageInputs();
  });
}


function initAuthMvp() {

  console.log("AUTH MVP INIT");
  const elEmail = document.getElementById("login-email");
  const elPassword = document.getElementById("login-password");

  const btnLogin = document.getElementById("btn-login");
  const btnMe = document.getElementById("btn-me");
  const btnLogout = document.getElementById("btn-logout");

  const elStatus = document.getElementById("auth-status");

  function setStatus(msg, obj = null) {
    if (!elStatus) return;

    if (obj) {
      elStatus.textContent = msg + "\n" + JSON.stringify(obj, null, 2);
    } else {
      elStatus.textContent = msg;
    }
  }

  function getToken() {
    return localStorage.getItem("usly_token");
  }

  function setToken(token) {
    localStorage.setItem("usly_token", token);
  }

  function clearToken() {
    localStorage.removeItem("usly_token");
  }

  // Globalny auto-logout tylko po 401 z apiFetch()
    window.addEventListener("auth:logout", (e) => {
      try { clearToken(); } catch (_) {}
      try { localStorage.removeItem(USLY_STORAGE_KEYS.userPlan); } catch (_) {}
      try { localStorage.removeItem("usly_user_interests"); } catch (_) {}

      App.isLoggedIn = false;
      App.currentUserId = null;
      App.selectedPersonId = null;
      App.selectedChatId = null;
      App.selectedChatUserId = null;
      App.selectedEventId = null;
      App.selectedGroupId = null;

      App.user.plan = "free";
      App.user.nick = "";
      App.user.city = "";
      App.user.age = 24;
      App.user.bio = "";
      App.user.interests = [];
      App.user.prefAgeFrom = 18;
      App.user.prefAgeTo = 35;
      App.user.avatarUrl = "";

      App.people = [];
      App.chats = [];
      App.myGroups = [];

      $("appRoot")?.classList.remove("isLoggedIn");
      hide($("tabbarUser"));
      hide($("tabbarPartner"));

      const st = e && e.detail && e.detail.status ? e.detail.status : "?";
      if (Number(st) !== 401) return;
      setStatus("⛔ Wylogowano automatycznie (HTTP " + st + ") — zaloguj się ponownie");
      App.history = ["S0_WELCOME"];
      go("S0_WELCOME");
    });

  // --- LOGIN ---

  if (btnLogin) {
    btnLogin.addEventListener("click", async () => {

      const email = elEmail?.value.trim();
      const password = elPassword?.value.trim();

      if (!email || !password) {
        setStatus("❌ Podaj email i hasło");
        return;
      }

      setStatus("⏳ Logowanie...");
      try {
        const data = await apiFetch("/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email, password, expected_role: App.role === "partner" ? "partner" : "user" }),
        });
        
        if (!data?.success) {
          setStatus("❌ " + (data?.message || "Login error"), data);
          return;
        }
        const token = data.data.access_token;
        
        setToken(token);

        setStatus("✅ Zalogowano. Token zapisany.");

      } catch (err) {
        console.error(err);
        setStatus("❌ " + (err.userMessage || "Błąd logowania"));
      }

    });
  }

  // --- ME ---

  if (btnMe) {
      btnMe.addEventListener("click", async () => {

        const token = getToken();

        if (!token) {
          setStatus("❌ Brak tokena — zaloguj się");
          return;
        }

        setStatus("⏳ Pobieranie /auth/me...");

        try {
          const data = await apiFetch("/auth/me");
          setStatus("✅ /auth/me OK", data);

        } catch (err) {
          console.error(err);

          // 401/403 obsługuje apiFetch() -> emituje auth:logout i ustawia globalny komunikat
          if (err && (err.status === 401 || err.status === 403)) {
            return;
          }

          setStatus("❌ " + (err.userMessage || "Błąd"), err.data || err.message);
        }

      });
    }

    // --- LOGOUT ---

  if (btnLogout) {
    btnLogout.addEventListener("click", () => {
      clearToken();
      setStatus("👋 Wylogowano (token usunięty)");
    });
  }

}

// Run when DOM ready
document.addEventListener("DOMContentLoaded", init);

// ===============================
// AUTH MVP
// ===============================



/* ------------------------- Leaflet Map -------------------------- */

let nearbyMap = null;
let nearbyMarkers = [];

function initNearbyMap() {
  const el = document.getElementById("nearbyMap");
  if (!el || nearbyMap) return;

  const lat = App.user?.geo?.lat ? Number(App.user.geo.lat) : 52.2297;
  const lng = App.user?.geo?.lng ? Number(App.user.geo.lng) : 21.0122;

  nearbyMap = L.map("nearbyMap").setView([lat, lng], 12);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap"
  }).addTo(nearbyMap);
}

function renderNearbyMapMarkers() {
  if (!nearbyMap) return;

  nearbyMarkers.forEach(m => nearbyMap.removeLayer(m));
  nearbyMarkers = [];

  const baseLat = App.user?.geo?.lat ? Number(App.user.geo.lat) : 52.2297;
  const baseLng = App.user?.geo?.lng ? Number(App.user.geo.lng) : 21.0122;

  const personIcon = L.divIcon({
    className: "nearby-person-marker",
    html: `<div style="position:relative;width:28px;height:34px;display:flex;align-items:flex-start;justify-content:center;"><div style="width:26px;height:26px;border-radius:999px 999px 999px 0;transform:rotate(-45deg);background:linear-gradient(135deg,#ff4bd4,#7b61ff);border:2px solid rgba(255,255,255,.96);box-shadow:0 10px 22px rgba(0,0,0,.30);position:absolute;top:0;left:1px;"></div><div style="position:absolute;top:3px;left:5px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;font-size:12px;transform:rotate(0deg);">👤</div></div>`,
    iconSize: [28, 34],
    iconAnchor: [14, 30],
  });

  const eventIcon = L.divIcon({
    className: "nearby-event-marker",
    html: `<div style="width:24px;height:24px;border-radius:999px;background:linear-gradient(135deg,#34e6ff,#00c48c);border:2px solid rgba(255,255,255,.95);box-shadow:0 10px 22px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;color:#052b2f;font-size:12px;font-weight:900;">🎫</div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });

  getNearbyPeopleForView().forEach((person, index) => {
    const lat = baseLat + (Math.random() - 0.5) * 0.06;
    const lng = baseLng + (Math.random() - 0.5) * 0.06;

    const marker = L.marker([lat, lng], { icon: personIcon })
      .addTo(nearbyMap);

    marker.on("click", () => openMapMarker("person", index));
    nearbyMarkers.push(marker);
  });

}



function openProfileEdit(){
  go("S10B_PROFILE_EDIT");
}


function refreshInterestUi() {
  const count = Array.isArray(App.user.interests) ? App.user.interests.length : 0;
  const limit = getUserInterestLimit();

  const ensureHint = (preferredId, anchorId) => {
    let el = $(preferredId);
    if (el) return el;

    const anchor = $(anchorId);
    if (!anchor || !anchor.parentNode) return null;

    el = document.createElement("div");
    el.id = preferredId;
    el.className = "sectionSub";
    el.style.marginTop = "8px";
    anchor.parentNode.insertBefore(el, anchor.nextSibling);
    return el;
  };

  const hintTargets = [
    ensureHint("regInterestLimitHint", "regInterestChips"),
    $("interestLimitHint"),
    $("setupInterestLimitHint"),
    $("setInterestLimitHint")
  ].filter(Boolean);

  const hintText = limit === null
    ? `${count} • VIP`
    : `${count}/${limit}`;

  hintTargets.forEach((hint) => {
    hint.textContent = hintText;
  });

  const inputs = [
    $("regInterestInput"),
    $("interestInput"),
    $("setInterestInput")
  ].filter(Boolean);

  const canAdd = canAddMoreInterests(count);

  inputs.forEach((input) => {
    input.disabled = !canAdd;
    input.style.opacity = canAdd ? "1" : "0.6";

    if (!canAdd) {
      input.placeholder = "Limit osiągnięty • Odblokuj więcej w PLUS";
      input.onclick = () => toast("Odblokuj więcej zainteresowań w planie PLUS");
    } else {
      input.onclick = null;
    }
  });
}

function openProfileInterests(){
  go("S10C_PROFILE_INTERESTS");
}

function openChangePassword() {
  openModal("Zmień hasło", `
    <div class="tStrong">Zmiana hasła</div>
    <div class="sectionSub mt10">Wpisz obecne hasło i ustaw nowe hasło do konta.</div>
    <label class="mt12">Obecne hasło</label>
    <input id="changePasswordCurrent" type="password" placeholder="Wpisz obecne hasło" />
    <label class="mt12">Nowe hasło</label>
    <input id="changePasswordNew" type="password" placeholder="Wpisz nowe hasło" />
    <label class="mt12">Powtórz nowe hasło</label>
    <input id="changePasswordRepeat" type="password" placeholder="Powtórz nowe hasło" />
    <button class="btn mt16" type="button" onclick="submitChangePassword()">Zapisz nowe hasło</button>
  `);
}

async function submitChangePassword() {
  const currentPassword = $("changePasswordCurrent")?.value?.trim() || "";
  const newPassword = $("changePasswordNew")?.value?.trim() || "";
  const repeatPassword = $("changePasswordRepeat")?.value?.trim() || "";

  if (!currentPassword || !newPassword || !repeatPassword) {
    toast("Uzupełnij wszystkie pola hasła");
    return;
  }

  if (newPassword !== repeatPassword) {
    toast("Nowe hasła nie są takie same");
    return;
  }

  if (newPassword.length < 8) {
    toast("Nowe hasło musi mieć co najmniej 8 znaków");
    return;
  }

  try {
    const res = await apiFetch("/auth/change-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        current_password: currentPassword,
        new_password: newPassword,
      }),
    });

    if (res?.success) {
      toast("Hasło zostało zmienione");
      closeModal();
      return;
    }

    toast(res?.error?.message || "Nie udało się zmienić hasła");
  } catch (err) {
    const msg =
      err?.data?.detail === "CURRENT_PASSWORD_INVALID"
        ? "Obecne hasło jest nieprawidłowe"
        : err?.data?.detail === "NEW_PASSWORD_SAME_AS_CURRENT"
        ? "Nowe hasło musi być inne niż obecne"
        : err?.userMessage || "Nie udało się zmienić hasła";
    toast(msg);
  }
}

function openDeleteAccount() {
  openModal("Usuń konto", `
    <div class="tStrong">Usuń konto</div>
    <div class="sectionSub mt10">Ta akcja jest nieodwracalna. Wpisz hasło, aby potwierdzić usunięcie konta.</div>
    <label class="mt12">Hasło</label>
    <input id="deleteAccountPassword" type="password" placeholder="Wpisz hasło, aby potwierdzić" />
    <button class="btn danger mt16" type="button" onclick="submitDeleteAccount()">Usuń konto</button>
  `);
}

async function submitDeleteAccount() {
  const password = $("deleteAccountPassword")?.value?.trim() || "";

  if (!password) {
    toast("Wpisz hasło, aby potwierdzić usunięcie konta");
    return;
  }

  try {
    const res = await apiFetch("/auth/delete-account", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });

    if (res?.success) {
      try { localStorage.removeItem("usly_token"); } catch (_) {}
      App.isLoggedIn = false;
      App.currentUserId = null;
      closeModal();
      toast("Konto zostało usunięte");
      go("S0_WELCOME");
      renderAll();
      return;
    }

    toast(res?.error?.message || "Nie udało się usunąć konta");
  } catch (err) {
    const msg =
      err?.data?.detail === "PASSWORD_INVALID"
        ? "Hasło jest nieprawidłowe"
        : err?.userMessage || "Nie udało się usunąć konta";
    toast(msg);
  }
}


/* ------------------------- LIVE BUG REPORT OVERRIDE -------------------------- */
async function submitBugReport() {
  const ta = $("bugReportText");
  const message = (ta?.value || "").trim();
  if (!message) {
    toast("Opisz proszę problem");
    return;
  }

  const role = App.role === "partner" ? "Organizator" : "Towarzysz";
  const userId = App.currentUserId ?? null;
  const email =
    (App.role === "partner" ? App.partner?.email : App.user?.email) ||
    null;

  try {
    const res = await apiFetch("/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        role,
        user_id: userId,
        email,
        current_view: App.currentView || null,
      }),
    });

    if (!res?.success || !res?.data?.ticket) {
      toast(res?.error?.message || "Nie udało się wysłać zgłoszenia");
      return;
    }

    closeModal();
    if (res.data.emailed) {
      toast(`Zgłoszenie wysłane • #${res.data.ticket}`);
    } else {
      toast(`Zgłoszenie zapisane • #${res.data.ticket}`);
    }
  } catch (err) {
    toast(err?.userMessage || "Nie udało się wysłać zgłoszenia");
  }
}

async function submitResetPassword() {
  const newPassword = $("resetPasswordNew")?.value?.trim() || "";
  const repeatPassword = $("resetPasswordRepeat")?.value?.trim() || "";

  if (!newPassword || !repeatPassword) {
    toast("Uzupełnij wszystkie pola hasła");
    return;
  }

  if (newPassword !== repeatPassword) {
    toast("Hasła nie są takie same");
    return;
  }

  if (newPassword.length < 8) {
    toast("Hasło musi mieć co najmniej 8 znaków");
    return;
  }

  if (!App.resetToken) {
    toast("Brak tokenu resetu hasła");
    return;
  }

  try {
    const res = await apiFetch("/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        token: App.resetToken,
        new_password: newPassword,
      }),
    });

    if (res?.success) {
      toast("Hasło zostało zmienione");
      go("S1_LOGIN");
      return;
    }

    toast(res?.error?.message || "Nie udało się zmienić hasła");
  } catch (err) {
    toast(err?.userMessage || "Błąd resetu hasła");
  }
}

async function loadResetPasswordScreen(token) {
  const tokenValue = String(token || "").trim();

  if (!tokenValue) {
    toast("Brak linku do resetu hasła");
    return false;
  }

  try {
    const res = await apiFetch("/auth/reset-password-info", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: tokenValue }),
    });

    if (!res?.success || !res?.data?.email) {
      toast("Link do resetu hasła jest nieprawidłowy");
      return false;
    }

    App.resetToken = tokenValue;
    App.resetEmail = String(res.data.email || "");

    closeModal();
    go("S3_RESET_PASSWORD");

    if ($("resetPasswordEmail")) $("resetPasswordEmail").value = App.resetEmail;
    if ($("resetPasswordNew")) $("resetPasswordNew").value = "";
    if ($("resetPasswordRepeat")) $("resetPasswordRepeat").value = "";

    return true;
  } catch (err) {
    toast(err?.userMessage || "Nie udało się otworzyć resetu hasła");
    return false;
  }
}

function handlePasswordResetTokenFromUrl() {
  try {
    const params = new URLSearchParams(window.location.search || "");
    const token = (params.get("token") || "").trim();
    if (!token) return;
    setTimeout(() => {
      loadResetPasswordScreen(token).catch(() => {});
    }, 0);
  } catch (_) {}
}

document.addEventListener("DOMContentLoaded", handlePasswordResetTokenFromUrl);

